export type AdPlacement =
  | 'home_top'
  | 'home_middle'
  | 'generator_bottom'
  | 'customizer_bottom'
  | 'poster_bottom'
  | 'footer_top';

export interface AdSlotConfig {
  id: AdPlacement;
  slotId?: string;
  label: string;
  format: 'auto' | 'horizontal' | 'rectangle';
  minHeight: number;
}
