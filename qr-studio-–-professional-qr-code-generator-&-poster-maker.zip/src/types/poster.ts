export type PosterCanvasFormat = 'a4' | 'letter' | 'business_card' | 'portrait' | 'square';

export interface CanvasDimensions {
  width: number;
  height: number;
  label: string;
  category: 'ISO Standard' | 'North American' | 'Stationery' | 'Digital & Social';
  physicalSize: string;
  ratioText: string;
  aspectClass: string;
}

export const POSTER_DIMENSIONS: Record<PosterCanvasFormat, CanvasDimensions> = {
  a4: {
    width: 1240,
    height: 1754,
    label: 'A4 Paper',
    category: 'ISO Standard',
    physicalSize: '210 × 297 mm • 8.27 × 11.69 in',
    ratioText: 'Standard International Flyer / Document (ISO 216)',
    aspectClass: 'aspect-[1/1.414]',
  },
  letter: {
    width: 1275,
    height: 1650,
    label: 'US Letter',
    category: 'North American',
    physicalSize: '215.9 × 279.4 mm • 8.5 × 11.0 in',
    ratioText: 'Standard US Office, Signage & Menu (ANSI A)',
    aspectClass: 'aspect-[8.5/11]',
  },
  business_card: {
    width: 1050,
    height: 600,
    label: 'Business Card',
    category: 'Stationery',
    physicalSize: '88.9 × 50.8 mm • 3.5 × 2.0 in',
    ratioText: 'Standard Wallet & Handout Card (3.5" × 2")',
    aspectClass: 'aspect-[7/4]',
  },
  portrait: {
    width: 1080,
    height: 1350,
    label: 'Portrait Poster',
    category: 'Digital & Social',
    physicalSize: '4:5 Ratio • 1080 × 1350 px',
    ratioText: 'Storefront Notice & Frame Display (4:5)',
    aspectClass: 'aspect-[4/5]',
  },
  square: {
    width: 1080,
    height: 1080,
    label: 'Square Display',
    category: 'Digital & Social',
    physicalSize: '1:1 Ratio • 1080 × 1080 px',
    ratioText: 'Table Tent, Social & Product Box (1:1)',
    aspectClass: 'aspect-square',
  },
};

export type PosterElementType = 'text' | 'qr' | 'logo' | 'shape';

export interface PosterElement {
  id: string;
  type: PosterElementType;
  x: number; // percentage 0 - 100
  y: number; // percentage 0 - 100
  width?: number; // percentage 0 - 100
  height?: number; // percentage 0 - 100
  text?: string;
  fontSize?: number; // scale relative to canvas base font
  fontWeight?: 'normal' | 'bold' | '900';
  textAlign?: 'left' | 'center' | 'right';
  color?: string;
  backgroundColor?: string;
  shapeType?: 'divider' | 'badge' | 'box';
  customClass?: string;
  letterSpacing?: string;
}

export interface PosterTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  format: PosterCanvasFormat;
  backgroundColor: string;
  elements: PosterElement[];
}
