export type QRMode =
  | 'url'
  | 'text'
  | 'wifi'
  | 'vcard'
  | 'whatsapp'
  | 'email'
  | 'sms'
  | 'upi'
  | 'batch';

export type DotPattern = 'square' | 'rounded' | 'dots' | 'classy' | 'classy-rounded' | 'extra-rounded';

export type CornerSquarePattern = 'square' | 'dot' | 'extra-rounded';

export type CornerDotPattern = 'square' | 'dot';

export type ErrorCorrection = 'L' | 'M' | 'Q' | 'H';

export interface FrameConfig {
  enabled: boolean;
  text: string;
  style: 'bottom-banner' | 'top-banner' | 'card' | 'badge' | 'minimal-pill';
  textColor: string;
  frameColor: string;
}

export interface WiFiConfig {
  ssid: string;
  password: string;
  encryption: 'WPA' | 'WEP' | 'nopass';
  hidden: boolean;
}

export interface VCardConfig {
  firstName: string;
  lastName: string;
  organization: string;
  title: string;
  phone: string;
  email: string;
  website: string;
  address: string;
  note: string;
}

export interface WhatsAppConfig {
  phone: string;
  message: string;
}

export interface EmailConfig {
  email: string;
  cc?: string;
  bcc?: string;
  subject: string;
  body: string;
}

export interface SMSConfig {
  phone: string;
  message: string;
}

export interface UPIConfig {
  vpa: string;
  name: string;
  amount: string;
  note: string;
}

export interface BatchItem {
  id: string;
  content: string;
  label: string;
  dataUrl?: string;
  status: 'idle' | 'generating' | 'ready' | 'error';
  error?: string;
}

export interface QRConfig {
  mode: QRMode;
  content: string;
  foregroundColor: string;
  backgroundColor: string;
  dotType: DotPattern;
  cornerSquareType: CornerSquarePattern;
  cornerDotType: CornerDotPattern;
  errorCorrection: ErrorCorrection;
  logoUrl?: string;
  logoFile?: File | null;
  logoSize: number; // 0.1 to 0.35
  margin: number;
  frame: FrameConfig;
}
