import React, { useRef, useMemo, memo } from 'react';
import { PosterCanvasFormat, PosterElement } from '../types/poster';

interface PosterCanvasProps {
  format: PosterCanvasFormat;
  backgroundColor: string;
  backgroundImage: string | null;
  elements: PosterElement[];
  selectedElementId: string | null;
  qrCanvas: HTMLCanvasElement | null;
  onSelectElement: (id: string) => void;
  onUpdateElementPosition: (id: string, x: number, y: number) => void;
}

export const PosterCanvas: React.FC<PosterCanvasProps> = memo(({
  format,
  backgroundColor,
  backgroundImage,
  elements,
  selectedElementId,
  qrCanvas,
  onSelectElement,
  onUpdateElementPosition,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const containerRectRef = useRef<DOMRect | null>(null);
  const draggingIdRef = useRef<string | null>(null);
  const rafIdRef = useRef<number | null>(null);

  // Memoize QR Data URL so dragging elements never calls expensive toDataURL() on every frame
  const qrDataUrl = useMemo(() => {
    if (qrCanvas) {
      try {
        return qrCanvas.toDataURL();
      } catch {
        // Continue to fallback
      }
    }
    // Instant procedural QR data URL fallback so the poster never renders blank
    try {
      const fallback = document.createElement('canvas');
      fallback.width = 256;
      fallback.height = 256;
      const ctx = fallback.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, 256, 256);
        ctx.fillStyle = '#171717';
        const drawEye = (ox: number, oy: number) => {
          ctx.fillRect(ox, oy, 60, 60);
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(ox + 10, oy + 10, 40, 40);
          ctx.fillStyle = '#171717';
          ctx.fillRect(ox + 20, oy + 20, 20, 20);
        };
        drawEye(20, 20);
        drawEye(176, 20);
        drawEye(20, 176);
        for (let r = 0; r < 10; r++) {
          for (let c = 0; c < 10; c++) {
            if ((r * 11 + c * 7 + (r ^ c)) % 3 === 0) {
              ctx.fillRect(36 + c * 18, 36 + r * 18, 12, 12);
            }
          }
        }
      }
      return fallback.toDataURL();
    } catch {
      return '';
    }
  }, [qrCanvas]);

  // Compute aspect ratio CSS classes
  const aspectStyle =
    format === 'square'
      ? 'aspect-square'
      : format === 'portrait'
      ? 'aspect-[4/5]'
      : format === 'business_card'
      ? 'aspect-[7/4]'
      : format === 'letter'
      ? 'aspect-[8.5/11]'
      : 'aspect-[1/1.414]';

  const handlePointerDown = (e: React.PointerEvent, id: string) => {
    e.stopPropagation();
    onSelectElement(id);
    draggingIdRef.current = id;
    if (containerRef.current) {
      containerRectRef.current = containerRef.current.getBoundingClientRect();
    }
    try {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      // Safe catch
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draggingIdRef.current || !containerRectRef.current) return;
    const clientX = e.clientX;
    const clientY = e.clientY;

    if (rafIdRef.current) cancelAnimationFrame(rafIdRef.current);
    rafIdRef.current = requestAnimationFrame(() => {
      if (!containerRectRef.current || !draggingIdRef.current) return;
      const rect = containerRectRef.current;
      const rawX = ((clientX - rect.left) / rect.width) * 100;
      const rawY = ((clientY - rect.top) / rect.height) * 100;

      const clampedX = Math.max(5, Math.min(95, Math.round(rawX)));
      const clampedY = Math.max(5, Math.min(95, Math.round(rawY)));

      onUpdateElementPosition(draggingIdRef.current, clampedX, clampedY);
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (rafIdRef.current) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }
    if (draggingIdRef.current) {
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {
        // Safe catch
      }
      draggingIdRef.current = null;
    }
  };

  return (
    <div className="w-full flex justify-center items-center py-4 px-2 select-none overflow-hidden">
      <div
        ref={containerRef}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onClick={() => onSelectElement('')}
        className={`relative w-full max-w-[460px] md:max-w-[500px] shadow-lg rounded-sm border border-[#171717]/20 transition-all ${aspectStyle} will-change-contents`}
        style={{
          backgroundColor,
          backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        {/* Render elements */}
        {elements.map((el) => {
          const isSelected = el.id === selectedElementId;

          if (el.type === 'shape') {
            if (el.shapeType === 'divider') {
              return (
                <div
                  key={el.id}
                  onPointerDown={(e) => handlePointerDown(e, el.id)}
                  style={{
                    left: `${el.x}%`,
                    top: `${el.y}%`,
                    width: `${el.width ?? 60}%`,
                    height: '2px',
                    backgroundColor: el.backgroundColor || '#171717',
                    transform: 'translate(-50%, -50%)',
                    touchAction: 'none',
                  }}
                  className={`absolute cursor-move transition-shadow ${
                    isSelected ? 'ring-2 ring-[#2563EB] ring-offset-2' : ''
                  }`}
                />
              );
            }

            if (el.shapeType === 'badge') {
              return (
                <div
                  key={el.id}
                  onPointerDown={(e) => handlePointerDown(e, el.id)}
                  style={{
                    left: `${el.x}%`,
                    top: `${el.y}%`,
                    width: `${el.width ?? 40}%`,
                    backgroundColor: el.backgroundColor || '#2563EB',
                    color: el.color || '#FFFFFF',
                    transform: 'translate(-50%, -50%)',
                    touchAction: 'none',
                  }}
                  className={`absolute cursor-move py-1 px-3 rounded-full text-center transition-shadow shadow-xs flex items-center justify-center ${
                    isSelected ? 'ring-2 ring-[#2563EB] ring-offset-2' : ''
                  }`}
                >
                  <span className="text-[10px] sm:text-xs font-bold tracking-wider uppercase truncate pointer-events-none">
                    {el.text}
                  </span>
                </div>
              );
            }
          }

          if (el.type === 'qr') {
            return (
              <div
                key={el.id}
                onPointerDown={(e) => handlePointerDown(e, el.id)}
                style={{
                  left: `${el.x}%`,
                  top: `${el.y}%`,
                  width: `${el.width ?? 42}%`,
                  transform: 'translate(-50%, -50%)',
                  touchAction: 'none',
                }}
                className={`absolute cursor-move aspect-square bg-white p-2 rounded-xl shadow-md border border-[#171717]/10 flex items-center justify-center transition-all ${
                  isSelected ? 'ring-2 ring-[#2563EB] ring-offset-4' : ''
                }`}
              >
                {qrDataUrl ? (
                  <img
                    src={qrDataUrl}
                    alt="Active QR Code"
                    className="w-full h-full object-contain pointer-events-none"
                    loading="eager"
                  />
                ) : (
                  <div className="w-full h-full bg-[#171717]/5 flex items-center justify-center text-[10px] text-[#171717]/40 font-mono">
                    Generating QR...
                  </div>
                )}
              </div>
            );
          }

          if (el.type === 'text') {
            return (
              <div
                key={el.id}
                onPointerDown={(e) => handlePointerDown(e, el.id)}
                style={{
                  left: `${el.x}%`,
                  top: `${el.y}%`,
                  color: el.color || '#171717',
                  textAlign: el.textAlign || 'center',
                  transform: 'translate(-50%, -50%)',
                  touchAction: 'none',
                }}
                className={`absolute cursor-move px-2 py-0.5 rounded transition-all max-w-[90%] whitespace-pre-line ${
                  isSelected
                    ? 'ring-2 ring-[#2563EB] bg-[#2563EB]/10'
                    : 'hover:outline-dashed hover:outline-1 hover:outline-[#171717]/30'
                }`}
              >
                <span
                  style={{
                    fontSize: `${(el.fontSize || 16) * 0.75}px`,
                    fontWeight: el.fontWeight === '900' ? 900 : el.fontWeight === 'bold' ? 700 : 400,
                    letterSpacing: el.letterSpacing || 'normal',
                  }}
                  className="block leading-tight select-none pointer-events-none"
                >
                  {el.text}
                </span>
              </div>
            );
          }

          return null;
        })}
      </div>
    </div>
  );
});

PosterCanvas.displayName = 'PosterCanvas';
