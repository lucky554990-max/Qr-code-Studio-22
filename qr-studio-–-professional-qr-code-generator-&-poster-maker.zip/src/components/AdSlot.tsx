import React, { useEffect, useState, memo } from 'react';
import { ADS_ENABLED, ADSENSE_PUBLISHER_ID, AD_SLOTS } from '../config/ads';
import { AdPlacement } from '../types/ads';

interface AdSlotProps {
  placement: AdPlacement;
  className?: string;
  minHeight?: number;
  showDevPlaceholder?: boolean;
}

export const AdSlot = memo<AdSlotProps>(({
  placement,
  className = '',
  minHeight,
  showDevPlaceholder = false,
}) => {
  const config = AD_SLOTS[placement];
  const effectiveMinHeight = minHeight ?? config?.minHeight ?? 90;
  const [adLoaded, setAdLoaded] = useState(false);

  useEffect(() => {
    if (ADS_ENABLED && ADSENSE_PUBLISHER_ID && config?.slotId) {
      try {
        // @ts-expect-error window.adsbygoogle is injected by the official Google AdSense script
        (window.adsbygoogle = window.adsbygoogle || []).push({});
        setAdLoaded(true);
      } catch (e) {
        console.warn('AdSense initialization deferred:', e);
      }
    }
  }, [config?.slotId]);

  // When monetization is disabled, by default don't create layout disruptions.
  // If showDevPlaceholder is true, render a subtle, non-intrusive container clearly labeled as development space.
  if (!ADS_ENABLED) {
    if (!showDevPlaceholder) {
      return null;
    }

    return (
      <aside
        aria-label="Advertisement Space Reservation"
        className={`w-full max-w-4xl mx-auto my-6 px-4 py-3 border border-dashed border-[#171717]/20 dark:border-white/20 rounded-md bg-[#171717]/[0.02] dark:bg-white/[0.02] text-center select-none ${className}`}
        style={{ minHeight: `${effectiveMinHeight}px` }}
      >
        <div className="flex flex-col items-center justify-center h-full text-xs text-[#171717]/40 dark:text-white/40 tracking-wider uppercase font-mono py-2">
          <span className="font-semibold text-[#171717]/60 dark:text-white/70">Advertisement Space</span>
          <span className="text-[10px] mt-1 text-[#171717]/40 dark:text-white/40">
            {config?.label || placement} • Reserved for Google AdSense
          </span>
        </div>
      </aside>
    );
  }

  // Active AdSense configuration
  return (
    <div
      className={`w-full max-w-4xl mx-auto my-6 flex justify-center items-center overflow-hidden ${className}`}
      style={{ minHeight: `${effectiveMinHeight}px` }}
    >
      <ins
        className="adsbygoogle"
        style={{ display: 'block', minHeight: `${effectiveMinHeight}px`, width: '100%' }}
        data-ad-client={ADSENSE_PUBLISHER_ID}
        data-ad-slot={config?.slotId || ''}
        data-ad-format={config?.format || 'auto'}
        data-full-width-responsive="true"
      />
      {!adLoaded && (
        <span className="sr-only">Advertisement</span>
      )}
    </div>
  );
});

AdSlot.displayName = 'AdSlot';
