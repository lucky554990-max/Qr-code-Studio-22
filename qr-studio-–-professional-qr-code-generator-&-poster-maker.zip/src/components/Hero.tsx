import React, { useState, useEffect, useRef, memo } from 'react';
import QRCodeStyling from 'qr-code-styling';
import { ArrowRight, CheckCircle2, ShieldCheck, Sliders } from 'lucide-react';
import { validateAndFormatUrl } from '../utils/validateUrl';

interface HeroProps {
  onScrollToGenerator: () => void;
  onScrollToCustomizer: () => void;
}

export const Hero = memo<HeroProps>(({ onScrollToGenerator, onScrollToCustomizer }) => {
  const [heroInput, setHeroInput] = useState('https://qrstudio.app');
  const [activeUrl, setActiveUrl] = useState('https://qrstudio.app');
  const heroQrContainerRef = useRef<HTMLDivElement>(null);
  const heroQrInstanceRef = useRef<QRCodeStyling | null>(null);

  useEffect(() => {
    const container = heroQrContainerRef.current;
    if (!container) return;

    try {
      if (!heroQrInstanceRef.current || container.children.length === 0) {
        container.innerHTML = '';
        const qr = new QRCodeStyling({
          width: 220,
          height: 220,
          data: activeUrl,
          dotsOptions: {
            color: '#171717',
            type: 'rounded',
          },
          backgroundOptions: {
            color: '#FFFFFF',
          },
          cornersSquareOptions: {
            color: '#2563EB',
            type: 'extra-rounded',
          },
          cornersDotOptions: {
            color: '#2563EB',
            type: 'dot',
          },
          qrOptions: {
            errorCorrectionLevel: 'Q',
          },
        });
        heroQrInstanceRef.current = qr;
        qr.append(container);
      } else {
        heroQrInstanceRef.current.update({
          data: activeUrl,
        });
        if (container.children.length === 0) {
          heroQrInstanceRef.current.append(container);
        }
      }
    } catch (err) {
      console.warn('Hero QR render error:', err);
    }
  }, [activeUrl]);

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    const val = validateAndFormatUrl(heroInput);
    if (val.isValid) {
      setActiveUrl(val.formattedUrl);
      setHeroInput(val.formattedUrl);
    } else {
      setActiveUrl(heroInput.trim() || 'https://qrstudio.app');
    }
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-16 md:pt-16 md:pb-24 border-b border-[#171717]/10 dark:border-white/10 bg-white dark:bg-[#121212] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Headlines & Actions */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#171717]/15 dark:border-white/15 bg-[#171717]/[0.03] dark:bg-white/[0.04] text-xs font-medium text-[#171717] dark:text-white">
              <ShieldCheck className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>100% Client-Side Local Generation • Zero Server Logs</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#171717] dark:text-white leading-[1.08]">
              Create QR Codes. <br />
              <span className="text-[#2563EB]">Make Them Yours.</span>
            </h1>

            <p className="text-lg sm:text-xl text-[#171717]/70 dark:text-white/70 max-w-2xl leading-relaxed">
              Generate, customize, and download professional QR codes for links, Wi-Fi, vCard contacts,
              WhatsApp, and payments. Clean vector exports, real-time 3D display mockups, and printable
              promotional posters in one studio.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                type="button"
                onClick={onScrollToGenerator}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-[#2563EB] hover:bg-[#1d4ed8] text-white font-semibold rounded-xl text-base shadow-sm transition-all focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-2 touch-manipulation active:scale-95"
              >
                <span>Create Your QR Code</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onScrollToCustomizer}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-white dark:bg-[#1e1e1e] text-[#171717] dark:text-white hover:bg-[#171717]/5 dark:hover:bg-white/10 font-semibold rounded-xl text-base border border-[#171717]/20 dark:border-white/20 transition-all touch-manipulation active:scale-95"
              >
                <Sliders className="w-4 h-4 text-[#2563EB]" />
                <span>Explore Customization</span>
              </button>
            </div>

            {/* Feature Guarantees */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-[#171717]/10 dark:border-white/10">
              <div className="flex items-center gap-2 text-xs text-[#171717]/80 dark:text-white/80">
                <CheckCircle2 className="w-4 h-4 text-[#2563EB] shrink-0" />
                <span>No sign-up or paywalls</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#171717]/80 dark:text-white/80">
                <CheckCircle2 className="w-4 h-4 text-[#2563EB] shrink-0" />
                <span>Vector SVG & High-Res PNG</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-[#171717]/80 dark:text-white/80">
                <CheckCircle2 className="w-4 h-4 text-[#2563EB] shrink-0" />
                <span>Embedded Brand Icons & Frames</span>
              </div>
            </div>
          </div>

          {/* Right Column: Real Interactive Preview Card */}
          <div className="lg:col-span-5">
            <div className="bg-white dark:bg-[#1e1e1e] border-2 border-[#171717] dark:border-white/20 rounded-2xl p-6 sm:p-7 shadow-[8px_8px_0px_0px_#171717] dark:shadow-[8px_8px_0px_0px_#2563EB]">
              <div className="flex items-center justify-between pb-4 border-b border-[#171717]/10 dark:border-white/10 mb-5">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]" />
                  <span className="text-xs font-bold uppercase tracking-wider text-[#171717] dark:text-white">
                    Live Interactive Preview
                  </span>
                </div>
                <span className="text-[11px] font-mono text-[#171717]/50 dark:text-white/50">Client-Side Engine</span>
              </div>

              {/* Real QR Output Canvas Container */}
              <div className="bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/10 dark:border-white/10 rounded-xl p-4 flex flex-col items-center justify-center min-h-[260px] relative">
                <div ref={heroQrContainerRef} className="flex justify-center items-center bg-white p-2 rounded-lg" />
                <span className="text-[11px] text-[#171717]/60 dark:text-white/60 font-mono mt-3 text-center truncate max-w-[240px]">
                  {activeUrl}
                </span>
              </div>

              {/* Quick Input Bar to test live updates */}
              <form onSubmit={handleApply} className="mt-4 flex gap-2">
                <input
                  type="text"
                  value={heroInput}
                  onChange={(e) => setHeroInput(e.target.value)}
                  placeholder="Type any URL or link..."
                  className="flex-1 px-3.5 py-2 text-xs sm:text-sm border border-[#171717]/20 dark:border-white/20 rounded-lg focus:outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB] bg-white dark:bg-[#252525] text-[#171717] dark:text-white"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#171717] dark:bg-white text-white dark:text-[#171717] hover:bg-[#2563EB] dark:hover:bg-gray-100 rounded-lg text-xs font-semibold transition-colors touch-manipulation active:scale-95"
                >
                  Update
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

Hero.displayName = 'Hero';
