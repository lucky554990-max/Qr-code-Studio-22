import React, { useRef, useState, memo } from 'react';
import {
  PosterCanvasFormat,
  PosterElement,
  POSTER_DIMENSIONS,
} from '../types/poster';
import { POSTER_TEMPLATES } from '../hooks/usePosterEditor';
import {
  Layers,
  Type,
  BadgePercent,
  Trash2,
  Undo2,
  Redo2,
  RotateCcw,
  Download,
  Image as ImageIcon,
  AlignCenter,
  AlignLeft,
  AlignRight,
  Bold,
  Printer,
  FileText,
  CreditCard,
  Maximize,
  Check,
} from 'lucide-react';

interface PosterToolbarProps {
  format: PosterCanvasFormat;
  backgroundColor: string;
  backgroundImage: string | null;
  selectedElement: PosterElement | null;
  selectedTemplateId: string;
  canUndo: boolean;
  canRedo: boolean;
  isExporting: boolean;
  onSelectFormat: (format: PosterCanvasFormat) => void;
  onSelectTemplate: (templateId: string) => void;
  onUpdateBackgroundColor: (color: string) => void;
  onUploadBackgroundImage: (file: File) => void;
  onRemoveBackgroundImage: () => void;
  onAddElement: (type: 'text' | 'shape') => void;
  onUpdateElement: (id: string, patch: Partial<PosterElement>) => void;
  onRemoveElement: (id: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  onResetPoster: () => void;
  onExportPoster: (fileType: 'png' | 'jpeg', scale?: number) => void;
}

export const PosterToolbar = memo<PosterToolbarProps>(({
  format,
  backgroundColor,
  backgroundImage,
  selectedElement,
  selectedTemplateId,
  canUndo,
  canRedo,
  isExporting,
  onSelectFormat,
  onSelectTemplate,
  onUpdateBackgroundColor,
  onUploadBackgroundImage,
  onRemoveBackgroundImage,
  onAddElement,
  onUpdateElement,
  onRemoveElement,
  onUndo,
  onRedo,
  onResetPoster,
  onExportPoster,
}) => {
  const bgInputRef = useRef<HTMLInputElement>(null);
  const [printDpiScale, setPrintDpiScale] = useState<number>(2.0); // 2.0 = 300 DPI high-res, 1.0 = 150 DPI

  const handleBgFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadBackgroundImage(file);
    }
  };

  const paperPresets: {
    id: PosterCanvasFormat;
    label: string;
    sublabel: string;
    icon: typeof FileText;
  }[] = [
    {
      id: 'a4',
      label: 'A4 Paper',
      sublabel: '210 × 297 mm (ISO 216)',
      icon: FileText,
    },
    {
      id: 'letter',
      label: 'US Letter',
      sublabel: '8.5 × 11 in (ANSI A)',
      icon: FileText,
    },
    {
      id: 'business_card',
      label: 'Business Card',
      sublabel: '3.5 × 2 in (Standard)',
      icon: CreditCard,
    },
    {
      id: 'portrait',
      label: 'Portrait Poster',
      sublabel: '4:5 Display Frame',
      icon: Maximize,
    },
    {
      id: 'square',
      label: 'Square Display',
      sublabel: '1:1 Social & Box',
      icon: Maximize,
    },
  ];

  const currentDim = POSTER_DIMENSIONS[format];
  const targetPxW = Math.round(currentDim.width * printDpiScale);
  const targetPxH = Math.round(currentDim.height * printDpiScale);

  return (
    <div className="bg-white dark:bg-[#1a1a1a] border border-[#171717]/15 dark:border-white/10 rounded-2xl p-5 shadow-sm space-y-6 transition-colors">
      {/* Top Header & Actions */}
      <div className="flex items-center justify-between pb-4 border-b border-[#171717]/10 dark:border-white/10">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#2563EB]" />
          <h3 className="text-sm font-bold text-[#171717] dark:text-white uppercase tracking-wider">
            Poster Tools & Templates
          </h3>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={onUndo}
            disabled={!canUndo}
            title="Undo"
            className="p-1.5 text-[#171717]/60 dark:text-white/60 hover:text-[#171717] dark:hover:text-white disabled:opacity-30 rounded hover:bg-[#171717]/5 dark:hover:bg-white/5 transition-colors touch-manipulation"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onRedo}
            disabled={!canRedo}
            title="Redo"
            className="p-1.5 text-[#171717]/60 dark:text-white/60 hover:text-[#171717] dark:hover:text-white disabled:opacity-30 rounded hover:bg-[#171717]/5 dark:hover:bg-white/5 transition-colors touch-manipulation"
          >
            <Redo2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onResetPoster}
            title="Reset to Template Defaults"
            className="p-1.5 text-[#171717]/60 dark:text-white/60 hover:text-[#171717] dark:hover:text-white rounded hover:bg-[#171717]/5 dark:hover:bg-white/5 transition-colors touch-manipulation"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 1. Template Chooser */}
      <div>
        <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-2">
          1. Choose Business Template
        </label>
        <select
          value={selectedTemplateId}
          onChange={(e) => onSelectTemplate(e.target.value)}
          className="w-full px-3 py-2 text-xs font-medium border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
        >
          {POSTER_TEMPLATES.map((tpl) => (
            <option key={tpl.id} value={tpl.id}>
              {tpl.name} ({tpl.category})
            </option>
          ))}
        </select>
      </div>

      {/* 2. Industry-Standard Paper Sizes & Formats */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-semibold text-[#171717] dark:text-white block">
            2. Industry-Standard Paper Size
          </label>
          <span className="text-[10px] font-mono text-[#171717]/50 dark:text-white/50 uppercase">
            {currentDim.category}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {paperPresets.map((preset) => {
            const Icon = preset.icon;
            const isSelected = format === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => onSelectFormat(preset.id)}
                className={`p-2.5 rounded-xl border text-left transition-all flex items-start gap-2.5 touch-manipulation active:scale-95 ${
                  isSelected
                    ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#171717] dark:text-white ring-1 ring-[#2563EB]'
                    : 'border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] text-[#171717]/80 dark:text-white/80 hover:border-[#171717]/35 dark:hover:border-white/35'
                }`}
              >
                <div
                  className={`p-1.5 rounded-lg shrink-0 ${
                    isSelected ? 'bg-[#2563EB] text-white' : 'bg-[#171717]/5 dark:bg-white/5 text-[#171717] dark:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold leading-tight block truncate text-[#171717] dark:text-white">
                      {preset.label}
                    </span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />}
                  </div>
                  <span className="text-[10px] text-[#171717]/60 dark:text-white/60 block mt-0.5 leading-tight">
                    {preset.sublabel}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Current Paper Specification Callout */}
        <div className="mt-2.5 px-3 py-2 bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/10 dark:border-white/10 rounded-lg flex items-center justify-between text-[11px] font-mono text-[#171717]/70 dark:text-white/70">
          <span>Physical: {currentDim.physicalSize}</span>
          <span className="font-bold text-[#2563EB] dark:text-[#60a5fa]">{currentDim.label}</span>
        </div>
      </div>

      {/* 3. Background Color & Image */}
      <div>
        <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-2">
          3. Canvas Background
        </label>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onUpdateBackgroundColor('#FFFFFF')}
            className={`w-8 h-8 rounded-lg border border-[#171717]/20 dark:border-white/20 bg-white transition-transform ${
              backgroundColor === '#FFFFFF' ? 'ring-2 ring-[#2563EB] scale-110' : ''
            }`}
            title="Pure White"
          />
          <button
            type="button"
            onClick={() => onUpdateBackgroundColor('#171717')}
            className={`w-8 h-8 rounded-lg border border-[#171717]/20 dark:border-white/20 bg-[#171717] transition-transform ${
              backgroundColor === '#171717' ? 'ring-2 ring-[#2563EB] scale-110' : ''
            }`}
            title="Charcoal Black"
          />
          <div className="flex items-center gap-2 flex-1">
            <input
              type="color"
              value={backgroundColor}
              onChange={(e) => onUpdateBackgroundColor(e.target.value)}
              className="w-8 h-8 rounded border border-[#171717]/20 dark:border-white/20 p-0.5 cursor-pointer bg-white dark:bg-[#242424]"
            />
            <span className="text-[11px] font-mono uppercase text-[#171717]/60 dark:text-white/60">
              {backgroundColor}
            </span>
          </div>
        </div>

        {/* Upload Background image */}
        <div className="mt-3 flex items-center justify-between">
          <input
            ref={bgInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleBgFile}
          />
          <button
            type="button"
            onClick={() => bgInputRef.current?.click()}
            className="text-xs text-[#2563EB] dark:text-[#60a5fa] hover:underline flex items-center gap-1 font-medium"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Upload Background Photo</span>
          </button>
          {backgroundImage && (
            <button
              type="button"
              onClick={onRemoveBackgroundImage}
              className="text-xs text-red-600 dark:text-red-400 hover:underline"
            >
              Remove Image
            </button>
          )}
        </div>
      </div>

      {/* 4. Element Adder */}
      <div>
        <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-2">
          4. Add New Element
        </label>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onAddElement('text')}
            className="py-2 px-3 border border-[#171717]/20 dark:border-white/20 hover:border-[#2563EB] text-[#171717] dark:text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors touch-manipulation active:scale-95"
          >
            <Type className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>Add Text</span>
          </button>
          <button
            type="button"
            onClick={() => onAddElement('shape')}
            className="py-2 px-3 border border-[#171717]/20 dark:border-white/20 hover:border-[#2563EB] text-[#171717] dark:text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors touch-manipulation active:scale-95"
          >
            <BadgePercent className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>Add Badge</span>
          </button>
        </div>
      </div>

      {/* 5. Selected Element Inspector */}
      {selectedElement && (
        <div className="p-4 border border-[#2563EB]/30 bg-[#2563EB]/[0.02] dark:bg-white/[0.02] rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#171717] dark:text-white uppercase tracking-wider">
              Selected: {selectedElement.type.toUpperCase()}
            </span>
            {selectedElement.type !== 'qr' && (
              <button
                type="button"
                onClick={() => onRemoveElement(selectedElement.id)}
                className="text-xs text-red-600 dark:text-red-400 hover:underline flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" />
                <span>Delete</span>
              </button>
            )}
          </div>

          {/* Text Editor */}
          {selectedElement.type === 'text' && (
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-[#171717] dark:text-white block mb-1">
                  Text Content
                </label>
                <input
                  type="text"
                  value={selectedElement.text || ''}
                  onChange={(e) => onUpdateElement(selectedElement.id, { text: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs border border-[#171717]/20 dark:border-white/20 rounded bg-white dark:bg-[#242424] text-[#171717] dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-[#171717] dark:text-white block mb-1">
                    Font Size ({selectedElement.fontSize}px)
                  </label>
                  <input
                    type="range"
                    min="10"
                    max="80"
                    value={selectedElement.fontSize || 24}
                    onChange={(e) =>
                      onUpdateElement(selectedElement.id, {
                        fontSize: parseInt(e.target.value),
                      })
                    }
                    className="w-full accent-[#2563EB]"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-[#171717] dark:text-white block mb-1">
                    Text Color
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={selectedElement.color || '#171717'}
                      onChange={(e) =>
                        onUpdateElement(selectedElement.id, { color: e.target.value })
                      }
                      className="w-7 h-7 rounded border border-[#171717]/20 p-0.5 cursor-pointer bg-white dark:bg-[#242424]"
                    />
                    <span className="text-[11px] font-mono text-[#171717]/60 dark:text-white/60">
                      {selectedElement.color}
                    </span>
                  </div>
                </div>
              </div>

              {/* Text Align & Weight */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    onUpdateElement(selectedElement.id, {
                      fontWeight: selectedElement.fontWeight === 'bold' ? 'normal' : 'bold',
                    })
                  }
                  className={`p-1.5 rounded border ${
                    selectedElement.fontWeight === 'bold'
                      ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#2563EB]'
                      : 'border-[#171717]/20 dark:border-white/20 text-[#171717] dark:text-white'
                  }`}
                  title="Toggle Bold"
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <div className="flex items-center border border-[#171717]/20 dark:border-white/20 rounded p-0.5">
                  <button
                    type="button"
                    onClick={() => onUpdateElement(selectedElement.id, { textAlign: 'left' })}
                    className={`p-1 rounded ${
                      selectedElement.textAlign === 'left' ? 'bg-[#171717]/10 dark:bg-white/10' : ''
                    }`}
                  >
                    <AlignLeft className="w-3.5 h-3.5 text-[#171717] dark:text-white" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onUpdateElement(selectedElement.id, { textAlign: 'center' })}
                    className={`p-1 rounded ${
                      selectedElement.textAlign === 'center' ? 'bg-[#171717]/10 dark:bg-white/10' : ''
                    }`}
                  >
                    <AlignCenter className="w-3.5 h-3.5 text-[#171717] dark:text-white" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onUpdateElement(selectedElement.id, { textAlign: 'right' })}
                    className={`p-1 rounded ${
                      selectedElement.textAlign === 'right' ? 'bg-[#171717]/10 dark:bg-white/10' : ''
                    }`}
                  >
                    <AlignRight className="w-3.5 h-3.5 text-[#171717] dark:text-white" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* QR Code Resizer */}
          {selectedElement.type === 'qr' && (
            <div className="space-y-2">
              <label className="text-[11px] font-semibold text-[#171717] dark:text-white block">
                QR Code Dimension ({Math.round(selectedElement.width || 200)}px)
              </label>
              <input
                type="range"
                min="100"
                max="360"
                value={selectedElement.width || 200}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  onUpdateElement(selectedElement.id, { width: val, height: val });
                }}
                className="w-full accent-[#2563EB]"
              />
              <p className="text-[11px] text-[#171717]/50 dark:text-white/50">
                Drag the QR code directly on the canvas to place it anywhere.
              </p>
            </div>
          )}
        </div>
      )}

      {/* 6. Export Poster Section with Pre-Download Paper Size & DPI Presets */}
      <div className="pt-4 border-t border-[#171717]/10 dark:border-white/10 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <label className="text-xs font-bold text-[#171717] dark:text-white block">
              Download or Print Poster
            </label>
            <span className="text-[10px] text-[#171717]/60 dark:text-white/60 block mt-0.5">
              Target Paper Size: <strong>{currentDim.label}</strong> ({currentDim.physicalSize})
            </span>
          </div>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1 text-xs text-[#2563EB] dark:text-[#60a5fa] hover:underline font-semibold"
            title="Open browser print dialogue"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Direct</span>
          </button>
        </div>

        {/* DPI Quality Picker */}
        <div className="bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/10 dark:border-white/10 p-2.5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold text-[#171717] dark:text-white">Export Print Quality:</span>
            <span className="font-mono text-[#2563EB] dark:text-[#60a5fa] font-bold">
              {targetPxW} × {targetPxH} px
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setPrintDpiScale(2.0)}
              className={`py-1.5 px-2 text-[11px] rounded-lg border text-center transition-all touch-manipulation ${
                printDpiScale === 2.0
                  ? 'border-[#2563EB] bg-[#2563EB] text-white font-bold shadow-xs'
                  : 'border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] text-[#171717]/80 dark:text-white/80 hover:border-[#171717]/30 dark:hover:border-white/30'
              }`}
            >
              300 DPI Print (Commercial)
            </button>
            <button
              type="button"
              onClick={() => setPrintDpiScale(1.0)}
              className={`py-1.5 px-2 text-[11px] rounded-lg border text-center transition-all touch-manipulation ${
                printDpiScale === 1.0
                  ? 'border-[#2563EB] bg-[#2563EB] text-white font-bold shadow-xs'
                  : 'border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] text-[#171717]/80 dark:text-white/80 hover:border-[#171717]/30 dark:hover:border-white/30'
              }`}
            >
              150 DPI Web / Standard
            </button>
          </div>
        </div>

        {/* Download Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => {
              if (isExporting) return;
              onExportPoster('png', printDpiScale);
            }}
            disabled={isExporting}
            className="py-2.5 px-3 bg-[#171717] dark:bg-white text-white dark:text-[#171717] hover:bg-[#2563EB] dark:hover:bg-gray-100 active:scale-95 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-50 touch-manipulation min-h-[44px]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Generating...' : 'High-Res PNG'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              if (isExporting) return;
              onExportPoster('jpeg', printDpiScale);
            }}
            disabled={isExporting}
            className="py-2.5 px-3 bg-[#171717] dark:bg-white text-white dark:text-[#171717] hover:bg-[#2563EB] dark:hover:bg-gray-100 active:scale-95 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-50 touch-manipulation min-h-[44px]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Generating...' : 'Print JPEG'}</span>
          </button>
        </div>
      </div>
    </div>
  );
});

PosterToolbar.displayName = 'PosterToolbar';
