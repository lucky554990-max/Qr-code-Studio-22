import React, { memo } from 'react';
import {
  Link2,
  FileText,
  Wifi,
  Contact,
  MessageCircle,
  Mail,
  Phone,
  CreditCard,
  Layers,
  AlertCircle,
  Sparkles,
  X,
  Download,
  Check,
  Archive,
} from 'lucide-react';
import {
  QRMode,
  WiFiConfig,
  VCardConfig,
  WhatsAppConfig,
  EmailConfig,
  SMSConfig,
  UPIConfig,
  BatchItem,
} from '../types/qr';
import { downloadDataUrl } from '../utils/exportFile';

interface QRGeneratorProps {
  mode: QRMode;
  urlInput: string;
  textInput: string;
  wifiConfig: WiFiConfig;
  vcardConfig: VCardConfig;
  whatsappConfig: WhatsAppConfig;
  emailConfig: EmailConfig;
  smsConfig: SMSConfig;
  upiConfig: UPIConfig;
  batchInput: string;
  batchItems: BatchItem[];
  isProcessingBatch: boolean;
  urlError: string | null;
  isDirty: boolean;
  onModeChange: (mode: QRMode) => void;
  onUrlChange: (val: string) => void;
  onTextChange: (val: string) => void;
  onWiFiChange: (patch: Partial<WiFiConfig>) => void;
  onVCardChange: (patch: Partial<VCardConfig>) => void;
  onWhatsAppChange: (patch: Partial<WhatsAppConfig>) => void;
  onEmailChange: (patch: Partial<EmailConfig>) => void;
  onSMSChange: (patch: Partial<SMSConfig>) => void;
  onUPIChange: (patch: Partial<UPIConfig>) => void;
  onBatchInputChange: (val: string) => void;
  onProcessBatch: () => void;
  onDownloadBatchZip: () => void;
  onGenerate: () => void;
  onClear: () => void;
}

export const QRGenerator: React.FC<QRGeneratorProps> = memo(({
  mode,
  urlInput,
  textInput,
  wifiConfig,
  vcardConfig,
  whatsappConfig,
  emailConfig,
  smsConfig,
  upiConfig,
  batchInput,
  batchItems,
  isProcessingBatch,
  urlError,
  isDirty,
  onModeChange,
  onUrlChange,
  onTextChange,
  onWiFiChange,
  onVCardChange,
  onWhatsAppChange,
  onEmailChange,
  onSMSChange,
  onUPIChange,
  onBatchInputChange,
  onProcessBatch,
  onDownloadBatchZip,
  onGenerate,
  onClear,
}) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate();
  };

  const modeButtons: { id: QRMode; label: string; icon: React.ReactNode }[] = [
    { id: 'url', label: 'URL', icon: <Link2 className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'text', label: 'Text', icon: <FileText className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'wifi', label: 'Wi-Fi', icon: <Wifi className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'vcard', label: 'vCard', icon: <Contact className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'whatsapp', label: 'WhatsApp', icon: <MessageCircle className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'email', label: 'Email', icon: <Mail className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'sms', label: 'SMS', icon: <Phone className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'upi', label: 'UPI Pay', icon: <CreditCard className="w-4 h-4 text-[#2563EB]" /> },
    { id: 'batch', label: 'Batch/Bulk', icon: <Layers className="w-4 h-4 text-[#2563EB]" /> },
  ];

  return (
    <div className="bg-white dark:bg-[#1a1a1a] border border-[#171717]/15 dark:border-white/10 rounded-2xl p-5 sm:p-7 shadow-sm transition-colors">
      {/* Mode Selector Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-6 border-b border-[#171717]/10 dark:border-white/10 scrollbar-none">
        {modeButtons.map((btn) => (
          <button
            key={btn.id}
            type="button"
            onClick={() => onModeChange(btn.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap touch-manipulation active:scale-95 shrink-0 ${
              mode === btn.id
                ? 'bg-[#171717] dark:bg-white text-white dark:text-[#171717] shadow-xs'
                : 'bg-[#171717]/5 dark:bg-white/5 text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-[#171717]/10 dark:hover:bg-white/10'
            }`}
          >
            {btn.icon}
            <span>{btn.label}</span>
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* MODE: URL */}
        {mode === 'url' && (
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="url-input" className="text-sm font-semibold text-[#171717] dark:text-white">
                Destination URL
              </label>
              <span className="text-[11px] text-[#171717]/50 dark:text-white/50 font-mono">
                Auto-prefixes https:// if omitted
              </span>
            </div>
            <div className="relative">
              <input
                id="url-input"
                type="text"
                value={urlInput}
                onChange={(e) => onUrlChange(e.target.value)}
                placeholder="e.g. yourbusiness.com or https://example.com/menu"
                autoComplete="off"
                spellCheck="false"
                className={`w-full px-4 py-3 text-sm rounded-xl border bg-white dark:bg-[#242424] text-[#171717] dark:text-white transition-all focus:outline-none focus:ring-2 focus:ring-[#2563EB] pr-10 min-h-[46px] ${
                  urlError
                    ? 'border-red-500 bg-red-50/20 dark:bg-red-950/20'
                    : 'border-[#171717]/20 dark:border-white/20 hover:border-[#171717]/40 dark:hover:border-white/40'
                }`}
              />
              {urlInput && (
                <button
                  type="button"
                  onClick={onClear}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#171717]/40 dark:text-white/40 hover:text-[#171717] dark:hover:text-white p-2 touch-manipulation active:scale-90"
                  title="Clear input"
                  aria-label="Clear URL input"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* MODE: PLAIN TEXT */}
        {mode === 'text' && (
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="text-input" className="text-sm font-semibold text-[#171717] dark:text-white">
                Encoded Text Content
              </label>
              <span className="text-[11px] text-[#171717]/50 dark:text-white/50 font-mono">
                {textInput.length} characters
              </span>
            </div>
            <div className="relative">
              <textarea
                id="text-input"
                rows={4}
                value={textInput}
                onChange={(e) => onTextChange(e.target.value)}
                placeholder="Enter any text, wifi credentials, secret key, or instructions to encode..."
                spellCheck="false"
                className="w-full px-4 py-3 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 hover:border-[#171717]/40 dark:hover:border-white/40 bg-white dark:bg-[#242424] text-[#171717] dark:text-white transition-all focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              />
              {textInput && (
                <button
                  type="button"
                  onClick={onClear}
                  className="absolute right-3 top-3 text-[#171717]/40 dark:text-white/40 hover:text-[#171717] dark:hover:text-white p-2 touch-manipulation active:scale-90"
                  title="Clear input"
                  aria-label="Clear text input"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* MODE: WI-FI */}
        {mode === 'wifi' && (
          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                Network Name (SSID) *
              </label>
              <input
                type="text"
                value={wifiConfig.ssid}
                onChange={(e) => onWiFiChange({ ssid: e.target.value })}
                placeholder="e.g. Cafe_Guest_5G"
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Password
                </label>
                <input
                  type="text"
                  value={wifiConfig.password}
                  onChange={(e) => onWiFiChange({ password: e.target.value })}
                  placeholder="Enter Wi-Fi password"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                  disabled={wifiConfig.encryption === 'nopass'}
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Security Encryption
                </label>
                <select
                  value={wifiConfig.encryption}
                  onChange={(e) =>
                    onWiFiChange({
                      encryption: e.target.value as 'WPA' | 'WEP' | 'nopass',
                    })
                  }
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                >
                  <option value="WPA">WPA / WPA2 / WPA3 (Standard)</option>
                  <option value="WEP">WEP</option>
                  <option value="nopass">None (Open Network)</option>
                </select>
              </div>
            </div>

            <label className="inline-flex items-center gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={wifiConfig.hidden}
                onChange={(e) => onWiFiChange({ hidden: e.target.checked })}
                className="rounded border-[#171717]/20 text-[#2563EB] focus:ring-[#2563EB]"
              />
              <span className="text-xs text-[#171717]/80 dark:text-white/80">
                Hidden SSID (Network is not broadcasting name)
              </span>
            </label>
          </div>
        )}

        {/* MODE: VCARD */}
        {mode === 'vcard' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  First Name
                </label>
                <input
                  type="text"
                  value={vcardConfig.firstName}
                  onChange={(e) => onVCardChange({ firstName: e.target.value })}
                  placeholder="e.g. Alex"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Last Name
                </label>
                <input
                  type="text"
                  value={vcardConfig.lastName}
                  onChange={(e) => onVCardChange({ lastName: e.target.value })}
                  placeholder="e.g. Morgan"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Organization / Company
                </label>
                <input
                  type="text"
                  value={vcardConfig.organization}
                  onChange={(e) => onVCardChange({ organization: e.target.value })}
                  placeholder="e.g. Studio Agency"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Job Title
                </label>
                <input
                  type="text"
                  value={vcardConfig.title}
                  onChange={(e) => onVCardChange({ title: e.target.value })}
                  placeholder="e.g. Managing Director"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={vcardConfig.phone}
                  onChange={(e) => onVCardChange({ phone: e.target.value })}
                  placeholder="+1 (555) 019-2834"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Email Address(es)
                </label>
                <input
                  type="text"
                  value={vcardConfig.email}
                  onChange={(e) => onVCardChange({ email: e.target.value })}
                  placeholder="alex@domain.com, work@domain.com"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Website URL
                </label>
                <input
                  type="text"
                  value={vcardConfig.website}
                  onChange={(e) => onVCardChange({ website: e.target.value })}
                  placeholder="https://company.com"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  City / Location
                </label>
                <input
                  type="text"
                  value={vcardConfig.address}
                  onChange={(e) => onVCardChange({ address: e.target.value })}
                  placeholder="San Francisco, CA"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
            </div>
          </div>
        )}

        {/* MODE: WHATSAPP */}
        {mode === 'whatsapp' && (
          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                WhatsApp Phone Number (with Country Code) *
              </label>
              <input
                type="tel"
                value={whatsappConfig.phone}
                onChange={(e) => onWhatsAppChange({ phone: e.target.value })}
                placeholder="e.g. 15551234567 or 447911123456"
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
              <span className="text-[11px] text-[#171717]/50 dark:text-white/50 block mt-1">
                Enter numbers only with country code (e.g., 1 for US, 44 for UK, 91 for India).
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                Pre-filled Chat Message (Optional)
              </label>
              <textarea
                rows={3}
                value={whatsappConfig.message}
                onChange={(e) => onWhatsAppChange({ message: e.target.value })}
                placeholder="Hello! I would like to inquire about your product..."
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>
          </div>
        )}

        {/* MODE: EMAIL */}
        {mode === 'email' && (
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-[#171717] dark:text-white">
                  Recipient Email(s) *
                </label>
                <span className="text-[11px] text-[#171717]/50 dark:text-white/50 font-mono">
                  Separate multiples with commas (e.g. sales@co.com, info@co.com)
                </span>
              </div>
              <input
                type="text"
                value={emailConfig.email}
                onChange={(e) => onEmailChange({ email: e.target.value })}
                placeholder="sales@example.com, support@example.com"
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  CC Email(s) (Optional)
                </label>
                <input
                  type="text"
                  value={emailConfig.cc || ''}
                  onChange={(e) => onEmailChange({ cc: e.target.value })}
                  placeholder="manager@example.com"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  BCC Email(s) (Optional)
                </label>
                <input
                  type="text"
                  value={emailConfig.bcc || ''}
                  onChange={(e) => onEmailChange({ bcc: e.target.value })}
                  placeholder="archive@example.com"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                Subject Line
              </label>
              <input
                type="text"
                value={emailConfig.subject}
                onChange={(e) => onEmailChange({ subject: e.target.value })}
                placeholder="Business Inquiry / Service Request"
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                Email Body Message
              </label>
              <textarea
                rows={3}
                value={emailConfig.body}
                onChange={(e) => onEmailChange({ body: e.target.value })}
                placeholder="Hi, I am interested in your services..."
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>
          </div>
        )}

        {/* MODE: SMS */}
        {mode === 'sms' && (
          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                Phone Number *
              </label>
              <input
                type="tel"
                value={smsConfig.phone}
                onChange={(e) => onSMSChange({ phone: e.target.value })}
                placeholder="+1 555-0199"
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                SMS Text Message (Optional)
              </label>
              <textarea
                rows={3}
                value={smsConfig.message}
                onChange={(e) => onSMSChange({ message: e.target.value })}
                placeholder="Text message to pre-fill when scanned..."
                className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>
          </div>
        )}

        {/* MODE: UPI PAY */}
        {mode === 'upi' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  UPI ID / VPA *
                </label>
                <input
                  type="text"
                  value={upiConfig.vpa}
                  onChange={(e) => onUPIChange({ vpa: e.target.value })}
                  placeholder="merchant@okhdfcbank"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Payee Business Name *
                </label>
                <input
                  type="text"
                  value={upiConfig.name}
                  onChange={(e) => onUPIChange({ name: e.target.value })}
                  placeholder="Acme Retail Store"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Amount (Optional, leave blank for any amount)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={upiConfig.amount}
                  onChange={(e) => onUPIChange({ amount: e.target.value })}
                  placeholder="e.g. 150.00"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                  Payment Note / Memo
                </label>
                <input
                  type="text"
                  value={upiConfig.note}
                  onChange={(e) => onUPIChange({ note: e.target.value })}
                  placeholder="Order payment"
                  className="w-full px-3 py-2 text-sm rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>
            </div>
          </div>
        )}

        {/* MODE: BATCH / BULK */}
        {mode === 'batch' && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-[#171717] dark:text-white">
                  Batch Entries (One per line: URL or Text, Optional Label)
                </label>
                <span className="text-[11px] text-[#171717]/50 dark:text-white/50 font-mono">
                  Format: Content, Label
                </span>
              </div>
              <textarea
                rows={5}
                value={batchInput}
                onChange={(e) => onBatchInputChange(e.target.value)}
                placeholder="https://example.com/item1, Table 1&#10;https://example.com/item2, Table 2&#10;https://example.com/item3, Table 3"
                className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-[#171717]/20 dark:border-white/20 bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={onProcessBatch}
                disabled={isProcessingBatch}
                className="px-4 py-2 bg-[#2563EB] hover:bg-[#1d4ed8] text-white rounded-xl text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 transition-all disabled:opacity-50 touch-manipulation active:scale-95"
              >
                <Layers className="w-4 h-4" />
                <span>{isProcessingBatch ? 'Generating Batch...' : 'Generate Batch QR Codes'}</span>
              </button>

              {batchItems.length > 0 && (
                <button
                  type="button"
                  onClick={onDownloadBatchZip}
                  className="px-4 py-2 bg-[#171717] dark:bg-white text-white dark:text-[#171717] rounded-xl text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 hover:bg-black dark:hover:bg-gray-100 transition-all touch-manipulation active:scale-95"
                >
                  <Archive className="w-4 h-4" />
                  <span>Download All as ZIP</span>
                </button>
              )}
            </div>

            {/* Batch Results Grid */}
            {batchItems.length > 0 && (
              <div className="pt-3 border-t border-[#171717]/10 dark:border-white/10 space-y-2">
                <span className="text-xs font-bold text-[#171717] dark:text-white block">
                  Batch Results ({batchItems.length} codes)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-72 overflow-y-auto pr-1">
                  {batchItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl border border-[#171717]/15 dark:border-white/15 bg-[#171717]/[0.02] dark:bg-white/5 flex items-center gap-3"
                    >
                      {item.dataUrl ? (
                        <img
                          src={item.dataUrl}
                          alt={item.label}
                          className="w-14 h-14 rounded-lg bg-white p-0.5 border border-[#171717]/10 shrink-0"
                        />
                      ) : (
                        <div className="w-14 h-14 rounded-lg bg-white/20 animate-pulse shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <span className="font-semibold text-xs text-[#171717] dark:text-white truncate block">
                          {item.label}
                        </span>
                        <span className="text-[10px] text-[#171717]/50 dark:text-white/50 truncate block font-mono">
                          {item.content}
                        </span>
                        {item.dataUrl && (
                          <button
                            type="button"
                            onClick={() => downloadDataUrl(item.dataUrl!, `${item.label || 'qr'}.png`)}
                            className="mt-1 text-[11px] text-[#2563EB] font-semibold hover:underline inline-flex items-center gap-1"
                          >
                            <Download className="w-3 h-3" />
                            <span>Download</span>
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Validation Error Banner */}
        {urlError && (
          <div className="flex items-start gap-2 p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 rounded-lg text-xs text-red-700 dark:text-red-400">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600 dark:text-red-400" />
            <span>{urlError}</span>
          </div>
        )}

        {/* Primary Action Button (for non-batch modes) */}
        {mode !== 'batch' && (
          <div className="pt-2 flex items-center justify-between gap-3">
            <button
              type="submit"
              className={`w-full py-3 px-5 rounded-xl text-sm font-semibold text-white shadow-xs flex items-center justify-center gap-2 transition-all touch-manipulation active:scale-[0.98] ${
                isDirty
                  ? 'bg-[#2563EB] hover:bg-[#1d4ed8] ring-2 ring-[#2563EB]/40'
                  : 'bg-[#171717] dark:bg-white dark:text-[#171717] hover:bg-[#262626] dark:hover:bg-gray-100'
              }`}
            >
              {isDirty ? (
                <>
                  <Sparkles className="w-4 h-4 text-white" />
                  <span>Update QR Code Now</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 text-white dark:text-[#171717]" />
                  <span>QR Code Live & Scannable</span>
                </>
              )}
            </button>
          </div>
        )}
      </form>
    </div>
  );
});

QRGenerator.displayName = 'QRGenerator';
