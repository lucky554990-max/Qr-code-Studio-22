import React, { memo } from 'react';
import {
  BookOpen,
  ArrowRight,
  Clock,
  Calendar,
  CheckCircle2,
  Sparkles,
  ArrowLeft,
  Share2,
  ShieldCheck,
  Printer,
  ChevronRight,
} from 'lucide-react';
import { SEO_ARTICLES, SEOArticle } from '../data/seoArticles';

interface SEOArticlesViewProps {
  currentArticleSlug: string | null;
  onSelectArticle: (slug: string) => void;
  onBackToArticlesList: () => void;
  onNavigateToGenerator: () => void;
}

export const SEOArticlesView: React.FC<SEOArticlesViewProps> = memo(({
  currentArticleSlug,
  onSelectArticle,
  onBackToArticlesList,
  onNavigateToGenerator,
}) => {
  const currentArticle = SEO_ARTICLES.find((a) => a.slug === currentArticleSlug);

  // Detail View of a specific guide
  if (currentArticle) {
    const relatedArticles = SEO_ARTICLES.filter((a) =>
      currentArticle.relatedSlugs.includes(a.slug)
    );

    return (
      <article className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-200">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between text-xs text-[#171717]/60 dark:text-white/60 pb-3 border-b border-[#171717]/10 dark:border-white/10">
          <button
            type="button"
            onClick={onBackToArticlesList}
            className="inline-flex items-center gap-1.5 hover:text-[#2563EB] dark:hover:text-[#60a5fa] font-medium transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Guides</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-[#2563EB]/10 text-[#2563EB] dark:text-[#60a5fa] font-semibold text-[11px]">
              {currentArticle.category}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              <span>{currentArticle.readingTime}</span>
            </span>
          </div>
        </div>

        {/* Article Header */}
        <header className="space-y-4">
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#171717] dark:text-white leading-tight">
            {currentArticle.title}
          </h1>
          <p className="text-base text-[#171717]/70 dark:text-white/70 leading-relaxed font-normal">
            {currentArticle.summary}
          </p>
          <div className="flex items-center gap-4 text-xs text-[#171717]/50 dark:text-white/50 pt-1 font-mono">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>Updated: {currentArticle.publishedDate}</span>
            </span>
            <span>•</span>
            <span>Verified by QR Studio Engineering Team</span>
          </div>
        </header>

        {/* In-Article CTA Banner */}
        <div className="p-4 rounded-xl border border-[#2563EB]/30 bg-[#2563EB]/5 dark:bg-[#2563EB]/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <span className="text-xs font-bold text-[#171717] dark:text-white flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#2563EB]" />
              Ready to create your code?
            </span>
            <p className="text-xs text-[#171717]/70 dark:text-white/70">
              Generate 100% client-side QR codes right here in QR Studio. No registration required.
            </p>
          </div>
          <button
            type="button"
            onClick={onNavigateToGenerator}
            className="px-4 py-2 bg-[#2563EB] hover:bg-[#1d4ed8] text-white rounded-lg text-xs font-semibold shrink-0 shadow-xs transition-all touch-manipulation active:scale-95"
          >
            Launch QR Generator
          </button>
        </div>

        {/* Article Body Content */}
        <div className="space-y-8 text-[#171717]/90 dark:text-white/90 leading-relaxed text-sm">
          {currentArticle.sections.map((section, idx) => (
            <section key={idx} className="space-y-3">
              {section.level === 'h2' ? (
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#171717] dark:text-white pt-2 border-t border-[#171717]/10 dark:border-white/10 first:border-t-0 first:pt-0">
                  {section.heading}
                </h2>
              ) : (
                <h3 className="text-lg font-bold tracking-tight text-[#171717] dark:text-white pt-1">
                  {section.heading}
                </h3>
              )}

              {section.paragraphs.map((para, pIdx) => (
                <p key={pIdx} className="text-[#171717]/80 dark:text-white/80 leading-relaxed">
                  {para}
                </p>
              ))}

              {section.bulletPoints && (
                <ul className="list-disc pl-5 space-y-1.5 text-xs sm:text-sm text-[#171717]/80 dark:text-white/80 my-2">
                  {section.bulletPoints.map((bp, bIdx) => (
                    <li key={bIdx}>{bp}</li>
                  ))}
                </ul>
              )}

              {section.callout && (
                <div
                  className={`p-3.5 rounded-xl border text-xs leading-relaxed my-3 ${
                    section.callout.type === 'warning'
                      ? 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-200'
                      : section.callout.type === 'tip'
                      ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900 text-emerald-900 dark:text-emerald-200'
                      : 'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900 text-blue-900 dark:text-blue-200'
                  }`}
                >
                  <span className="font-bold uppercase tracking-wider block mb-1">
                    {section.callout.type.toUpperCase()}:
                  </span>
                  <span>{section.callout.text}</span>
                </div>
              )}
            </section>
          ))}
        </div>

        {/* Related Articles Footer */}
        {relatedArticles.length > 0 && (
          <div className="pt-8 border-t border-[#171717]/10 dark:border-white/10 space-y-4">
            <h3 className="text-base font-bold text-[#171717] dark:text-white uppercase tracking-wider">
              Related Guides & Best Practices
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {relatedArticles.map((rel) => (
                <button
                  key={rel.slug}
                  type="button"
                  onClick={() => onSelectArticle(rel.slug)}
                  className="p-4 rounded-xl border border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#1a1a1a] hover:border-[#2563EB] text-left transition-all group flex flex-col justify-between"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-mono font-bold text-[#2563EB] dark:text-[#60a5fa]">
                      {rel.category}
                    </span>
                    <h4 className="text-sm font-bold text-[#171717] dark:text-white group-hover:text-[#2563EB] dark:group-hover:text-[#60a5fa] transition-colors leading-snug">
                      {rel.title}
                    </h4>
                    <p className="text-xs text-[#171717]/60 dark:text-white/60 line-clamp-2 mt-1">
                      {rel.metaDescription}
                    </p>
                  </div>
                  <span className="text-xs text-[#2563EB] dark:text-[#60a5fa] font-semibold inline-flex items-center gap-1 mt-3">
                    <span>Read Article</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </article>
    );
  }

  // Index List View of all Articles
  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#2563EB]/10 text-[#2563EB] dark:text-[#60a5fa] text-xs font-semibold">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Knowledge Base & Technical Guides</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#171717] dark:text-white tracking-tight">
          QR Code Best Practices, Tutorials & Guides
        </h2>
        <p className="text-sm text-[#171717]/70 dark:text-white/70">
          Everything you need to know about generating, styling, printing, and deploying commercial QR
          codes with zero data leakage.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SEO_ARTICLES.map((article) => (
          <article
            key={article.slug}
            className="p-5 rounded-2xl border border-[#171717]/15 dark:border-white/10 bg-white dark:bg-[#1a1a1a] shadow-sm hover:border-[#2563EB] dark:hover:border-[#2563EB] transition-all flex flex-col justify-between group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-[#171717]/50 dark:text-white/50">
                <span className="px-2 py-0.5 rounded-md bg-[#171717]/5 dark:bg-white/5 text-[#171717]/80 dark:text-white/80 font-semibold font-mono text-[10px]">
                  {article.category}
                </span>
                <span className="flex items-center gap-1 font-mono text-[11px]">
                  <Clock className="w-3 h-3" />
                  <span>{article.readingTime}</span>
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-[#171717] dark:text-white group-hover:text-[#2563EB] dark:group-hover:text-[#60a5fa] transition-colors leading-snug">
                  {article.title}
                </h3>
                <p className="text-xs text-[#171717]/70 dark:text-white/70 leading-relaxed mt-2 line-clamp-3">
                  {article.metaDescription}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#171717]/10 dark:border-white/10 mt-4 flex items-center justify-between">
              <span className="text-[11px] text-[#171717]/50 dark:text-white/50 font-mono">
                {article.publishedDate}
              </span>
              <button
                type="button"
                onClick={() => onSelectArticle(article.slug)}
                className="text-xs font-bold text-[#2563EB] dark:text-[#60a5fa] inline-flex items-center gap-1 group-hover:underline"
              >
                <span>Read Full Guide</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
});

SEOArticlesView.displayName = 'SEOArticlesView';
