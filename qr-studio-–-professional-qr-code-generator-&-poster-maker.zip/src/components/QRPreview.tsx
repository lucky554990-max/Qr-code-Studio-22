import React, { useEffect, useRef, useState, useCallback, memo } from 'react';
import QRCodeStyling, {
  DotType,
  CornerSquareType,
  CornerDotType,
  ErrorCorrectionLevel,
} from 'qr-code-styling';
import QRCode from 'qrcode';
import {
  Download,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Printer,
  ExternalLink,
} from 'lucide-react';
import { QRConfig } from '../types/qr';
import { ContrastResult } from '../utils/contrast';

interface QRPreviewProps {
  config: QRConfig;
  contrastResult: ContrastResult;
  isExporting: boolean;
  onExport: (format: 'png' | 'jpeg' | 'svg') => void;
  onReset: () => void;
  onNavigateToCustomizer: () => void;
}

export const QRPreview: React.FC<QRPreviewProps> = memo(({
  config,
  contrastResult,
  isExporting,
  onExport,
  onReset,
  onNavigateToCustomizer,
}) => {
  const previewContainerRef = useRef<HTMLDivElement>(null);
  const fallbackCanvasRef = useRef<HTMLCanvasElement>(null);
  const qrStylingInstanceRef = useRef<QRCodeStyling | null>(null);
  const [usingFallback, setUsingFallback] = useState(false);
  const [renderError, setRenderError] = useState<string | null>(null);
  const lastExportClickRef = useRef<number>(0);

  // Directly update or initialize QRCodeStyling without destroying DOM nodes
  useEffect(() => {
    const container = previewContainerRef.current;
    if (!container) return;

    const dataContent = config.content?.trim() || 'https://qrstudio.app';

    // Adaptive error correction for large data
    const safeErrorCorrection =
      dataContent.length > 500
        ? 'L'
        : dataContent.length > 250
        ? 'M'
        : config.logoUrl
        ? 'H'
        : config.errorCorrection || 'Q';

    try {
      setUsingFallback(false);
      setRenderError(null);

      const qrOptions = {
        width: 260,
        height: 260,
        type: 'canvas' as const,
        data: dataContent,
        dotsOptions: {
          color: config.foregroundColor || '#171717',
          type: config.dotType as DotType,
        },
        backgroundOptions: {
          color: config.backgroundColor || '#FFFFFF',
        },
        cornersSquareOptions: {
          color: config.foregroundColor || '#171717',
          type: config.cornerSquareType as CornerSquareType,
        },
        cornersDotOptions: {
          color: config.foregroundColor || '#171717',
          type: config.cornerDotType as CornerDotType,
        },
        image: config.logoUrl,
        imageOptions: {
          crossOrigin: 'anonymous',
          margin: 4,
          imageSize: config.logoSize || 0.24,
        },
        qrOptions: {
          errorCorrectionLevel: safeErrorCorrection as ErrorCorrectionLevel,
        },
      };

      if (!qrStylingInstanceRef.current || container.children.length === 0) {
        container.innerHTML = '';
        const qr = new QRCodeStyling(qrOptions);
        qr.append(container);
        qrStylingInstanceRef.current = qr;
      } else {
        qrStylingInstanceRef.current.update(qrOptions);
        if (container.children.length === 0) {
          qrStylingInstanceRef.current.append(container);
        }
      }
    } catch (err) {
      console.warn('QRCodeStyling render error, activating fallback standard canvas:', err);
      setUsingFallback(true);

      if (fallbackCanvasRef.current) {
        QRCode.toCanvas(
          fallbackCanvasRef.current,
          dataContent,
          {
            width: 260,
            margin: 1,
            color: {
              dark: config.foregroundColor || '#171717',
              light: config.backgroundColor || '#FFFFFF',
            },
            errorCorrectionLevel: safeErrorCorrection === 'H' ? 'H' : 'M',
          },
          (error) => {
            if (error) {
              setRenderError('Data too long to encode in a standard QR code.');
            } else {
              setRenderError(null);
            }
          }
        );
      }
    }
  }, [config]);

  const handleExportWithDebounce = useCallback(
    (format: 'png' | 'jpeg' | 'svg') => {
      const now = Date.now();
      if (now - lastExportClickRef.current < 800 || isExporting) return;
      lastExportClickRef.current = now;
      onExport(format);
    },
    [onExport, isExporting]
  );

  const handlePrint = useCallback(() => {
    window.print();
  }, []);

  const getModeLabel = (mode: string) => {
    switch (mode) {
      case 'url': return 'Website URL';
      case 'text': return 'Plain Text';
      case 'wifi': return 'Wi-Fi Network';
      case 'vcard': return 'vCard Contact';
      case 'whatsapp': return 'WhatsApp';
      case 'email': return 'Email Mailto';
      case 'sms': return 'SMS Message';
      case 'upi': return 'UPI Payment';
      case 'batch': return 'Batch Mode';
      default: return 'QR Code';
    }
  };

  return (
    <div className="bg-white dark:bg-[#1a1a1a] border border-[#171717]/15 dark:border-white/10 rounded-2xl p-5 sm:p-7 shadow-sm flex flex-col justify-between h-full print:border-none print:p-0 transition-colors">
      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-[#171717]/10 dark:border-white/10 mb-4 print:hidden">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#171717] dark:text-white">
              Live QR Preview
            </h3>
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#171717]/5 dark:bg-white/5 text-[#171717]/70 dark:text-white/70 uppercase">
            {getModeLabel(config.mode)}
          </span>
        </div>

        {/* Canvas Display Card (Marked for Print) */}
        <div className="print-asset-container relative bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/10 dark:border-white/10 rounded-xl p-6 flex flex-col items-center justify-center min-h-[340px] print:bg-white print:border-none print:p-0">
          {/* Framed preview container */}
          <div
            className={`flex flex-col items-center justify-center p-3 transition-all ${
              config.frame.enabled ? 'border-2 rounded-xl' : ''
            }`}
            style={{
              backgroundColor: config.backgroundColor,
              borderColor: config.frame.enabled ? config.frame.frameColor : 'transparent',
            }}
          >
            {/* Top Frame Banner if enabled */}
            {config.frame.enabled && config.frame.style === 'top-banner' && (
              <div
                className="w-full text-center py-1.5 px-4 mb-2 rounded-lg text-xs font-bold tracking-wider uppercase select-none"
                style={{
                  backgroundColor: config.frame.frameColor,
                  color: config.frame.textColor,
                }}
              >
                {config.frame.text}
              </div>
            )}

            {/* QR Node Container */}
            <div
              ref={previewContainerRef}
              className={`flex items-center justify-center overflow-hidden will-change-contents ${
                usingFallback ? 'hidden' : 'block'
              }`}
            />

            {/* Fallback Canvas */}
            <canvas
              ref={fallbackCanvasRef}
              className={`rounded-lg ${usingFallback ? 'block' : 'hidden'}`}
              width={260}
              height={260}
            />

            {renderError && (
              <div className="p-3 text-xs text-red-600 bg-red-50 dark:bg-red-950/40 rounded-lg max-w-[260px] text-center mt-2">
                {renderError}
              </div>
            )}

            {/* Bottom Frame Banner if enabled */}
            {config.frame.enabled &&
              (config.frame.style === 'bottom-banner' ||
                config.frame.style === 'badge' ||
                config.frame.style === 'card' ||
                config.frame.style === 'minimal-pill') && (
                <div
                  className={`text-center py-1.5 px-4 mt-2 text-xs font-bold tracking-wider uppercase select-none ${
                    config.frame.style === 'badge' || config.frame.style === 'minimal-pill'
                      ? 'rounded-full inline-block self-center'
                      : 'w-full rounded-lg'
                  }`}
                  style={{
                    backgroundColor: config.frame.frameColor,
                    color: config.frame.textColor,
                  }}
                >
                  {config.frame.text}
                </div>
              )}
          </div>

          {/* Decoded Target Readout */}
          <div className="mt-4 text-center max-w-xs print:mt-2">
            <p className="text-[11px] font-mono text-[#171717]/60 dark:text-white/60 truncate" title={config.content}>
              {config.content}
            </p>
          </div>
        </div>

        {/* Contrast & Scannability Reliability Evaluation */}
        <div className="mt-4 print:hidden">
          {contrastResult.isOptimal ? (
            <div className="flex items-center gap-2 p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 rounded-lg text-xs text-emerald-800 dark:text-emerald-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Optimal contrast ({contrastResult.ratio.toFixed(1)}:1). Scans reliably across all mobile cameras.</span>
            </div>
          ) : contrastResult.isAdequate ? (
            <div className="flex items-center gap-2 p-2.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-lg text-xs text-amber-800 dark:text-amber-300">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>Adequate contrast ({contrastResult.ratio.toFixed(1)}:1). Recommend testing in low-light environments.</span>
            </div>
          ) : (
            <div className="flex items-start gap-2 p-2.5 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-lg text-xs text-red-800 dark:text-red-300">
              <ShieldAlert className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
              <span>{contrastResult.warningMessage}</span>
            </div>
          )}
        </div>
      </div>

      {/* Export & Download Actions (Hidden in Print) */}
      <div className="pt-6 border-t border-[#171717]/10 dark:border-white/10 mt-6 space-y-3 print:hidden">
        <div className="flex items-center justify-between mb-1">
          <div className="text-xs font-semibold text-[#171717]/70 dark:text-white/70 uppercase tracking-wider">
            Export Options
          </div>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1 text-xs text-[#171717]/70 dark:text-white/70 hover:text-[#2563EB] dark:hover:text-[#3b82f6] font-medium touch-manipulation active:scale-95 transition-transform"
            title="Print directly from browser"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print QR</span>
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => handleExportWithDebounce('png')}
            disabled={isExporting}
            className="flex items-center justify-center gap-1.5 py-3 px-3 bg-[#171717] dark:bg-white text-white dark:text-[#171717] hover:bg-[#2563EB] dark:hover:bg-gray-100 active:scale-95 rounded-xl text-xs font-semibold transition-all disabled:opacity-50 touch-manipulation min-h-[44px]"
            title="Download crisp 1200px PNG graphic"
          >
            <Download className="w-3.5 h-3.5" />
            <span>PNG</span>
          </button>

          <button
            type="button"
            onClick={() => handleExportWithDebounce('svg')}
            disabled={isExporting}
            className="flex items-center justify-center gap-1.5 py-3 px-3 bg-[#171717] dark:bg-white text-white dark:text-[#171717] hover:bg-[#2563EB] dark:hover:bg-gray-100 active:scale-95 rounded-xl text-xs font-semibold transition-all disabled:opacity-50 touch-manipulation min-h-[44px]"
            title="Download scalable vector SVG for print & large banners"
          >
            <Download className="w-3.5 h-3.5" />
            <span>SVG</span>
          </button>

          <button
            type="button"
            onClick={() => handleExportWithDebounce('jpeg')}
            disabled={isExporting}
            className="flex items-center justify-center gap-1.5 py-3 px-3 bg-[#171717] dark:bg-white text-white dark:text-[#171717] hover:bg-[#2563EB] dark:hover:bg-gray-100 active:scale-95 rounded-xl text-xs font-semibold transition-all disabled:opacity-50 touch-manipulation min-h-[44px]"
            title="Download standard JPEG image"
          >
            <Download className="w-3.5 h-3.5" />
            <span>JPEG</span>
          </button>
        </div>

        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={onReset}
            className="inline-flex items-center gap-1.5 text-xs text-[#171717]/60 dark:text-white/60 hover:text-[#171717] dark:hover:text-white font-medium touch-manipulation active:scale-95 transition-transform py-1.5"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset Colors & Patterns</span>
          </button>

          <button
            type="button"
            onClick={onNavigateToCustomizer}
            className="inline-flex items-center gap-1 text-xs text-[#2563EB] dark:text-[#60a5fa] hover:underline font-semibold touch-manipulation active:scale-95 transition-transform py-1.5"
          >
            <span>Advanced Customizer</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
});

QRPreview.displayName = 'QRPreview';
