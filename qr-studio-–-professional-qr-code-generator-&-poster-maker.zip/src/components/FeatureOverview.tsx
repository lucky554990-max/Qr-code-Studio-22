import React, { memo } from 'react';
import { QrCode, Sliders, LayoutTemplate, ArrowRight } from 'lucide-react';

interface FeatureOverviewProps {
  onNavigateTab: (tab: 'generator' | 'customizer' | 'poster') => void;
}

export const FeatureOverview = memo<FeatureOverviewProps>(({ onNavigateTab }) => {
  return (
    <div className="space-y-16">
      {/* 3 Core Features */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#171717] dark:text-white tracking-tight">
            The Complete Professional QR Suite
          </h2>
          <p className="text-sm text-[#171717]/70 dark:text-white/70">
            Everything you need to encode, style, visualize in 3D, and publish production-grade
            barcodes for your brand.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div className="bg-white dark:bg-[#1a1a1a] border border-[#171717]/15 dark:border-white/10 rounded-2xl p-6 shadow-sm hover:border-[#2563EB] transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#171717] dark:bg-white text-white dark:text-[#171717] flex items-center justify-center group-hover:bg-[#2563EB] group-hover:text-white dark:group-hover:bg-[#2563EB] dark:group-hover:text-white transition-colors">
                <QrCode className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-[#171717] dark:text-white">QR Code Generator</h3>
                <p className="text-xs text-[#171717]/70 dark:text-white/70 mt-1.5 leading-relaxed">
                  Generate instant, error-corrected QR codes across 9 business modes: URLs, Wi-Fi, vCard 3.0 contacts,
                  WhatsApp, Email, SMS, UPI payments, and Batch generation.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('generator')}
              className="mt-6 inline-flex items-center gap-1.5 text-xs font-bold text-[#2563EB] group-hover:underline"
            >
              <span>Open Generator</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 2 */}
          <div className="bg-white dark:bg-[#1a1a1a] border border-[#171717]/15 dark:border-white/10 rounded-2xl p-6 shadow-sm hover:border-[#2563EB] transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#171717] dark:bg-white text-white dark:text-[#171717] flex items-center justify-center group-hover:bg-[#2563EB] group-hover:text-white dark:group-hover:bg-[#2563EB] dark:group-hover:text-white transition-colors">
                <Sliders className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-[#171717] dark:text-white">QR Code Customizer</h3>
                <p className="text-xs text-[#171717]/70 dark:text-white/70 mt-1.5 leading-relaxed">
                  Real-time WCAG contrast analyzer with One-Click Auto-Fix, curated brand social icons,
                  module shapes, corner dots, custom logo uploads, and call-to-action frames.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('customizer')}
              className="mt-6 inline-flex items-center gap-1.5 text-xs font-bold text-[#2563EB] group-hover:underline"
            >
              <span>Explore Customizer</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 3 */}
          <div className="bg-white dark:bg-[#1a1a1a] border border-[#171717]/15 dark:border-white/10 rounded-2xl p-6 shadow-sm hover:border-[#2563EB] transition-all flex flex-col justify-between group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#171717] dark:bg-white text-white dark:text-[#171717] flex items-center justify-center group-hover:bg-[#2563EB] group-hover:text-white dark:group-hover:bg-[#2563EB] dark:group-hover:text-white transition-colors">
                <LayoutTemplate className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-[#171717] dark:text-white">QR Poster Maker</h3>
                <p className="text-xs text-[#171717]/70 dark:text-white/70 mt-1.5 leading-relaxed">
                  Design promotional table tents, store flyers, digital menus, and business signs
                  with standard paper sizes (A4, Letter, Business Card) and live QR code embeddings.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('poster')}
              className="mt-6 inline-flex items-center gap-1.5 text-xs font-bold text-[#2563EB] group-hover:underline"
            >
              <span>Launch Poster Studio</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* How It Works (3 Steps) */}
      <section id="guide" className="p-8 sm:p-10 bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/10 dark:border-white/10 rounded-2xl space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#171717] dark:text-white tracking-tight">
            How It Works
          </h3>
          <p className="text-xs text-[#171717]/60 dark:text-white/60">
            A three-step workflow engineered for rapid business deployment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          {/* Step 1 */}
          <div className="bg-white dark:bg-[#1f1f1f] p-5 rounded-xl border border-[#171717]/10 dark:border-white/10 space-y-3">
            <div className="w-7 h-7 rounded-full bg-[#171717] dark:bg-white text-white dark:text-[#171717] flex items-center justify-center text-xs font-bold font-mono">
              1
            </div>
            <h4 className="text-sm font-bold text-[#171717] dark:text-white">Choose Your Format</h4>
            <p className="text-xs text-[#171717]/70 dark:text-white/70 leading-relaxed">
              Select from URLs, Wi-Fi, vCard 3.0 contacts, WhatsApp, Email, SMS, UPI payments, or
              batch lists. Everything is encoded locally in your browser.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-white dark:bg-[#1f1f1f] p-5 rounded-xl border border-[#171717]/10 dark:border-white/10 space-y-3">
            <div className="w-7 h-7 rounded-full bg-[#2563EB] text-white flex items-center justify-center text-xs font-bold font-mono">
              2
            </div>
            <h4 className="text-sm font-bold text-[#171717] dark:text-white">Customize & Auto-Check</h4>
            <p className="text-xs text-[#171717]/70 dark:text-white/70 leading-relaxed">
              Pick brand colors, check scannability contrast with 1-click Auto-Fix, apply social brand
              icons, and preview on a realistic 3D acrylic display stand.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-white dark:bg-[#1f1f1f] p-5 rounded-xl border border-[#171717]/10 dark:border-white/10 space-y-3">
            <div className="w-7 h-7 rounded-full bg-[#171717] dark:bg-white text-white dark:text-[#171717] flex items-center justify-center text-xs font-bold font-mono">
              3
            </div>
            <h4 className="text-sm font-bold text-[#171717] dark:text-white">Download & Deploy</h4>
            <p className="text-xs text-[#171717]/70 dark:text-white/70 leading-relaxed">
              Export in scalable vector SVG for commercial printing or high-DPI PNG/JPEG. Download
              bulk batches in a single ZIP file or build promotional flyers in the Poster Maker.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
});

FeatureOverview.displayName = 'FeatureOverview';
