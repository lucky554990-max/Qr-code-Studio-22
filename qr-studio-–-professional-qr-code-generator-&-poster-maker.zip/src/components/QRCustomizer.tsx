import React, { useRef, memo } from 'react';
import {
  Palette,
  Grid,
  Upload,
  Trash2,
  Tag,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import {
  QRConfig,
  DotPattern,
  CornerSquarePattern,
  CornerDotPattern,
} from '../types/qr';
import { ContrastResult } from '../utils/contrast';
import { BRAND_ICON_PRESETS, BrandIconPreset } from '../utils/brandIcons';

interface QRCustomizerProps {
  config: QRConfig;
  contrastResult: ContrastResult;
  onUpdateConfig: (patch: Partial<QRConfig>) => void;
  onAutoFixContrast: () => void;
  onApplyBrandIcon: (preset: BrandIconPreset) => void;
  onLogoUpload: (file: File) => void;
  onRemoveLogo: () => void;
  onResetCustomization: () => void;
}

export const QRCustomizer: React.FC<QRCustomizerProps> = memo(({
  config,
  contrastResult,
  onUpdateConfig,
  onAutoFixContrast,
  onApplyBrandIcon,
  onLogoUpload,
  onRemoveLogo,
  onResetCustomization,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const dotPatterns: { id: DotPattern; label: string }[] = [
    { id: 'square', label: 'Square' },
    { id: 'rounded', label: 'Rounded' },
    { id: 'dots', label: 'Dots' },
    { id: 'classy', label: 'Classy' },
    { id: 'classy-rounded', label: 'Classy Rounded' },
    { id: 'extra-rounded', label: 'Extra Rounded' },
  ];

  const cornerSquares: { id: CornerSquarePattern; label: string }[] = [
    { id: 'square', label: 'Standard Square' },
    { id: 'dot', label: 'Round Corner' },
    { id: 'extra-rounded', label: 'Extra Curved' },
  ];

  const cornerDots: { id: CornerDotPattern; label: string }[] = [
    { id: 'square', label: 'Square Dot' },
    { id: 'dot', label: 'Circle Dot' },
  ];

  const framePresets = ['SCAN ME', 'SCAN TO VISIT', 'OPEN MENU', 'CONNECT WI-FI', 'PAY HERE'];

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        onLogoUpload(file);
      } catch (err: unknown) {
        console.error(err);
      }
    }
  };

  return (
    <div className="bg-white dark:bg-[#1a1a1a] border border-[#171717]/15 dark:border-white/10 rounded-2xl p-5 sm:p-7 shadow-sm space-y-8 transition-colors">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-[#171717]/10 dark:border-white/10">
        <div>
          <h2 className="text-xl font-bold text-[#171717] dark:text-white tracking-tight">
            Design & Styling Studio
          </h2>
          <p className="text-xs text-[#171717]/60 dark:text-white/60 mt-0.5">
            Configure custom colors, module shapes, embedded brand icons, and call-to-action frames.
          </p>
        </div>
        <button
          type="button"
          onClick={onResetCustomization}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg border border-[#171717]/10 dark:border-white/10 transition-colors font-medium touch-manipulation"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Styles</span>
        </button>
      </div>

      {/* SECTION 1: Colors & Contrast Checker */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-[#2563EB]" />
            <h3 className="text-sm font-bold text-[#171717] dark:text-white uppercase tracking-wider">
              1. QR Code Colors & Scannability
            </h3>
          </div>

          {/* Contrast Quality Indicator */}
          <div className="flex items-center gap-2">
            <span
              className={`text-xs px-2.5 py-1 rounded-full font-mono font-semibold flex items-center gap-1 ${
                contrastResult.isOptimal
                  ? 'bg-green-100 text-green-800 dark:bg-green-950/60 dark:text-green-300'
                  : contrastResult.isAdequate
                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                  : 'bg-red-100 text-red-800 dark:bg-red-950/60 dark:text-red-300'
              }`}
            >
              {contrastResult.isOptimal ? (
                <CheckCircle2 className="w-3.5 h-3.5" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5" />
              )}
              <span>{contrastResult.ratio.toFixed(1)}:1 Contrast</span>
            </span>
          </div>
        </div>

        {/* Contrast Warning & Auto-Fix Banner */}
        {(!contrastResult.isOptimal || contrastResult.warningMessage) && (
          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-800 dark:text-amber-300">
                {contrastResult.warningMessage || 'Suboptimal contrast. May scan slower in low-light environments.'}
              </p>
            </div>
            <button
              type="button"
              onClick={onAutoFixContrast}
              className="px-3 py-1.5 bg-[#171717] dark:bg-white text-white dark:text-[#171717] text-xs font-semibold rounded-lg shrink-0 flex items-center gap-1.5 hover:bg-black dark:hover:bg-gray-100 transition-all touch-manipulation active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Auto-Fix Contrast</span>
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Foreground Color */}
          <div className="p-4 rounded-xl border border-[#171717]/10 dark:border-white/10 bg-[#171717]/[0.01] dark:bg-white/[0.02] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#171717] dark:text-white">
                Foreground (QR Modules)
              </label>
              <button
                type="button"
                onClick={() => onUpdateConfig({ foregroundColor: '#171717' })}
                className="text-[10px] text-[#2563EB] hover:underline"
              >
                Reset Default
              </button>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={config.foregroundColor}
                onChange={(e) => onUpdateConfig({ foregroundColor: e.target.value })}
                className="w-10 h-10 rounded-lg cursor-pointer border border-[#171717]/20 dark:border-white/20 p-0.5 bg-white dark:bg-[#242424]"
              />
              <input
                type="text"
                value={config.foregroundColor}
                onChange={(e) => onUpdateConfig({ foregroundColor: e.target.value })}
                className="flex-1 px-3 py-2 text-xs font-mono uppercase border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
                maxLength={7}
              />
            </div>
          </div>

          {/* Background Color */}
          <div className="p-4 rounded-xl border border-[#171717]/10 dark:border-white/10 bg-[#171717]/[0.01] dark:bg-white/[0.02] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#171717] dark:text-white">
                Background Color
              </label>
              <button
                type="button"
                onClick={() => onUpdateConfig({ backgroundColor: '#FFFFFF' })}
                className="text-[10px] text-[#2563EB] hover:underline"
              >
                Reset Default
              </button>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={config.backgroundColor}
                onChange={(e) => onUpdateConfig({ backgroundColor: e.target.value })}
                className="w-10 h-10 rounded-lg cursor-pointer border border-[#171717]/20 dark:border-white/20 p-0.5 bg-white dark:bg-[#242424]"
              />
              <input
                type="text"
                value={config.backgroundColor}
                onChange={(e) => onUpdateConfig({ backgroundColor: e.target.value })}
                className="flex-1 px-3 py-2 text-xs font-mono uppercase border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
                maxLength={7}
              />
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: Patterns & Shapes */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Grid className="w-4 h-4 text-[#2563EB]" />
          <h3 className="text-sm font-bold text-[#171717] dark:text-white uppercase tracking-wider">
            2. Module Patterns & Eyes
          </h3>
        </div>

        {/* Module Shapes */}
        <div>
          <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-2">
            Module Shape
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {dotPatterns.map((pat) => (
              <button
                key={pat.id}
                type="button"
                onClick={() => onUpdateConfig({ dotType: pat.id })}
                className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                  config.dotType === pat.id
                    ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#2563EB] font-bold shadow-xs'
                    : 'border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] text-[#171717]/80 dark:text-white/80 hover:border-[#171717]/40 dark:hover:border-white/40'
                }`}
              >
                {pat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Corner Eyes Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-2">
              Corner Square Style
            </label>
            <div className="space-y-1.5">
              {cornerSquares.map((sq) => (
                <button
                  key={sq.id}
                  type="button"
                  onClick={() => onUpdateConfig({ cornerSquareType: sq.id })}
                  className={`w-full py-2 px-3 text-xs rounded-lg border text-left transition-all ${
                    config.cornerSquareType === sq.id
                      ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#2563EB] font-bold'
                      : 'border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] text-[#171717]/80 dark:text-white/80 hover:border-[#171717]/40 dark:hover:border-white/40'
                  }`}
                >
                  {sq.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-2">
              Corner Dot Style
            </label>
            <div className="space-y-1.5">
              {cornerDots.map((cd) => (
                <button
                  key={cd.id}
                  type="button"
                  onClick={() => onUpdateConfig({ cornerDotType: cd.id })}
                  className={`w-full py-2 px-3 text-xs rounded-lg border text-left transition-all ${
                    config.cornerDotType === cd.id
                      ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#2563EB] font-bold'
                      : 'border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] text-[#171717]/80 dark:text-white/80 hover:border-[#171717]/40 dark:hover:border-white/40'
                  }`}
                >
                  {cd.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: Built-in Brand Icons & Custom Upload */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Upload className="w-4 h-4 text-[#2563EB]" />
            <h3 className="text-sm font-bold text-[#171717] dark:text-white uppercase tracking-wider">
              3. Brand Logo & Social Icons
            </h3>
          </div>
          {config.logoUrl && (
            <button
              type="button"
              onClick={onRemoveLogo}
              className="inline-flex items-center gap-1 text-xs text-red-600 dark:text-red-400 hover:underline"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Remove Logo</span>
            </button>
          )}
        </div>

        {/* 1-Click Curated Presets Library */}
        <div>
          <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-2">
            Select Preset Icon (1-Click)
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {BRAND_ICON_PRESETS.map((icon) => (
              <button
                key={icon.id}
                type="button"
                onClick={() => onApplyBrandIcon(icon)}
                className="p-2 rounded-xl border border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] hover:border-[#2563EB] hover:bg-[#2563EB]/5 flex flex-col items-center gap-1.5 transition-all text-center touch-manipulation active:scale-95"
              >
                <img src={icon.svgDataUri} alt={icon.name} className="w-6 h-6 object-contain" />
                <span className="text-[10px] font-semibold text-[#171717] dark:text-white truncate max-w-full">
                  {icon.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/svg+xml,image/webp"
          className="hidden"
          onChange={handleFileInputChange}
        />

        {/* Custom Upload or Active Logo Adjustments */}
        {config.logoUrl ? (
          <div className="p-4 border border-[#171717]/15 dark:border-white/15 rounded-xl bg-[#171717]/[0.02] dark:bg-white/[0.02] flex flex-col sm:flex-row items-center gap-4">
            <div className="w-16 h-16 rounded-lg bg-white border border-[#171717]/15 p-1 flex items-center justify-center shrink-0">
              <img
                src={config.logoUrl}
                alt="Active logo"
                className="max-w-full max-h-full object-contain"
              />
            </div>
            <div className="flex-1 space-y-2 w-full">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-[#171717] dark:text-white">Logo Scale</span>
                <span className="font-mono text-[#171717]/60 dark:text-white/60">
                  {Math.round(config.logoSize * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="0.32"
                step="0.02"
                value={config.logoSize}
                onChange={(e) => onUpdateConfig({ logoSize: parseFloat(e.target.value) })}
                className="w-full accent-[#2563EB] cursor-pointer"
              />
              <p className="text-[11px] text-[#171717]/50 dark:text-white/50">
                Error correction automatically set to High (H) to safeguard camera scanning.
              </p>
            </div>
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-[#171717]/20 dark:border-white/20 hover:border-[#2563EB] rounded-xl p-5 text-center cursor-pointer transition-colors bg-[#171717]/[0.01] dark:bg-white/[0.01]"
          >
            <Upload className="w-7 h-7 text-[#171717]/40 dark:text-white/40 mx-auto mb-1.5" />
            <p className="text-xs font-semibold text-[#171717] dark:text-white">
              Or click to upload your custom brand logo
            </p>
            <p className="text-[11px] text-[#171717]/50 dark:text-white/50 mt-0.5">
              PNG, SVG, or JPEG up to 5MB (Processed client-side only)
            </p>
          </div>
        )}
      </section>

      {/* SECTION 4: Frame & Action Label */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-[#2563EB]" />
            <h3 className="text-sm font-bold text-[#171717] dark:text-white uppercase tracking-wider">
              4. Call-to-Action Frame & Label
            </h3>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={config.frame.enabled}
              onChange={(e) =>
                onUpdateConfig({
                  frame: { ...config.frame, enabled: e.target.checked },
                })
              }
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-[#171717]/20 dark:bg-white/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#171717]/30 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#2563EB]"></div>
            <span className="ml-2 text-xs font-semibold text-[#171717] dark:text-white">
              {config.frame.enabled ? 'Enabled' : 'Disabled'}
            </span>
          </label>
        </div>

        {config.frame.enabled && (
          <div className="p-4 border border-[#171717]/15 dark:border-white/15 rounded-xl bg-[#171717]/[0.01] dark:bg-white/[0.01] space-y-4">
            {/* Label Text Input */}
            <div>
              <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                Banner Text
              </label>
              <input
                type="text"
                value={config.frame.text}
                onChange={(e) =>
                  onUpdateConfig({
                    frame: { ...config.frame, text: e.target.value },
                  })
                }
                placeholder="SCAN ME"
                maxLength={30}
                className="w-full px-3 py-2 text-xs uppercase font-bold tracking-wider border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
              />
              <div className="flex flex-wrap gap-1.5 mt-2">
                {framePresets.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() =>
                      onUpdateConfig({
                        frame: { ...config.frame, text: preset },
                      })
                    }
                    className="px-2 py-0.5 text-[10px] bg-white dark:bg-[#242424] border border-[#171717]/20 dark:border-white/20 hover:border-[#2563EB] rounded text-[#171717]/70 dark:text-white/70 font-semibold"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Frame Style */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(
                [
                  { id: 'bottom-banner', label: 'Bottom Banner' },
                  { id: 'top-banner', label: 'Top Banner' },
                  { id: 'badge', label: 'Centered Badge' },
                  { id: 'card', label: 'Full Card' },
                ] as const
              ).map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() =>
                    onUpdateConfig({
                      frame: { ...config.frame, style: st.id },
                    })
                  }
                  className={`py-2 px-2 text-xs rounded-lg border text-center transition-all ${
                    config.frame.style === st.id
                      ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#2563EB] font-bold'
                      : 'border-[#171717]/15 dark:border-white/15 bg-white dark:bg-[#242424] text-[#171717]/80 dark:text-white/80 hover:border-[#171717]/40 dark:hover:border-white/40'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>

            {/* Frame & Text Colors */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div>
                <label className="text-[11px] font-semibold text-[#171717] dark:text-white block mb-1">
                  Frame Color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.frame.frameColor}
                    onChange={(e) =>
                      onUpdateConfig({
                        frame: { ...config.frame, frameColor: e.target.value },
                      })
                    }
                    className="w-8 h-8 rounded border border-[#171717]/20 dark:border-white/20 p-0.5 cursor-pointer bg-white dark:bg-[#242424]"
                  />
                  <input
                    type="text"
                    value={config.frame.frameColor}
                    onChange={(e) =>
                      onUpdateConfig({
                        frame: { ...config.frame, frameColor: e.target.value },
                      })
                    }
                    className="w-24 px-2 py-1 text-xs font-mono uppercase border border-[#171717]/20 dark:border-white/20 rounded bg-white dark:bg-[#242424] text-[#171717] dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-[#171717] dark:text-white block mb-1">
                  Text Color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.frame.textColor}
                    onChange={(e) =>
                      onUpdateConfig({
                        frame: { ...config.frame, textColor: e.target.value },
                      })
                    }
                    className="w-8 h-8 rounded border border-[#171717]/20 dark:border-white/20 p-0.5 cursor-pointer bg-white dark:bg-[#242424]"
                  />
                  <input
                    type="text"
                    value={config.frame.textColor}
                    onChange={(e) =>
                      onUpdateConfig({
                        frame: { ...config.frame, textColor: e.target.value },
                      })
                    }
                    className="w-24 px-2 py-1 text-xs font-mono uppercase border border-[#171717]/20 dark:border-white/20 rounded bg-white dark:bg-[#242424] text-[#171717] dark:text-white"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
});

QRCustomizer.displayName = 'QRCustomizer';
