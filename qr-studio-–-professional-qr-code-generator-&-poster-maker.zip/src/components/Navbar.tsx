import React, { useState, memo } from 'react';
import { Menu, X, QrCode, Sun, Moon, BookOpen } from 'lucide-react';
import { Theme } from '../hooks/useTheme';
import { ModalType } from './InfoModals';

export type NavTab = 'generator' | 'customizer' | 'showcase' | 'poster' | 'guide' | 'articles';

interface NavbarProps {
  activeTab: NavTab;
  theme: Theme;
  onToggleTheme: () => void;
  onSelectTab: (tab: NavTab) => void;
  onOpenModal: (modal: ModalType) => void;
}

export const Navbar = memo<NavbarProps>(({
  activeTab,
  theme,
  onToggleTheme,
  onSelectTab,
  onOpenModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (tab: NavTab) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
    if (tab !== 'articles') {
      const element = document.getElementById(tab);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#171717]/95 border-b border-[#171717]/10 dark:border-white/10 backdrop-blur-sm transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <button
          type="button"
          onClick={() => handleNavClick('generator')}
          className="flex items-center gap-2.5 text-left focus:outline-none focus:ring-2 focus:ring-[#2563EB] rounded-lg p-1 touch-manipulation active:scale-95"
        >
          <div className="w-9 h-9 rounded-lg bg-[#171717] dark:bg-white flex items-center justify-center text-white dark:text-[#171717] shadow-sm">
            <QrCode className="w-5 h-5 text-white dark:text-[#171717]" />
          </div>
          <div>
            <span className="font-bold text-lg tracking-tight text-[#171717] dark:text-white block leading-none">
              QR Studio
            </span>
            <span className="text-[10px] text-[#171717]/50 dark:text-white/50 font-mono tracking-wider uppercase block mt-0.5">
              Professional Suite
            </span>
          </div>
        </button>

        {/* Center Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1 bg-[#171717]/5 dark:bg-white/5 p-1 rounded-xl border border-[#171717]/10 dark:border-white/10">
          <button
            type="button"
            onClick={() => handleNavClick('generator')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'generator'
                ? 'bg-white dark:bg-[#252525] text-[#171717] dark:text-white shadow-xs font-semibold'
                : 'text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-white/50 dark:hover:bg-white/10'
            }`}
          >
            QR Generator
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('customizer')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'customizer'
                ? 'bg-white dark:bg-[#252525] text-[#171717] dark:text-white shadow-xs font-semibold'
                : 'text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-white/50 dark:hover:bg-white/10'
            }`}
          >
            Customize
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('showcase')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'showcase'
                ? 'bg-white dark:bg-[#252525] text-[#171717] dark:text-white shadow-xs font-semibold'
                : 'text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-white/50 dark:hover:bg-white/10'
            }`}
          >
            3D Mockup
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('poster')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'poster'
                ? 'bg-white dark:bg-[#252525] text-[#171717] dark:text-white shadow-xs font-semibold'
                : 'text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-white/50 dark:hover:bg-white/10'
            }`}
          >
            Poster Maker
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('guide')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'guide'
                ? 'bg-white dark:bg-[#252525] text-[#171717] dark:text-white shadow-xs font-semibold'
                : 'text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-white/50 dark:hover:bg-white/10'
            }`}
          >
            How It Works
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('articles')}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
              activeTab === 'articles'
                ? 'bg-white dark:bg-[#252525] text-[#2563EB] dark:text-[#60a5fa] shadow-xs font-semibold'
                : 'text-[#171717]/70 dark:text-white/70 hover:text-[#171717] dark:hover:text-white hover:bg-white/50 dark:hover:bg-white/10'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>Guides</span>
          </button>
        </nav>

        {/* Right Controls: Theme Toggle & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Theme Toggle Button */}
          <button
            type="button"
            onClick={onToggleTheme}
            className="p-2 rounded-xl border border-[#171717]/10 dark:border-white/15 bg-[#171717]/5 dark:bg-white/5 text-[#171717] dark:text-white hover:bg-[#171717]/10 dark:hover:bg-white/10 transition-all touch-manipulation active:scale-90"
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
            aria-label="Toggle color theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-[#171717]" />
            )}
          </button>

          <button
            type="button"
            onClick={() => onOpenModal('static-vs-dynamic')}
            className="hidden sm:inline-block text-xs text-[#171717]/70 dark:text-white/70 hover:text-[#2563EB] dark:hover:text-[#3b82f6] font-medium transition-colors"
          >
            Static vs Dynamic
          </button>

          <button
            type="button"
            onClick={() => handleNavClick('generator')}
            className="hidden sm:inline-flex px-4 py-2 bg-[#2563EB] hover:bg-[#1d4ed8] text-white rounded-lg text-sm font-semibold shadow-xs transition-colors focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-2 touch-manipulation active:scale-95"
          >
            Create QR Code
          </button>

          {/* Mobile Hamburger Button */}
          <div className="flex lg:hidden items-center">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#171717] dark:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg touch-manipulation"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-[#171717]/10 dark:border-white/10 bg-white dark:bg-[#1a1a1a] px-4 pt-2 pb-6 space-y-2">
          <button
            type="button"
            onClick={() => handleNavClick('generator')}
            className="w-full text-left px-3 py-2 text-sm font-medium text-[#171717] dark:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg"
          >
            QR Generator (9 Modes)
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('customizer')}
            className="w-full text-left px-3 py-2 text-sm font-medium text-[#171717] dark:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg"
          >
            Customize QR Code
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('showcase')}
            className="w-full text-left px-3 py-2 text-sm font-medium text-[#171717] dark:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg"
          >
            3D Display Stand
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('poster')}
            className="w-full text-left px-3 py-2 text-sm font-medium text-[#171717] dark:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg"
          >
            Poster Maker
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('guide')}
            className="w-full text-left px-3 py-2 text-sm font-medium text-[#171717] dark:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg"
          >
            How It Works (3 Steps)
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('articles')}
            className="w-full text-left px-3 py-2 text-sm font-semibold text-[#2563EB] dark:text-[#60a5fa] hover:bg-[#2563EB]/10 rounded-lg flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4" />
            <span>Guides & Knowledge Base</span>
          </button>
          <div className="pt-2 border-t border-[#171717]/10 dark:border-white/10 flex flex-col gap-2">
            <button
              type="button"
              onClick={() => {
                onOpenModal('static-vs-dynamic');
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-1.5 text-xs text-[#2563EB] font-medium"
            >
              Static vs Dynamic Guide
            </button>
            <button
              type="button"
              onClick={() => {
                onOpenModal('contact');
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-1.5 text-xs text-[#171717]/70 dark:text-white/70 hover:text-[#2563EB]"
            >
              Contact Support
            </button>
            <button
              type="button"
              onClick={() => handleNavClick('generator')}
              className="w-full py-2.5 bg-[#2563EB] text-white text-center rounded-lg text-sm font-semibold"
            >
              Create QR Code
            </button>
          </div>
        </div>
      )}
    </header>
  );
});

Navbar.displayName = 'Navbar';
