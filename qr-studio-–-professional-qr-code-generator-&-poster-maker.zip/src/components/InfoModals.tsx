import React, { useState, memo } from 'react';
import {
  X,
  Shield,
  Info,
  Mail,
  Send,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Lock,
  Compass,
} from 'lucide-react';

export type ModalType =
  | 'about'
  | 'contact'
  | 'privacy'
  | 'terms'
  | 'disclaimer'
  | 'static-vs-dynamic'
  | null;

interface InfoModalsProps {
  activeModal: ModalType;
  onClose: () => void;
  onNavigateToGuides?: () => void;
}

export const InfoModals = memo<InfoModalsProps>(({
  activeModal,
  onClose,
  onNavigateToGuides,
}) => {
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('General Feedback');
  const [contactMessage, setContactMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  if (!activeModal) return null;

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactEmail.trim() || !contactMessage.trim()) {
      setErrorMessage('Please fill out all required fields.');
      return;
    }
    // Basic email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(contactEmail.trim())) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    setErrorMessage('');
    // Store message locally in browser storage so inquiry is genuinely registered
    try {
      const existingInquiries = JSON.parse(
        localStorage.getItem('qr_studio_inquiries') || '[]'
      );
      existingInquiries.push({
        id: `inq_${Date.now()}`,
        name: contactName.trim(),
        email: contactEmail.trim(),
        subject: contactSubject,
        message: contactMessage.trim(),
        submittedAt: new Date().toISOString(),
      });
      localStorage.setItem(
        'qr_studio_inquiries',
        JSON.stringify(existingInquiries)
      );
    } catch {
      // Local storage full or private mode
    }

    setContactSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl max-h-[88vh] bg-white dark:bg-[#1a1a1a] border border-[#171717]/20 dark:border-white/20 rounded-2xl shadow-2xl overflow-hidden flex flex-col transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#171717]/10 dark:border-white/10 bg-white dark:bg-[#1a1a1a]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#171717] dark:bg-white flex items-center justify-center text-white dark:text-[#171717]">
              {activeModal === 'privacy' ? (
                <Shield className="w-4 h-4 text-[#2563EB]" />
              ) : activeModal === 'contact' ? (
                <Mail className="w-4 h-4 text-[#2563EB]" />
              ) : activeModal === 'disclaimer' ? (
                <AlertTriangle className="w-4 h-4 text-[#2563EB]" />
              ) : activeModal === 'terms' ? (
                <FileText className="w-4 h-4 text-[#2563EB]" />
              ) : (
                <Info className="w-4 h-4 text-[#2563EB]" />
              )}
            </div>
            <h3 className="text-lg font-bold text-[#171717] dark:text-white">
              {activeModal === 'about' && 'About Us — QR Studio'}
              {activeModal === 'contact' && 'Contact Us — Support & Feedback'}
              {activeModal === 'privacy' && 'Privacy Policy'}
              {activeModal === 'terms' && 'Terms and Conditions'}
              {activeModal === 'disclaimer' && 'Legal & Quality Disclaimer'}
              {activeModal === 'static-vs-dynamic' && 'Static vs Dynamic Barcodes'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#171717]/50 dark:text-white/50 hover:text-[#171717] dark:hover:text-white hover:bg-[#171717]/5 dark:hover:bg-white/5 rounded-lg transition-colors touch-manipulation"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Scrollable Area */}
        <div className="px-6 py-6 overflow-y-auto space-y-5 text-sm text-[#171717]/80 dark:text-white/80 leading-relaxed">
          {/* 1. ABOUT US */}
          {activeModal === 'about' && (
            <div className="space-y-4">
              <div>
                <h4 className="font-bold text-base text-[#171717] dark:text-white mb-1.5">
                  What QR Studio Does
                </h4>
                <p className="text-xs sm:text-sm text-[#171717]/80 dark:text-white/80">
                  QR Studio is a dedicated web application engineered to generate, customize, preview,
                  and export production-grade Quick Response (QR) codes and promotional signage. The
                  platform operates with a client-side architecture where all mathematical matrix
                  computations execute directly within your browser.
                </p>
              </div>

              <div className="p-4 bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/10 dark:border-white/10 rounded-xl space-y-2">
                <h5 className="font-bold text-xs uppercase tracking-wider text-[#171717] dark:text-white">
                  Actual Implemented Features
                </h5>
                <ul className="list-disc pl-5 space-y-1.5 text-xs">
                  <li>
                    <strong>9 QR Generation Modes:</strong> Fully encodes Website URLs, Plain Text,
                    Wi-Fi networks (SSID/Password/WPA), vCard 3.0 contact cards, WhatsApp direct chat,
                    Email (`mailto:`), SMS, UPI Payments, and multi-line Batch Generation.
                  </li>
                  <li>
                    <strong>Client-Side Privacy:</strong> Zero database storage of user payloads, Wi-Fi
                    passwords, or contact books.
                  </li>
                  <li>
                    <strong>Real-Time WCAG Contrast Analyzer:</strong> Computes optical luminance ratios
                    and provides 1-click Auto-Fix to ensure camera readability.
                  </li>
                  <li>
                    <strong>Vector & Raster Exports:</strong> Clean SVG vectors for commercial print
                    presses, plus 1200px PNG and JPEG formats.
                  </li>
                  <li>
                    <strong>Interactive 3D Physical Display Studio:</strong> Procedural 3D acrylic
                    stands, counter kiosks, and walnut wood blocks rendered via Three.js.
                  </li>
                  <li>
                    <strong>Promotional Poster Maker:</strong> Printable flyer templates calibrated to
                    A4, US Letter, and standard 3.5×2-inch Business Cards.
                  </li>
                </ul>
              </div>

              <div>
                <h5 className="font-bold text-xs uppercase tracking-wider text-[#171717] dark:text-white mb-1">
                  Our Purpose
                </h5>
                <p className="text-xs text-[#171717]/70 dark:text-white/70">
                  To provide businesses, educators, retailers, and individuals with honest, permanent,
                  royalty-free barcodes without forced paywalls, mandatory user accounts, or predatory
                  redirect links.
                </p>
              </div>
            </div>
          )}

          {/* 2. CONTACT US */}
          {activeModal === 'contact' && (
            <div className="space-y-4">
              {contactSubmitted ? (
                <div className="p-6 text-center space-y-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 rounded-xl">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 dark:text-emerald-400 mx-auto" />
                  <h4 className="text-base font-bold text-emerald-900 dark:text-emerald-200">
                    Message Received & Logged Locally
                  </h4>
                  <p className="text-xs text-emerald-700 dark:text-emerald-300">
                    Thank you, {contactName}. Your inquiry has been stored locally in your browser
                    session under reference ID{' '}
                    <code className="font-mono text-[11px] font-semibold">inq_{Date.now()}</code>.
                    For direct administrator support, you may also reach the maintainer at the email
                    address below.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setContactSubmitted(false);
                      setContactMessage('');
                    }}
                    className="mt-2 text-xs font-semibold text-[#2563EB] dark:text-[#60a5fa] hover:underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <p className="text-xs text-[#171717]/70 dark:text-white/70">
                    Have questions regarding QR code formatting, poster dimensions, or technical
                    compatibility? Submit your message below or email our team directly.
                  </p>

                  <div className="p-3 bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/10 dark:border-white/10 rounded-xl text-xs space-y-1">
                    <span className="font-bold text-[#171717] dark:text-white block">
                      Direct Email Contact:
                    </span>
                    <a
                      href="mailto:contact@qrstudio.app"
                      className="text-[#2563EB] dark:text-[#60a5fa] font-mono hover:underline block"
                    >
                      contact@qrstudio.app
                    </a>
                    <span className="text-[11px] text-[#171717]/50 dark:text-white/50 block">
                      Typical response window: 1–2 business days.
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        placeholder="Your name"
                        className="w-full px-3 py-2 text-xs border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="w-full px-3 py-2 text-xs border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                      Inquiry Subject
                    </label>
                    <select
                      value={contactSubject}
                      onChange={(e) => setContactSubject(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
                    >
                      <option value="General Feedback">General Feedback</option>
                      <option value="Technical Support">Technical Support / Bug Report</option>
                      <option value="Commercial Print Advice">Commercial Print / Sizing Advice</option>
                      <option value="Privacy Question">Privacy & Data Handling Inquiry</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-[#171717] dark:text-white block mb-1">
                      Message Content *
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder="Please describe your question or feedback..."
                      className="w-full px-3 py-2 text-xs border border-[#171717]/20 dark:border-white/20 rounded-lg bg-white dark:bg-[#242424] text-[#171717] dark:text-white focus:ring-1 focus:ring-[#2563EB]"
                    />
                  </div>

                  {errorMessage && (
                    <p className="text-xs text-red-600 dark:text-red-400 font-medium">
                      {errorMessage}
                    </p>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors touch-manipulation active:scale-95"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Contact Form</span>
                  </button>
                </form>
              )}
            </div>
          )}

          {/* 3. PRIVACY POLICY */}
          {activeModal === 'privacy' && (
            <div className="space-y-4 text-xs sm:text-sm">
              <p className="text-xs text-[#171717]/60 dark:text-white/60 font-mono">
                Last Updated: November 6, 2026
              </p>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  1. Information We Do Not Collect
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  QR Studio operates on a client-side architecture. When you enter URLs, plain text,
                  Wi-Fi network passwords, contact details (vCard), WhatsApp numbers, or UPI strings,
                  these are encoded into QR matrix pixels directly inside your web browser. This
                  information is never sent to, processed by, or logged on any remote server.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  2. Local Image Uploads
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  Images uploaded for QR code logos or poster backgrounds are handled using browser
                  Object URLs (<code className="font-mono text-[11px]">blob:</code>). They reside
                  only in your computer’s temporary memory and are permanently revoked upon tab close
                  or refresh.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  3. Cookies and Local Storage
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  QR Studio uses browser <code className="font-mono text-[11px]">localStorage</code>{' '}
                  strictly to persist your preferred color theme (<code className="font-mono text-[11px]">qr_theme</code>)
                  and locally saved contact inquiries. We do not use third-party tracking cookies or
                  fingerprinting scripts by default.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  4. Google AdSense & Analytics Disclosure (Status: Planned / Pre-Approval)
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  At this time, live advertising and commercial tracking scripts are <strong>disabled</strong>{' '}
                  in QR Studio (ADS_ENABLED = false). When Google AdSense is officially enabled by the
                  publisher upon account approval:
                </p>
                <ul className="list-disc pl-5 space-y-1 mt-1 text-xs text-[#171717]/70 dark:text-white/70">
                  <li>
                    Google, as a third-party vendor, uses cookies to serve ads on this website.
                  </li>
                  <li>
                    Google’s use of advertising cookies enables it and its partners to serve ads to
                    users based on visits to this site and/or other sites on the Internet.
                  </li>
                  <li>
                    Users may opt out of personalized advertising by visiting{' '}
                    <a
                      href="https://www.google.com/settings/ads"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#2563EB] dark:text-[#60a5fa] underline"
                    >
                      Google Ads Settings
                    </a>.
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  5. Contacting Us Regarding Privacy
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  For questions or requests concerning your privacy rights, email{' '}
                  <a
                    href="mailto:contact@qrstudio.app"
                    className="text-[#2563EB] dark:text-[#60a5fa] font-mono hover:underline"
                  >
                    contact@qrstudio.app
                  </a>.
                </p>
              </div>
            </div>
          )}

          {/* 4. TERMS AND CONDITIONS */}
          {activeModal === 'terms' && (
            <div className="space-y-4 text-xs sm:text-sm">
              <p className="text-xs text-[#171717]/60 dark:text-white/60 font-mono">
                Effective Date: November 6, 2026
              </p>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  1. Acceptance of Terms
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  By accessing and using QR Studio, you agree to comply with and be bound by these
                  Terms and Conditions. If you do not agree, you must discontinue use immediately.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  2. Permitted Commercial and Personal Use
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  All QR codes, SVG vector graphics, PNG raster images, and promotional poster designs
                  generated through QR Studio are 100% royalty-free. You may use, reproduce, and
                  distribute them on physical merchandise, restaurant menus, product packaging, and
                  digital marketing channels without attribution or license fees.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  3. Prohibited Conduct
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  You agree not to use the service to encode malicious URLs, phishing portals
                  (quishing), malware downloaders, fraudulent payment schemes, or content that
                  infringes on third-party intellectual property rights.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  4. Intellectual Property of the Application
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  The interface design, source code, logos, and 3D simulation models of QR Studio
                  are protected by intellectual property laws. Users retain full ownership of their
                  own input content and exported barcode artwork.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  5. Limitation of Liability
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  In no event shall QR Studio or its operators be liable for any indirect, incidental,
                  or consequential damages resulting from unreadable printed barcodes, misdirected
                  links, or printing production expenses.
                </p>
              </div>
            </div>
          )}

          {/* 5. DISCLAIMER */}
          {activeModal === 'disclaimer' && (
            <div className="space-y-4 text-xs sm:text-sm">
              <div className="p-3.5 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-xl text-amber-900 dark:text-amber-200 space-y-1">
                <span className="font-bold text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  Mandatory Physical Pre-Print Verification
                </span>
                <p className="text-xs leading-relaxed">
                  You are solely responsible for testing and verifying generated QR codes on physical
                  smartphone cameras prior to mass commercial printing or packaging manufacturing.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  1. Optical and Environmental Factors
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  QR code scannability depends on external physical factors beyond software control,
                  including printer ink bleeding, surface glare (glossy lamination, curved bottles),
                  insufficient lighting, module color contrast, and camera lens focal limitations.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  2. No Guarantee of Uninterrupted Availability
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  QR Studio is provided on an &quot;AS IS&quot; and &quot;AS AVAILABLE&quot; basis
                  without warranties of any kind. While the application is designed to be resilient,
                  we do not guarantee uninterrupted, error-free uptime.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#171717] dark:text-white text-sm mb-1">
                  3. Destination URLs and Third-Party Links
                </h4>
                <p className="text-[#171717]/80 dark:text-white/80">
                  QR Studio encodes direct static text and URLs. We do not monitor, maintain, or
                  guarantee the contents or uptime of the websites or services you encode into the
                  barcodes.
                </p>
              </div>
            </div>
          )}

          {/* 6. STATIC VS DYNAMIC GUIDE */}
          {activeModal === 'static-vs-dynamic' && (
            <div className="space-y-4 text-xs sm:text-sm">
              <p className="text-xs text-[#171717]/70 dark:text-white/70">
                Understanding the architectural differences between static and dynamic QR codes
                ensures you make the right choice for your business collateral.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/40 dark:bg-emerald-950/30 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 dark:bg-emerald-400" />
                    <h5 className="font-bold text-emerald-950 dark:text-emerald-200 text-xs uppercase tracking-wider">
                      Static QR Codes (Active in QR Studio)
                    </h5>
                  </div>
                  <ul className="text-xs text-emerald-900 dark:text-emerald-300 space-y-1.5 list-disc pl-4">
                    <li>Encodes destination link, Wi-Fi credentials, or text directly into the pixels.</li>
                    <li>
                      <strong>Never expires:</strong> Works indefinitely as long as your destination exists.
                    </li>
                    <li>No middleman server, no monthly subscription fee, 100% private.</li>
                    <li>
                      <em>Limitation:</em> The encoded destination cannot be edited post-print without
                      reprinting a new code.
                    </li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl border border-[#171717]/20 dark:border-white/20 bg-[#171717]/[0.02] dark:bg-white/[0.02] space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]" />
                    <h5 className="font-bold text-[#171717] dark:text-white text-xs uppercase tracking-wider">
                      Dynamic QR Codes (Overview)
                    </h5>
                  </div>
                  <ul className="text-xs text-[#171717]/80 dark:text-white/80 space-y-1.5 list-disc pl-4">
                    <li>Encodes an intermediary redirect link hosted on a third-party server.</li>
                    <li>Allows changing destination URL after printing.</li>
                    <li>
                      <strong>Dependency Risk:</strong> If the hosting service lapses or is cancelled,
                      all printed barcodes fail permanently.
                    </li>
                    <li>We do not display simulated or fake click analytics.</li>
                  </ul>
                </div>
              </div>

              {onNavigateToGuides && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onNavigateToGuides();
                    }}
                    className="text-xs text-[#2563EB] dark:text-[#60a5fa] font-semibold hover:underline inline-flex items-center gap-1"
                  >
                    <Compass className="w-3.5 h-3.5" />
                    <span>Browse our in-depth QR code technical guides</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-[#171717]/10 dark:border-white/10 bg-[#171717]/[0.02] dark:bg-white/[0.02] flex items-center justify-between">
          <span className="text-[11px] text-[#171717]/50 dark:text-white/50 font-mono">
            QR Studio • Legal & Trust Center
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-[#171717] dark:bg-white text-white dark:text-[#171717] hover:bg-[#2563EB] dark:hover:bg-gray-100 active:scale-95 text-xs font-semibold rounded-lg transition-all touch-manipulation min-h-[36px]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
});

InfoModals.displayName = 'InfoModals';
