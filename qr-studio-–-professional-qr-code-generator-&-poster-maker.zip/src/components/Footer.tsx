import React, { memo } from 'react';
import { QrCode, ShieldCheck, Sun, Moon, BookOpen } from 'lucide-react';
import { AdSlot } from './AdSlot';
import { Theme } from '../hooks/useTheme';
import { ModalType } from './InfoModals';

interface FooterProps {
  theme?: Theme;
  onToggleTheme?: () => void;
  onOpenModal: (modal: ModalType) => void;
  onNavigateTab: (tab: 'generator' | 'customizer' | 'showcase' | 'poster' | 'guide') => void;
  onOpenGuides?: () => void;
}

export const Footer = memo<FooterProps>(({
  theme,
  onToggleTheme,
  onOpenModal,
  onNavigateTab,
  onOpenGuides,
}) => {
  return (
    <footer className="bg-[#171717] dark:bg-[#0d0d0d] text-white pt-12 pb-16 mt-20 border-t border-[#171717] dark:border-white/10 transition-colors">
      {/* Pre-Footer Reserved Advertisement Space */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <AdSlot placement="footer_top" showDevPlaceholder={false} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-white/10">
          {/* Brand Column */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-[#171717]">
                <QrCode className="w-5 h-5 text-[#171717]" />
              </div>
              <span className="font-bold text-lg tracking-tight text-white">QR Studio</span>
            </div>
            <p className="text-xs text-white/60 max-w-sm leading-relaxed">
              Professional client-side QR code generator, interactive 3D physical display simulator,
              and promotional poster designer. Zero server logging, 100% royalty-free commercial exports.
            </p>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <div className="inline-flex items-center gap-2 text-xs text-white/70">
                <ShieldCheck className="w-4 h-4 text-[#2563EB]" />
                <span>Private in-browser generation</span>
              </div>
              {onToggleTheme && (
                <button
                  type="button"
                  onClick={onToggleTheme}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg border border-white/20 text-white/80 hover:text-white hover:bg-white/10 transition-colors"
                >
                  {theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5" />}
                  <span>{theme === 'dark' ? 'Light Theme' : 'Dark Theme'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Product Navigation */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white/40 font-mono">
              Product Suite
            </h4>
            <ul className="space-y-2 text-xs text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigateTab('generator')}
                  className="hover:text-white transition-colors text-left"
                >
                  QR Code Generator (9 Modes)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigateTab('customizer')}
                  className="hover:text-white transition-colors text-left"
                >
                  Color & Module Customizer
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigateTab('showcase')}
                  className="hover:text-white transition-colors text-left"
                >
                  3D Display Stand Mockups
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigateTab('poster')}
                  className="hover:text-white transition-colors text-left"
                >
                  Promotional Poster Maker
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenModal('static-vs-dynamic')}
                  className="hover:text-white transition-colors text-left"
                >
                  Static vs Dynamic Guide
                </button>
              </li>
            </ul>
          </div>

          {/* Guides / Educational Articles */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white/40 font-mono">
              Guides & Tutorials
            </h4>
            <ul className="space-y-2 text-xs text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenGuides) onOpenGuides();
                    else onNavigateTab('guide');
                  }}
                  className="hover:text-white transition-colors text-left flex items-center gap-1.5"
                >
                  <BookOpen className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span>Knowledge Base</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigateTab('guide')}
                  className="hover:text-white transition-colors text-left"
                >
                  How It Works (3 Steps)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenGuides) onOpenGuides();
                    else onNavigateTab('guide');
                  }}
                  className="hover:text-white transition-colors text-left"
                >
                  Wi-Fi QR Code Guide
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenGuides) onOpenGuides();
                    else onNavigateTab('guide');
                  }}
                  className="hover:text-white transition-colors text-left"
                >
                  Business QR Best Practices
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Informational */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white/40 font-mono">
              Transparency & Legal
            </h4>
            <ul className="space-y-2 text-xs text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => onOpenModal('about')}
                  className="hover:text-white transition-colors text-left"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenModal('contact')}
                  className="hover:text-white transition-colors text-left"
                >
                  Contact Us
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenModal('privacy')}
                  className="hover:text-white transition-colors text-left"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenModal('terms')}
                  className="hover:text-white transition-colors text-left"
                >
                  Terms and Conditions
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenModal('disclaimer')}
                  className="hover:text-white transition-colors text-left"
                >
                  Disclaimer
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Copyright & Disclosure */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-white/50 gap-4">
          <p>© {new Date().getFullYear()} QR Studio. All rights reserved.</p>
          <div className="flex items-center gap-3 text-[11px] text-white/40">
            <span>Direct Email: contact@qrstudio.app</span>
            <span>•</span>
            <span>Client-side Privacy Engine</span>
          </div>
        </div>
      </div>
    </footer>
  );
});

Footer.displayName = 'Footer';
