import React, { useEffect, useRef, useState, useCallback, memo } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  RotateCcw,
  Camera,
  ChevronDown,
  ChevronUp,
  Sparkles,
} from 'lucide-react';

interface ThreeQRShowcaseProps {
  qrCanvas: HTMLCanvasElement | null;
  qrContent: string;
}

type StandType = 'acrylic' | 'wood' | 'kiosk';
type FinishType = 'studio' | 'gold' | 'midnight' | 'minimal';

export const ThreeQRShowcase: React.FC<ThreeQRShowcaseProps> = memo(({ qrCanvas }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [standType, setStandType] = useState<StandType>('acrylic');
  const [finish, setFinish] = useState<FinishType>('studio');
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [isRenderExporting, setIsRenderExporting] = useState<boolean>(false);

  // References for scene synchronization without tearing down canvas
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const qrTextureRef = useRef<THREE.CanvasTexture | null>(null);
  const defaultTextureRef = useRef<THREE.CanvasTexture | null>(null);
  const qrMeshRef = useRef<THREE.Mesh | null>(null);
  const isSoftwareGlRef = useRef<boolean>(false);
  const isVisibleRef = useRef<boolean>(true);
  const autoRotateRef = useRef<boolean>(autoRotate);
  const requestRenderRef = useRef<(() => void) | null>(null);

  autoRotateRef.current = autoRotate;

  // Pre-generate a crisp default procedural QR canvas texture so stand never renders untextured
  const createDefaultQRTexture = useCallback(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, 512, 512);
      ctx.fillStyle = '#171717';

      // Three corner locator eyes
      const drawEye = (ox: number, oy: number) => {
        ctx.fillRect(ox, oy, 110, 110);
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(ox + 20, oy + 20, 70, 70);
        ctx.fillStyle = '#171717';
        ctx.fillRect(ox + 35, oy + 35, 40, 40);
      };

      drawEye(40, 40);
      drawEye(362, 40);
      drawEye(40, 362);

      // Clean QR data matrix pattern
      for (let r = 0; r < 14; r++) {
        for (let c = 0; c < 14; c++) {
          if ((r * 13 + c * 7 + (r ^ c)) % 3 === 0) {
            ctx.fillRect(60 + c * 28, 60 + r * 28, 20, 20);
          }
        }
      }
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, []);

  // Texture helper: create procedural contact shadow
  const createContactShadowTexture = useCallback(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    const gradient = ctx.createRadialGradient(128, 128, 10, 128, 128, 120);
    gradient.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
    gradient.addColorStop(0.35, 'rgba(0, 0, 0, 0.35)');
    gradient.addColorStop(0.7, 'rgba(0, 0, 0, 0.12)');
    gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 256, 256);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, []);

  // Texture helper: procedural wood grain
  const createWoodTexture = useCallback(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#3a2312';
    ctx.fillRect(0, 0, 512, 512);

    ctx.fillStyle = '#2b180a';
    for (let i = 0; i < 40; i++) {
      const y = Math.random() * 512;
      const h = Math.random() * 8 + 2;
      ctx.globalAlpha = 0.25;
      ctx.fillRect(0, y, 512, h);
    }
    ctx.globalAlpha = 1.0;
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    return texture;
  }, []);

  // Build the 3–12 part procedural model
  const rebuildStandModel = useCallback(
    (type: StandType, activeFinish: FinishType) => {
      const group = modelGroupRef.current;
      if (!group) return;

      // Clean prior meshes
      while (group.children.length > 0) {
        const child = group.children[0];
        group.remove(child);
        if ((child as THREE.Mesh).geometry) {
          (child as THREE.Mesh).geometry.dispose();
        }
      }

      // Finish variations
      const metalProps =
        activeFinish === 'gold'
          ? { color: 0xd4af37, metalness: 0.95, roughness: 0.18 }
          : activeFinish === 'midnight'
          ? { color: 0x1f242d, metalness: 0.85, roughness: 0.3 }
          : activeFinish === 'minimal'
          ? { color: 0x2563eb, metalness: 0.4, roughness: 0.2 }
          : { color: 0xc8cdd0, metalness: 0.9, roughness: 0.22 };

      const shadowTex = createContactShadowTexture();
      const shadowMat = new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.5,
      });

      if (!defaultTextureRef.current) {
        defaultTextureRef.current = createDefaultQRTexture();
      }
      const activeQRTexture = qrTextureRef.current || defaultTextureRef.current;

      if (type === 'acrylic') {
        // --- Tabletop Acrylic QR Stand ---
        const baseGeo = new THREE.BoxGeometry(2.4, 0.12, 1.2);
        const baseMat = new THREE.MeshStandardMaterial({
          color: metalProps.color,
          metalness: metalProps.metalness,
          roughness: metalProps.roughness,
        });
        const baseMesh = new THREE.Mesh(baseGeo, baseMat);
        baseMesh.position.set(0, 0.06, 0);
        baseMesh.castShadow = true;
        baseMesh.receiveShadow = true;
        group.add(baseMesh);

        // Clamps
        const clampGeo = new THREE.BoxGeometry(0.24, 0.32, 0.36);
        const clampMat = new THREE.MeshStandardMaterial({
          color: 0x171717,
          metalness: 0.8,
          roughness: 0.25,
        });
        const leftClamp = new THREE.Mesh(clampGeo, clampMat);
        leftClamp.position.set(-0.85, 0.22, 0);
        group.add(leftClamp);

        const rightClamp = new THREE.Mesh(clampGeo, clampMat);
        rightClamp.position.set(0.85, 0.22, 0);
        group.add(rightClamp);

        // Screws
        const screwGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.42, 12);
        const screwMat = new THREE.MeshStandardMaterial({
          color: 0xe6b800,
          metalness: 0.95,
          roughness: 0.15,
        });
        const leftScrew = new THREE.Mesh(screwGeo, screwMat);
        leftScrew.rotation.x = Math.PI / 2;
        leftScrew.position.set(-0.85, 0.25, 0.18);
        group.add(leftScrew);

        const rightScrew = new THREE.Mesh(screwGeo, screwMat);
        rightScrew.rotation.x = Math.PI / 2;
        rightScrew.position.set(0.85, 0.25, 0.18);
        group.add(rightScrew);

        // Angled Acrylic Faceplate
        const plateGeo = new THREE.BoxGeometry(2.0, 2.3, 0.06);
        const acrylicMat = new THREE.MeshPhysicalMaterial({
          color: 0xffffff,
          transmission: isSoftwareGlRef.current ? 0 : 0.92,
          transparent: true,
          opacity: isSoftwareGlRef.current ? 0.45 : 1.0,
          roughness: 0.04,
          ior: 1.5,
          thickness: 0.6,
          clearcoat: 1.0,
        });
        const plateMesh = new THREE.Mesh(plateGeo, acrylicMat);
        plateMesh.position.set(0, 1.25, -0.05);
        plateMesh.rotation.x = -0.12;
        plateMesh.castShadow = true;
        group.add(plateMesh);

        // QR Code Decal
        const qrGeo = new THREE.PlaneGeometry(1.5, 1.5);
        const qrMat = new THREE.MeshBasicMaterial({
          map: activeQRTexture,
          transparent: true,
          polygonOffset: true,
          polygonOffsetFactor: -1,
          polygonOffsetUnits: -1,
        });
        const qrMesh = new THREE.Mesh(qrGeo, qrMat);
        qrMesh.name = 'qr-decal-mesh';
        qrMesh.position.set(0, 1.3, -0.015);
        qrMesh.rotation.x = -0.12;
        group.add(qrMesh);
        qrMeshRef.current = qrMesh;

        // Ground Contact Shadow
        const shadowPlane = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 2.2), shadowMat);
        shadowPlane.rotation.x = -Math.PI / 2;
        shadowPlane.position.set(0, 0.002, 0.1);
        group.add(shadowPlane);
      } else if (type === 'wood') {
        // --- Artisan Carved Walnut Table-Talker ---
        const woodTex = createWoodTexture();
        const blockGeo = new THREE.BoxGeometry(2.2, 0.5, 1.1);
        const woodMat = new THREE.MeshStandardMaterial({
          map: woodTex,
          roughness: 0.65,
          metalness: 0.05,
        });
        const blockMesh = new THREE.Mesh(blockGeo, woodMat);
        blockMesh.position.set(0, 0.25, 0);
        blockMesh.castShadow = true;
        blockMesh.receiveShadow = true;
        group.add(blockMesh);

        const cardGeo = new THREE.BoxGeometry(1.9, 2.2, 0.04);
        const cardMat = new THREE.MeshStandardMaterial({
          color: activeFinish === 'gold' ? 0x222222 : 0xffffff,
          roughness: 0.25,
          metalness: 0.1,
        });
        const cardMesh = new THREE.Mesh(cardGeo, cardMat);
        cardMesh.position.set(0, 1.32, -0.05);
        cardMesh.rotation.x = -0.14;
        cardMesh.castShadow = true;
        group.add(cardMesh);

        const qrGeo = new THREE.PlaneGeometry(1.4, 1.4);
        const qrMat = new THREE.MeshBasicMaterial({
          map: activeQRTexture,
          polygonOffset: true,
          polygonOffsetFactor: -1,
          polygonOffsetUnits: -1,
        });
        const qrMesh = new THREE.Mesh(qrGeo, qrMat);
        qrMesh.name = 'qr-decal-mesh';
        qrMesh.position.set(0, 1.36, -0.025);
        qrMesh.rotation.x = -0.14;
        group.add(qrMesh);
        qrMeshRef.current = qrMesh;

        const plateGeo = new THREE.BoxGeometry(1.6, 0.22, 0.02);
        const plateMat = new THREE.MeshStandardMaterial({
          color: 0xd4af37,
          metalness: 0.95,
          roughness: 0.2,
        });
        const plateMesh = new THREE.Mesh(plateGeo, plateMat);
        plateMesh.position.set(0, 0.25, 0.56);
        group.add(plateMesh);

        const screwGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.05, 8);
        const leftScrew = new THREE.Mesh(screwGeo, plateMat);
        leftScrew.rotation.x = Math.PI / 2;
        leftScrew.position.set(-0.7, 0.25, 0.57);
        group.add(leftScrew);

        const rightScrew = new THREE.Mesh(screwGeo, plateMat);
        rightScrew.rotation.x = Math.PI / 2;
        rightScrew.position.set(0.7, 0.25, 0.57);
        group.add(rightScrew);

        const shadowPlane = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 2.0), shadowMat);
        shadowPlane.rotation.x = -Math.PI / 2;
        shadowPlane.position.set(0, 0.002, 0.1);
        group.add(shadowPlane);
      } else {
        // --- Countertop Kiosk Pedestal ---
        const baseGeo = new THREE.CylinderGeometry(1.1, 1.2, 0.14, 24);
        const baseMat = new THREE.MeshStandardMaterial({
          color: metalProps.color,
          metalness: metalProps.metalness,
          roughness: metalProps.roughness,
        });
        const baseMesh = new THREE.Mesh(baseGeo, baseMat);
        baseMesh.position.set(0, 0.07, 0);
        baseMesh.castShadow = true;
        baseMesh.receiveShadow = true;
        group.add(baseMesh);

        const stemGeo = new THREE.CylinderGeometry(0.18, 0.22, 1.4, 16);
        const stemMat = new THREE.MeshStandardMaterial({
          color: 0x171717,
          metalness: 0.7,
          roughness: 0.3,
        });
        const stemMesh = new THREE.Mesh(stemGeo, stemMat);
        stemMesh.position.set(0, 0.84, 0);
        stemMesh.castShadow = true;
        group.add(stemMesh);

        const knuckleGeo = new THREE.SphereGeometry(0.24, 12, 12);
        const knuckleMat = new THREE.MeshStandardMaterial({
          color: metalProps.color,
          metalness: 0.9,
          roughness: 0.15,
        });
        const knuckleMesh = new THREE.Mesh(knuckleGeo, knuckleMat);
        knuckleMesh.position.set(0, 1.58, 0);
        group.add(knuckleMesh);

        const headGeo = new THREE.BoxGeometry(2.0, 2.1, 0.18);
        const headMat = new THREE.MeshStandardMaterial({
          color: 0x171717,
          metalness: 0.85,
          roughness: 0.2,
        });
        const headMesh = new THREE.Mesh(headGeo, headMat);
        headMesh.position.set(0, 2.2, 0.15);
        headMesh.rotation.x = -0.32;
        headMesh.castShadow = true;
        group.add(headMesh);

        const trimGeo = new THREE.BoxGeometry(2.06, 0.06, 0.2);
        const trimMat = new THREE.MeshStandardMaterial({
          color: 0x2563eb,
          roughness: 0.2,
          metalness: 0.5,
        });
        const trimMesh = new THREE.Mesh(trimGeo, trimMat);
        trimMesh.position.set(0, 3.24, -0.19);
        trimMesh.rotation.x = -0.32;
        group.add(trimMesh);

        const glassGeo = new THREE.PlaneGeometry(1.8, 1.9);
        const glassMat = new THREE.MeshPhysicalMaterial({
          color: 0xffffff,
          roughness: 0.05,
          clearcoat: 1.0,
          transparent: true,
          opacity: 0.88,
        });
        const glassMesh = new THREE.Mesh(glassGeo, glassMat);
        glassMesh.position.set(0, 2.2, 0.25);
        glassMesh.rotation.x = -0.32;
        group.add(glassMesh);

        const qrGeo = new THREE.PlaneGeometry(1.4, 1.4);
        const qrMat = new THREE.MeshBasicMaterial({
          map: activeQRTexture,
          polygonOffset: true,
          polygonOffsetFactor: -1,
          polygonOffsetUnits: -1,
        });
        const qrMesh = new THREE.Mesh(qrGeo, qrMat);
        qrMesh.name = 'qr-decal-mesh';
        qrMesh.position.set(0, 2.22, 0.26);
        qrMesh.rotation.x = -0.32;
        group.add(qrMesh);
        qrMeshRef.current = qrMesh;

        const shadowPlane = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 3.0), shadowMat);
        shadowPlane.rotation.x = -Math.PI / 2;
        shadowPlane.position.set(0, 0.002, 0);
        group.add(shadowPlane);
      }

      requestRenderRef.current?.();
    },
    [createContactShadowTexture, createWoodTexture, createDefaultQRTexture]
  );

  // Update QR Texture cleanly without full re-allocation
  useEffect(() => {
    if (!qrCanvas) return;

    if (!qrTextureRef.current) {
      const texture = new THREE.CanvasTexture(qrCanvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      if (rendererRef.current) {
        texture.anisotropy = Math.min(4, rendererRef.current.capabilities.getMaxAnisotropy());
      }
      qrTextureRef.current = texture;
    } else {
      qrTextureRef.current.image = qrCanvas;
      qrTextureRef.current.needsUpdate = true;
    }

    if (modelGroupRef.current) {
      modelGroupRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh && child.name === 'qr-decal-mesh') {
          (child.material as THREE.MeshBasicMaterial).map = qrTextureRef.current;
          (child.material as THREE.MeshBasicMaterial).needsUpdate = true;
        }
      });
    }

    requestRenderRef.current?.();
  }, [qrCanvas]);

  // Main Three.js Scene Setup & Render Loop
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL guard
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();
    isSoftwareGlRef.current = isSoftwareGl;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.5));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth, container.clientHeight);

    container.replaceChildren(renderer.domElement);
    rendererRef.current = renderer;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf8fafc);
    scene.fog = new THREE.Fog(0xf8fafc, 6, 16);
    sceneRef.current = scene;

    // RoomEnvironment Studio PBR Reflections
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio 3-Point Lighting Rig
    const keyLight = new THREE.DirectionalLight(0xfff3e0, 2.2);
    keyLight.position.set(4, 6, 5);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.shadow) {
      keyLight.shadow.mapSize.width = 512;
      keyLight.shadow.mapSize.height = 512;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 15;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight(0xe8f0fe, 0xd0d7de, 1.1);
    scene.add(hemiLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 0.8);
    rimLight.position.set(-4, 3, -4);
    scene.add(rimLight);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      42,
      container.clientWidth / container.clientHeight,
      0.1,
      40
    );
    camera.position.set(0, 1.8, 4.4);
    cameraRef.current = camera;

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI / 2 - 0.05;
    controls.minDistance = 2.0;
    controls.maxDistance = 8.0;
    controls.target.set(0, 1.2, 0);
    controlsRef.current = controls;

    // Model Group
    const modelGroup = new THREE.Group();
    scene.add(modelGroup);
    modelGroupRef.current = modelGroup;

    // Initial build
    rebuildStandModel(standType, finish);

    // Render-on-demand request trigger
    let isRenderPending = false;
    const requestRender = () => {
      if (!isRenderPending && isVisibleRef.current) {
        isRenderPending = true;
        requestAnimationFrame(() => {
          isRenderPending = false;
          controls.update();
          renderer.render(scene, camera);
        });
      }
    };
    requestRenderRef.current = requestRender;

    // Listen to camera controls change (dragging / damping / zooming)
    const onControlsChange = () => {
      requestRender();
    };
    controls.addEventListener('change', onControlsChange);

    // Smooth animation loop that runs when autoRotate is active and visible
    let frameId = 0;
    const tick = () => {
      if (isVisibleRef.current && autoRotateRef.current && modelGroupRef.current) {
        modelGroupRef.current.rotation.y += 0.005;
        renderer.render(scene, camera);
      }
      frameId = requestAnimationFrame(tick);
    };

    frameId = requestAnimationFrame(tick);

    // IntersectionObserver: Pause WebGL completely when user scrolls away!
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        isVisibleRef.current = entry.isIntersecting;
        if (entry.isIntersecting) {
          requestRender();
        }
      },
      { threshold: 0.1 }
    );
    observer.observe(container);

    // Responsive resize handler with debounced RAF
    let resizeTimer = 0;
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      cancelAnimationFrame(resizeTimer);
      resizeTimer = requestAnimationFrame(() => {
        const w = container.clientWidth;
        const h = container.clientHeight;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
        requestRender();
      });
    };

    window.addEventListener('resize', handleResize, { passive: true });

    return () => {
      cancelAnimationFrame(frameId);
      cancelAnimationFrame(resizeTimer);
      observer.disconnect();
      controls.removeEventListener('change', onControlsChange);
      controls.dispose();
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update model when standType or finish changes
  useEffect(() => {
    rebuildStandModel(standType, finish);
  }, [standType, finish, rebuildStandModel]);

  const handleResetCamera = useCallback(() => {
    if (cameraRef.current && controlsRef.current && modelGroupRef.current) {
      cameraRef.current.position.set(0, 1.8, 4.4);
      controlsRef.current.target.set(0, 1.2, 0);
      controlsRef.current.update();
      modelGroupRef.current.rotation.y = 0;
      requestRenderRef.current?.();
    }
  }, []);

  const handleCaptureSnapshot = useCallback(() => {
    if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;
    setIsRenderExporting(true);
    try {
      rendererRef.current.render(sceneRef.current, cameraRef.current);
      const dataUrl = rendererRef.current.domElement.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `qr-studio-3d-stand-${standType}.png`;
      link.click();
    } catch (err) {
      console.error('Snapshot failed:', err);
    } finally {
      setIsRenderExporting(false);
    }
  }, [standType]);

  return (
    <div className="relative w-full h-[520px] md:h-[620px] bg-slate-50 border border-[#171717]/10 rounded-2xl overflow-hidden shadow-sm flex flex-col will-change-transform">
      {/* 3D Canvas Container */}
      <div ref={mountRef} className="w-full h-full relative cursor-grab active:cursor-grabbing" />

      {/* Top Left Specification Badge */}
      <div className="absolute top-4 left-4 z-10 bg-[#171717] text-white px-3.5 py-1.5 rounded-lg text-xs font-mono flex items-center gap-2 shadow-sm pointer-events-none">
        <Sparkles className="w-3.5 h-3.5 text-[#2563EB]" />
        <span>3D Display Studio</span>
        <span className="text-white/40">|</span>
        <span className="text-white/80 capitalize">{standType} Mockup</span>
      </div>

      {/* Top Right Quick Actions */}
      <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
        <button
          type="button"
          onClick={handleResetCamera}
          title="Reset Camera View"
          className="p-2 bg-white text-[#171717] hover:text-[#2563EB] active:scale-95 border border-[#171717]/10 rounded-lg shadow-xs transition-transform text-xs flex items-center gap-1 font-medium touch-manipulation min-h-[38px]"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Reset View</span>
        </button>
        <button
          type="button"
          onClick={handleCaptureSnapshot}
          disabled={isRenderExporting}
          title="Capture High-Res 3D Snapshot"
          className="px-3 py-2 bg-[#2563EB] text-white hover:bg-[#1d4ed8] active:scale-95 rounded-lg shadow-xs transition-transform text-xs flex items-center gap-1.5 font-medium disabled:opacity-50 touch-manipulation min-h-[38px]"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>{isRenderExporting ? 'Capturing...' : 'Export 3D Render'}</span>
        </button>
      </div>

      {/* Collapsible Unified Bottom Control Dock */}
      <div
        className={`absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-3xl transition-transform duration-200 ease-out ${
          isCollapsed ? 'translate-y-[calc(100%-36px)]' : 'translate-y-0'
        }`}
      >
        <div className="flex justify-center mb-1">
          <button
            type="button"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="px-4 py-1.5 bg-[#171717] text-white text-[11px] font-mono tracking-wider rounded-t-lg flex items-center gap-1 hover:bg-[#2563EB] active:scale-95 transition-all shadow-md touch-manipulation"
          >
            {isCollapsed ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            <span>{isCollapsed ? 'Show 3D Controls' : 'Hide Controls'}</span>
          </button>
        </div>

        <div className="bg-[#171717] text-white rounded-xl p-3 sm:p-4 shadow-xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 sm:gap-4">
          {/* Display Stand Selector */}
          <div className="flex items-center gap-1.5 w-full md:w-auto">
            <span className="text-[11px] font-mono text-white/50 uppercase tracking-wider mr-1">
              Stand:
            </span>
            <button
              type="button"
              onClick={() => setStandType('acrylic')}
              className={`flex-1 md:flex-none px-3 py-2 text-xs font-medium rounded-lg transition-all touch-manipulation active:scale-95 ${
                standType === 'acrylic'
                  ? 'bg-[#2563EB] text-white shadow-xs font-bold'
                  : 'bg-white/5 text-white/80 hover:bg-white/10'
              }`}
            >
              Acrylic Plaque
            </button>
            <button
              type="button"
              onClick={() => setStandType('wood')}
              className={`flex-1 md:flex-none px-3 py-2 text-xs font-medium rounded-lg transition-all touch-manipulation active:scale-95 ${
                standType === 'wood'
                  ? 'bg-[#2563EB] text-white shadow-xs font-bold'
                  : 'bg-white/5 text-white/80 hover:bg-white/10'
              }`}
            >
              Walnut Block
            </button>
            <button
              type="button"
              onClick={() => setStandType('kiosk')}
              className={`flex-1 md:flex-none px-3 py-2 text-xs font-medium rounded-lg transition-all touch-manipulation active:scale-95 ${
                standType === 'kiosk'
                  ? 'bg-[#2563EB] text-white shadow-xs font-bold'
                  : 'bg-white/5 text-white/80 hover:bg-white/10'
              }`}
            >
              Counter Kiosk
            </button>
          </div>

          {/* Finish & Material Switcher */}
          <div className="flex items-center gap-1.5 w-full md:w-auto justify-between md:justify-start">
            <span className="text-[11px] font-mono text-white/50 uppercase tracking-wider mr-1">
              Finish:
            </span>
            {(
              [
                { id: 'studio', label: 'Silver' },
                { id: 'gold', label: 'Brass' },
                { id: 'midnight', label: 'Midnight' },
                { id: 'minimal', label: 'Blue' },
              ] as { id: FinishType; label: string }[]
            ).map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFinish(f.id)}
                className={`px-3 py-1.5 text-xs rounded-md transition-all touch-manipulation active:scale-95 ${
                  finish === f.id
                    ? 'bg-white text-[#171717] font-bold shadow-xs'
                    : 'bg-white/5 text-white/70 hover:bg-white/10'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Auto Rotation Switch */}
          <div className="flex items-center gap-2 self-end md:self-auto">
            <button
              type="button"
              onClick={() => setAutoRotate(!autoRotate)}
              className={`px-3.5 py-1.5 text-xs rounded-lg border transition-all flex items-center gap-1.5 touch-manipulation active:scale-95 ${
                autoRotate
                  ? 'border-[#2563EB] text-[#2563EB] bg-[#2563EB]/10 font-semibold'
                  : 'border-white/20 text-white/70 hover:border-white/40'
              }`}
            >
              <RotateCcw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} />
              <span>{autoRotate ? 'Orbit: ON' : 'Orbit: OFF'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});

ThreeQRShowcase.displayName = 'ThreeQRShowcase';
