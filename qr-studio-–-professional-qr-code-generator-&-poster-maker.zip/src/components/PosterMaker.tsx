import React, { useState, useCallback, memo } from 'react';
import { usePosterEditor } from '../hooks/usePosterEditor';
import { PosterCanvas } from './PosterCanvas';
import { PosterToolbar } from './PosterToolbar';
import { exportPosterFile } from '../utils/exportPoster';
import { POSTER_DIMENSIONS } from '../types/poster';
import { Sparkles, ShieldCheck } from 'lucide-react';

interface PosterMakerProps {
  qrCanvas: HTMLCanvasElement | null;
}

export const PosterMaker: React.FC<PosterMakerProps> = memo(({ qrCanvas }) => {
  const {
    format,
    setFormat,
    backgroundColor,
    setBackgroundColor,
    backgroundImage,
    setBackgroundImage,
    elements,
    selectedElementId,
    setSelectedElementId,
    selectedElement,
    selectedTemplateId,
    selectTemplate,
    updateElement,
    addElement,
    removeElement,
    undo,
    redo,
    canUndo,
    canRedo,
    resetPoster,
  } = usePosterEditor('minimal_business');

  const [isExporting, setIsExporting] = useState<boolean>(false);

  const handleUploadBackgroundImage = useCallback((file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      alert('Background image exceeds 5MB limit.');
      return;
    }
    const url = URL.createObjectURL(file);
    setBackgroundImage(url);
  }, [setBackgroundImage]);

  const handleRemoveBackgroundImage = useCallback(() => {
    if (backgroundImage && backgroundImage.startsWith('blob:')) {
      URL.revokeObjectURL(backgroundImage);
    }
    setBackgroundImage(null);
  }, [backgroundImage, setBackgroundImage]);

  const handleUpdateElementPosition = useCallback((id: string, x: number, y: number) => {
    updateElement(id, { x, y });
  }, [updateElement]);

  const handleExport = useCallback(async (fileType: 'png' | 'jpeg', scale = 2.0) => {
    if (isExporting) return;
    setIsExporting(true);
    try {
      await exportPosterFile(
        format,
        backgroundColor,
        backgroundImage,
        elements,
        qrCanvas,
        fileType,
        scale
      );
    } catch (err) {
      console.error('Failed to export poster:', err);
    } finally {
      setIsExporting(false);
    }
  }, [format, backgroundColor, backgroundImage, elements, qrCanvas, isExporting]);

  const currentDim = POSTER_DIMENSIONS[format];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#171717]/10 dark:border-white/10">
        <div>
          <h2 className="text-2xl font-extrabold text-[#171717] dark:text-white tracking-tight">
            Promotional Poster & Signage Studio
          </h2>
          <p className="text-sm text-[#171717]/70 dark:text-white/70 mt-1">
            Design real, printable promotional flyers, menus, and business cards containing your
            customized QR code.
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#2563EB]/10 text-[#2563EB] dark:text-[#60a5fa] text-xs font-semibold">
          <Sparkles className="w-4 h-4" />
          <span>Industry Paper Size Presets: A4, Letter, Business Card</span>
        </div>
      </div>

      {/* Two Column Layout: Editor Toolbar on Left/Right, Canvas in Center */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Toolbar */}
        <div className="lg:col-span-5 order-2 lg:order-1">
          <PosterToolbar
            format={format}
            backgroundColor={backgroundColor}
            backgroundImage={backgroundImage}
            selectedElement={selectedElement}
            selectedTemplateId={selectedTemplateId}
            canUndo={canUndo}
            canRedo={canRedo}
            isExporting={isExporting}
            onSelectFormat={setFormat}
            onSelectTemplate={selectTemplate}
            onUpdateBackgroundColor={setBackgroundColor}
            onUploadBackgroundImage={handleUploadBackgroundImage}
            onRemoveBackgroundImage={handleRemoveBackgroundImage}
            onAddElement={addElement}
            onUpdateElement={updateElement}
            onRemoveElement={removeElement}
            onUndo={undo}
            onRedo={redo}
            onResetPoster={resetPoster}
            onExportPoster={handleExport}
          />
        </div>

        {/* Center Poster Canvas Viewport */}
        <div className="lg:col-span-7 order-1 lg:order-2 bg-[#171717]/[0.02] dark:bg-white/[0.02] border border-[#171717]/15 dark:border-white/15 rounded-2xl p-4 sm:p-6 flex flex-col items-center justify-center min-h-[560px]">
          {/* Active Preset Specification Header */}
          <div className="w-full flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-3 border-b border-[#171717]/10 dark:border-white/10 text-xs text-[#171717]/60 dark:text-white/60 font-mono gap-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#2563EB]" />
              <span className="font-bold text-[#171717] dark:text-white">{currentDim.label}</span>
              <span className="text-[#171717]/40 dark:text-white/40">•</span>
              <span>{currentDim.physicalSize}</span>
            </div>
            <span className="text-[11px] text-[#2563EB] dark:text-[#60a5fa] font-semibold">{currentDim.category}</span>
          </div>

          <PosterCanvas
            format={format}
            backgroundColor={backgroundColor}
            backgroundImage={backgroundImage}
            elements={elements}
            selectedElementId={selectedElementId}
            qrCanvas={qrCanvas}
            onSelectElement={setSelectedElementId}
            onUpdateElementPosition={handleUpdateElementPosition}
          />

          <div className="mt-4 flex flex-col sm:flex-row items-center justify-between w-full gap-2 text-xs text-[#171717]/60 dark:text-white/60 pt-2 border-t border-[#171717]/10 dark:border-white/10">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#2563EB] shrink-0" />
              <span>Preserves strict QR quiet zones and high-resolution typography during download.</span>
            </div>
            <span className="font-mono text-[11px] text-[#171717]/50 dark:text-white/50">
              Preset: {currentDim.width} × {currentDim.height} px
            </span>
          </div>
        </div>
      </div>
    </div>
  );
});

PosterMaker.displayName = 'PosterMaker';
