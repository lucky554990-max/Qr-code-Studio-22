import { AdPlacement, AdSlotConfig } from '../types/ads';

/**
 * Google AdSense Global Configuration for QR Studio
 *
 * Current Status: PREPARED & READY
 * ADS_ENABLED is currently FALSE.
 *
 * TO ACTIVATE GOOGLE ADSENSE:
 * 1. Obtain an approved AdSense account at https://adsense.google.com/
 * 2. Set ADS_ENABLED to true below or via VITE_ADS_ENABLED=true in your .env
 * 3. Replace ADSENSE_PUBLISHER_ID with your real publisher ID (e.g., 'ca-pub-1234567890123456')
 * 4. Add your verified Ad Unit slot IDs to the SLOTS table below.
 * 5. AdSense compliance note: Ads will automatically conform to responsive containers
 *    and will never cover interactive inputs, download buttons, or poster canvases.
 */

export const ADS_ENABLED = false;

// Real AdSense publisher ID to be populated by the site owner when verified
export const ADSENSE_PUBLISHER_ID = '';

// Dedicated slot definitions matching the user's explicit placement zones
export const AD_SLOTS: Record<AdPlacement, AdSlotConfig> = {
  home_top: {
    id: 'home_top',
    slotId: '',
    label: 'Homepage Top Advertisement',
    format: 'horizontal',
    minHeight: 90,
  },
  home_middle: {
    id: 'home_middle',
    slotId: '',
    label: 'Homepage Middle Advertisement',
    format: 'horizontal',
    minHeight: 120,
  },
  generator_bottom: {
    id: 'generator_bottom',
    slotId: '',
    label: 'QR Generator Workspace Advertisement',
    format: 'auto',
    minHeight: 100,
  },
  customizer_bottom: {
    id: 'customizer_bottom',
    slotId: '',
    label: 'QR Customizer Advertisement',
    format: 'auto',
    minHeight: 100,
  },
  poster_bottom: {
    id: 'poster_bottom',
    slotId: '',
    label: 'Poster Maker Bottom Advertisement',
    format: 'auto',
    minHeight: 100,
  },
  footer_top: {
    id: 'footer_top',
    slotId: '',
    label: 'Footer Pre-Banner Advertisement',
    format: 'horizontal',
    minHeight: 90,
  },
};
