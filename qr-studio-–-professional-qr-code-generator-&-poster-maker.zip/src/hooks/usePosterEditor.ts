import { useState, useCallback, useRef } from 'react';
import {
  PosterCanvasFormat,
  PosterElement,
  PosterElementType,
  PosterTemplate,
  POSTER_DIMENSIONS,
} from '../types/poster';
import { downloadBlob, downloadDataUrl } from '../utils/exportFile';

export const POSTER_TEMPLATES: PosterTemplate[] = [
  {
    id: 'minimal_business',
    name: 'Minimal Business Card & Desk Stand',
    category: 'Corporate & Retail',
    description: 'Clean typographic layout with high-contrast framing for reception desks and business cards.',
    format: 'portrait',
    backgroundColor: '#FFFFFF',
    elements: [
      {
        id: 'header-tag',
        type: 'shape',
        shapeType: 'badge',
        x: 50,
        y: 8,
        width: 40,
        height: 4,
        text: 'OFFICIAL SERVICE',
        color: '#FFFFFF',
        backgroundColor: '#171717',
        fontSize: 14,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      {
        id: 'heading',
        type: 'text',
        x: 50,
        y: 18,
        text: 'Apex Consulting Group',
        fontSize: 34,
        fontWeight: '900',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'subtitle',
        type: 'text',
        x: 50,
        y: 25,
        text: 'Scan to schedule an appointment or download our portfolio',
        fontSize: 16,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'qr-code',
        type: 'qr',
        x: 50,
        y: 52,
        width: 44, // 44% canvas width
        height: 44,
      },
      {
        id: 'divider',
        type: 'shape',
        shapeType: 'divider',
        x: 50,
        y: 78,
        width: 70,
        height: 0.2,
        backgroundColor: '#171717',
      },
      {
        id: 'footer-brand',
        type: 'text',
        x: 50,
        y: 84,
        text: 'www.apexconsulting.io • contact@apexconsulting.io',
        fontSize: 14,
        fontWeight: 'bold',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'footer-note',
        type: 'text',
        x: 50,
        y: 91,
        text: 'Available Mon–Fri • 9:00 AM – 6:00 PM EST',
        fontSize: 12,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
    ],
  },
  {
    id: 'restaurant_menu',
    name: 'Restaurant & Café Digital Menu',
    category: 'Dining & Hospitality',
    description: 'Designed for dining tables, bars, and counter ordering.',
    format: 'portrait',
    backgroundColor: '#FFFFFF',
    elements: [
      {
        id: 'rest-name',
        type: 'text',
        x: 50,
        y: 12,
        text: 'BISTRO LUMIÈRE',
        fontSize: 38,
        fontWeight: '900',
        color: '#171717',
        textAlign: 'center',
        letterSpacing: '0.15em',
      },
      {
        id: 'rest-sub',
        type: 'text',
        x: 50,
        y: 19,
        text: 'Artisanal Bakery & Specialty Coffee',
        fontSize: 15,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'rest-box',
        type: 'shape',
        shapeType: 'badge',
        x: 50,
        y: 28,
        width: 55,
        height: 5,
        text: 'CONTACTLESS MENU & ORDER',
        color: '#FFFFFF',
        backgroundColor: '#2563EB',
        fontSize: 13,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      {
        id: 'qr-code',
        type: 'qr',
        x: 50,
        y: 54,
        width: 42,
        height: 42,
      },
      {
        id: 'rest-instructions',
        type: 'text',
        x: 50,
        y: 77,
        text: 'Point your camera to browse specials, allergens & daily wines',
        fontSize: 14,
        fontWeight: 'bold',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'rest-wifi',
        type: 'text',
        x: 50,
        y: 86,
        text: 'Complimentary Wi-Fi: LumiereGuest / Pass: freshroast',
        fontSize: 12,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
    ],
  },
  {
    id: 'product_promotion',
    name: 'Product Promotion & Offer Flyer',
    category: 'Retail & E-commerce',
    description: 'Special discounts, promotional campaigns, and store sales announcements.',
    format: 'square',
    backgroundColor: '#171717',
    elements: [
      {
        id: 'promo-badge',
        type: 'shape',
        shapeType: 'badge',
        x: 50,
        y: 12,
        width: 60,
        height: 6,
        text: 'LIMITED TIME EXCLUSIVE OFFER',
        color: '#FFFFFF',
        backgroundColor: '#2563EB',
        fontSize: 14,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      {
        id: 'promo-heading',
        type: 'text',
        x: 50,
        y: 24,
        text: 'CLAIM 25% OFF YOUR PURCHASE',
        fontSize: 32,
        fontWeight: '900',
        color: '#FFFFFF',
        textAlign: 'center',
      },
      {
        id: 'promo-sub',
        type: 'text',
        x: 50,
        y: 33,
        text: 'Scan the QR code to activate instant member rewards at checkout',
        fontSize: 15,
        fontWeight: 'normal',
        color: '#FFFFFF',
        textAlign: 'center',
      },
      {
        id: 'qr-code',
        type: 'qr',
        x: 50,
        y: 58,
        width: 38,
        height: 38,
      },
      {
        id: 'promo-terms',
        type: 'text',
        x: 50,
        y: 84,
        text: 'Valid online & in-store. Terms apply.',
        fontSize: 13,
        fontWeight: 'bold',
        color: '#FFFFFF',
        textAlign: 'center',
      },
      {
        id: 'promo-url',
        type: 'text',
        x: 50,
        y: 91,
        text: 'www.mystore.com/vip-offer',
        fontSize: 14,
        fontWeight: 'bold',
        color: '#2563EB',
        textAlign: 'center',
      },
    ],
  },
  {
    id: 'social_media',
    name: 'Social Media Follow & Connect',
    category: 'Creator & Brand',
    description: 'Promote Instagram, YouTube, TikTok, or LinkedIn community handles.',
    format: 'square',
    backgroundColor: '#FFFFFF',
    elements: [
      {
        id: 'social-head',
        type: 'text',
        x: 50,
        y: 15,
        text: 'LET’S STAY CONNECTED',
        fontSize: 34,
        fontWeight: '900',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'social-sub',
        type: 'text',
        x: 50,
        y: 24,
        text: 'Join 50k+ creators. Weekly breakdowns, livestreams & drops.',
        fontSize: 15,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'qr-code',
        type: 'qr',
        x: 50,
        y: 53,
        width: 44,
        height: 44,
      },
      {
        id: 'social-badge',
        type: 'shape',
        shapeType: 'badge',
        x: 50,
        y: 80,
        width: 50,
        height: 6,
        text: '@YOURSTUDIO_HANDLE',
        color: '#FFFFFF',
        backgroundColor: '#2563EB',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      {
        id: 'social-footer',
        type: 'text',
        x: 50,
        y: 91,
        text: 'Tag us in your stories to be featured on our official channel',
        fontSize: 12,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
    ],
  },
  {
    id: 'website_promo',
    name: 'Official Website & Portal Notice',
    category: 'Information & Utility',
    description: 'Clean signage directing visitors to company documentation, portals, or downloads.',
    format: 'a4',
    backgroundColor: '#FFFFFF',
    elements: [
      {
        id: 'web-badge',
        type: 'shape',
        shapeType: 'badge',
        x: 50,
        y: 8,
        width: 45,
        height: 4,
        text: 'DIGITAL DOCUMENTATION',
        color: '#FFFFFF',
        backgroundColor: '#171717',
        fontSize: 14,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      {
        id: 'web-heading',
        type: 'text',
        x: 50,
        y: 17,
        text: 'ACCESS THE CLIENT PORTAL',
        fontSize: 40,
        fontWeight: '900',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'web-sub',
        type: 'text',
        x: 50,
        y: 25,
        text: 'Scan below with your smartphone camera to access project status, invoices, and files.',
        fontSize: 17,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'qr-code',
        type: 'qr',
        x: 50,
        y: 52,
        width: 48,
        height: 48,
      },
      {
        id: 'web-url',
        type: 'text',
        x: 50,
        y: 77,
        text: 'https://portal.yourcompany.com',
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2563EB',
        textAlign: 'center',
      },
      {
        id: 'web-help',
        type: 'text',
        x: 50,
        y: 85,
        text: 'Need assistance? Reach our support team at support@yourcompany.com',
        fontSize: 13,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
    ],
  },
  {
    id: 'contact_info',
    name: 'Business Contact & VCard Card',
    category: 'Professional Network',
    description: 'Save contact details, vCard data, or emergency hotline numbers directly to phones.',
    format: 'portrait',
    backgroundColor: '#FFFFFF',
    elements: [
      {
        id: 'contact-name',
        type: 'text',
        x: 50,
        y: 12,
        text: 'Dr. Eleanor Vance, MD',
        fontSize: 32,
        fontWeight: '900',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'contact-title',
        type: 'text',
        x: 50,
        y: 18,
        text: 'Chief Medical Specialist & Clinic Director',
        fontSize: 15,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'contact-badge',
        type: 'shape',
        shapeType: 'badge',
        x: 50,
        y: 26,
        width: 48,
        height: 4.5,
        text: 'SAVE CONTACT TO PHONE',
        color: '#FFFFFF',
        backgroundColor: '#2563EB',
        fontSize: 13,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      {
        id: 'qr-code',
        type: 'qr',
        x: 50,
        y: 52,
        width: 42,
        height: 42,
      },
      {
        id: 'contact-tel',
        type: 'text',
        x: 50,
        y: 76,
        text: 'Direct: +1 (555) 234-5678',
        fontSize: 16,
        fontWeight: 'bold',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'contact-addr',
        type: 'text',
        x: 50,
        y: 83,
        text: 'Suite 400, Metro Health Pavilion, New York, NY',
        fontSize: 13,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'center',
      },
      {
        id: 'contact-web',
        type: 'text',
        x: 50,
        y: 90,
        text: 'clinic.vancemedical.com',
        fontSize: 14,
        fontWeight: 'bold',
        color: '#2563EB',
        textAlign: 'center',
      },
    ],
  },
  {
    id: 'business_card_pro',
    name: 'Corporate Business Card (3.5 × 2 in)',
    category: 'Stationery & Executive',
    description: 'Industry-standard 3.5" × 2" landscape card with clean executive typography and high-density QR.',
    format: 'business_card',
    backgroundColor: '#FFFFFF',
    elements: [
      {
        id: 'bc-badge',
        type: 'shape',
        shapeType: 'badge',
        x: 28,
        y: 18,
        width: 38,
        height: 7,
        text: 'MANAGING DIRECTOR',
        color: '#FFFFFF',
        backgroundColor: '#171717',
        fontSize: 11,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      {
        id: 'bc-name',
        type: 'text',
        x: 32,
        y: 38,
        text: 'Alexander Vance',
        fontSize: 26,
        fontWeight: '900',
        color: '#171717',
        textAlign: 'left',
      },
      {
        id: 'bc-title',
        type: 'text',
        x: 32,
        y: 52,
        text: 'Senior Partner • Apex Capital Management',
        fontSize: 13,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'left',
      },
      {
        id: 'bc-divider',
        type: 'shape',
        shapeType: 'divider',
        x: 32,
        y: 63,
        width: 48,
        height: 0.3,
        backgroundColor: '#2563EB',
      },
      {
        id: 'bc-contact',
        type: 'text',
        x: 32,
        y: 77,
        text: '+1 (555) 890-1234  •  alex@apexcap.io\nwww.apexcap.io  •  New York, NY',
        fontSize: 11,
        fontWeight: 'normal',
        color: '#171717',
        textAlign: 'left',
      },
      {
        id: 'qr-code',
        type: 'qr',
        x: 82,
        y: 50,
        width: 25,
        height: 25,
      },
    ],
  },
];

export function usePosterEditor(initialTemplateId = 'minimal_business') {
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(initialTemplateId);
  const initialTemplate =
    POSTER_TEMPLATES.find((t) => t.id === initialTemplateId) || POSTER_TEMPLATES[0];

  const [format, setFormat] = useState<PosterCanvasFormat>(initialTemplate.format);
  const [backgroundColor, setBackgroundColor] = useState<string>(initialTemplate.backgroundColor);
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);
  const [elements, setElements] = useState<PosterElement[]>(initialTemplate.elements);
  const [selectedElementId, setSelectedElementId] = useState<string | null>('heading');

  // History stack for undo / redo
  const historyRef = useRef<PosterElement[][]>([initialTemplate.elements]);
  const historyIndexRef = useRef<number>(0);

  const pushHistory = useCallback((newElements: PosterElement[]) => {
    const nextHistory = historyRef.current.slice(0, historyIndexRef.current + 1);
    nextHistory.push(newElements);
    historyRef.current = nextHistory;
    historyIndexRef.current = nextHistory.length - 1;
  }, []);

  const selectTemplate = useCallback((templateId: string) => {
    const tpl = POSTER_TEMPLATES.find((t) => t.id === templateId);
    if (!tpl) return;
    setSelectedTemplateId(templateId);
    setFormat(tpl.format);
    setBackgroundColor(tpl.backgroundColor);
    setBackgroundImage(null);
    setElements(tpl.elements);
    setSelectedElementId(tpl.elements[0]?.id || null);
    historyRef.current = [tpl.elements];
    historyIndexRef.current = 0;
  }, []);

  const updateElement = useCallback(
    (id: string, patch: Partial<PosterElement>) => {
      setElements((prev) => {
        const next = prev.map((el) => (el.id === id ? { ...el, ...patch } : el));
        pushHistory(next);
        return next;
      });
    },
    [pushHistory]
  );

  const addElement = useCallback(
    (type: PosterElementType) => {
      const newId = `element-${Date.now()}`;
      let newEl: PosterElement;

      if (type === 'text') {
        newEl = {
          id: newId,
          type: 'text',
          x: 50,
          y: 40,
          text: 'Custom Text Element',
          fontSize: 20,
          fontWeight: 'bold',
          color: backgroundColor === '#171717' ? '#FFFFFF' : '#171717',
          textAlign: 'center',
        };
      } else if (type === 'shape') {
        newEl = {
          id: newId,
          type: 'shape',
          shapeType: 'badge',
          x: 50,
          y: 35,
          width: 40,
          height: 5,
          text: 'HIGHLIGHT BADGE',
          color: '#FFFFFF',
          backgroundColor: '#2563EB',
          fontSize: 14,
          fontWeight: 'bold',
          textAlign: 'center',
        };
      } else {
        newEl = {
          id: newId,
          type: 'text',
          x: 50,
          y: 50,
          text: 'New Item',
          fontSize: 16,
          color: '#171717',
          textAlign: 'center',
        };
      }

      setElements((prev) => {
        const next = [...prev, newEl];
        pushHistory(next);
        return next;
      });
      setSelectedElementId(newId);
    },
    [backgroundColor, pushHistory]
  );

  const removeElement = useCallback(
    (id: string) => {
      // Prevent deleting the QR code element (poster must have a QR code)
      const el = elements.find((e) => e.id === id);
      if (el?.type === 'qr') {
        return;
      }
      setElements((prev) => {
        const next = prev.filter((e) => e.id !== id);
        pushHistory(next);
        return next;
      });
      setSelectedElementId(null);
    },
    [elements, pushHistory]
  );

  const undo = useCallback(() => {
    if (historyIndexRef.current > 0) {
      historyIndexRef.current -= 1;
      const prevElements = historyRef.current[historyIndexRef.current];
      setElements(prevElements);
    }
  }, []);

  const redo = useCallback(() => {
    if (historyIndexRef.current < historyRef.current.length - 1) {
      historyIndexRef.current += 1;
      const nextElements = historyRef.current[historyIndexRef.current];
      setElements(nextElements);
    }
  }, []);

  const resetPoster = useCallback(() => {
    const tpl = POSTER_TEMPLATES.find((t) => t.id === selectedTemplateId) || POSTER_TEMPLATES[0];
    setFormat(tpl.format);
    setBackgroundColor(tpl.backgroundColor);
    setBackgroundImage(null);
    setElements(tpl.elements);
    setSelectedElementId(tpl.elements[0]?.id || null);
    historyRef.current = [tpl.elements];
    historyIndexRef.current = 0;
  }, [selectedTemplateId]);

  const selectedElement = elements.find((e) => e.id === selectedElementId) || null;

  return {
    format,
    setFormat,
    backgroundColor,
    setBackgroundColor,
    backgroundImage,
    setBackgroundImage,
    elements,
    selectedElementId,
    setSelectedElementId,
    selectedElement,
    selectedTemplateId,
    selectTemplate,
    updateElement,
    addElement,
    removeElement,
    undo,
    redo,
    canUndo: historyIndexRef.current > 0,
    canRedo: historyIndexRef.current < historyRef.current.length - 1,
    resetPoster,
  };
}
