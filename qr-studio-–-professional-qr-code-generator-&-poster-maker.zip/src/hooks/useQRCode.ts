import { useState, useCallback, useEffect, useRef } from 'react';
import QRCodeStyling, {
  DotType,
  CornerSquareType,
  CornerDotType,
  ErrorCorrectionLevel,
} from 'qr-code-styling';
import QRCode from 'qrcode';
import JSZip from 'jszip';
import {
  QRConfig,
  QRMode,
  FrameConfig,
  DotPattern,
  CornerSquarePattern,
  CornerDotPattern,
  ErrorCorrection,
  WiFiConfig,
  VCardConfig,
  WhatsAppConfig,
  EmailConfig,
  SMSConfig,
  UPIConfig,
  BatchItem,
} from '../types/qr';
import { validateAndFormatUrl } from '../utils/validateUrl';
import { evaluateQrContrast, ContrastResult } from '../utils/contrast';
import { renderFramedQrCanvas } from '../utils/qrRenderer';
import { downloadBlob, downloadDataUrl } from '../utils/exportFile';
import {
  formatWiFiPayload,
  formatVCardPayload,
  formatWhatsAppPayload,
  formatEmailPayload,
  formatSMSPayload,
  formatUPIPayload,
} from '../utils/qrPayloads';
import { BrandIconPreset } from '../utils/brandIcons';

const DEFAULT_FRAME: FrameConfig = {
  enabled: false,
  text: 'SCAN ME',
  style: 'bottom-banner',
  textColor: '#FFFFFF',
  frameColor: '#2563EB',
};

const INITIAL_CONFIG: QRConfig = {
  mode: 'url',
  content: 'https://qrstudio.app',
  foregroundColor: '#171717',
  backgroundColor: '#FFFFFF',
  dotType: 'square',
  cornerSquareType: 'square',
  cornerDotType: 'square',
  errorCorrection: 'Q',
  logoUrl: undefined,
  logoFile: null,
  logoSize: 0.24,
  margin: 10,
  frame: DEFAULT_FRAME,
};

const DEFAULT_WIFI: WiFiConfig = {
  ssid: '',
  password: '',
  encryption: 'WPA',
  hidden: false,
};

const DEFAULT_VCARD: VCardConfig = {
  firstName: '',
  lastName: '',
  organization: '',
  title: '',
  phone: '',
  email: '',
  website: '',
  address: '',
  note: '',
};

const DEFAULT_WHATSAPP: WhatsAppConfig = {
  phone: '',
  message: '',
};

const DEFAULT_EMAIL: EmailConfig = {
  email: '',
  subject: '',
  body: '',
};

const DEFAULT_SMS: SMSConfig = {
  phone: '',
  message: '',
};

const DEFAULT_UPI: UPIConfig = {
  vpa: '',
  name: '',
  amount: '',
  note: '',
};

export function useQRCode() {
  const [config, setConfig] = useState<QRConfig>(INITIAL_CONFIG);
  const [urlInput, setUrlInput] = useState<string>('https://qrstudio.app');
  const [textInput, setTextInput] = useState<string>('');
  const [wifiConfig, setWifiConfig] = useState<WiFiConfig>(DEFAULT_WIFI);
  const [vcardConfig, setVcardConfig] = useState<VCardConfig>(DEFAULT_VCARD);
  const [whatsappConfig, setWhatsappConfig] = useState<WhatsAppConfig>(DEFAULT_WHATSAPP);
  const [emailConfig, setEmailConfig] = useState<EmailConfig>(DEFAULT_EMAIL);
  const [smsConfig, setSmsConfig] = useState<SMSConfig>(DEFAULT_SMS);
  const [upiConfig, setUpiConfig] = useState<UPIConfig>(DEFAULT_UPI);

  // Batch Generation State
  const [batchInput, setBatchInput] = useState<string>(
    'https://example.com/product-1, Summer T-Shirt\nhttps://example.com/product-2, Denim Jacket\nhttps://example.com/product-3, Canvas Bag'
  );
  const [batchItems, setBatchItems] = useState<BatchItem[]>([]);
  const [isProcessingBatch, setIsProcessingBatch] = useState<boolean>(false);

  const [urlError, setUrlError] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState<boolean>(false);
  const [contrastResult, setContrastResult] = useState<ContrastResult>(() =>
    evaluateQrContrast(INITIAL_CONFIG.foregroundColor, INITIAL_CONFIG.backgroundColor)
  );
  const [isExporting, setIsExporting] = useState<boolean>(false);

  // Update contrast evaluation when colors change
  useEffect(() => {
    setContrastResult(evaluateQrContrast(config.foregroundColor, config.backgroundColor));
  }, [config.foregroundColor, config.backgroundColor]);

  // Debounced auto-sync to ensure preview stays crisp and responsive
  useEffect(() => {
    const handler = setTimeout(() => {
      let targetPayload = config.content;

      if (config.mode === 'url') {
        const trimmed = urlInput.trim();
        if (trimmed && trimmed !== config.content) {
          const val = validateAndFormatUrl(trimmed);
          if (val.isValid) {
            targetPayload = val.formattedUrl;
            setUrlError(null);
          }
        }
      } else if (config.mode === 'text') {
        const trimmed = textInput.trim();
        if (trimmed) {
          targetPayload = trimmed;
        }
      } else if (config.mode === 'wifi') {
        if (wifiConfig.ssid.trim()) {
          targetPayload = formatWiFiPayload(wifiConfig);
        }
      } else if (config.mode === 'vcard') {
        if (vcardConfig.firstName.trim() || vcardConfig.lastName.trim() || vcardConfig.phone.trim() || vcardConfig.email.trim()) {
          targetPayload = formatVCardPayload(vcardConfig);
        }
      } else if (config.mode === 'whatsapp') {
        if (whatsappConfig.phone.trim()) {
          targetPayload = formatWhatsAppPayload(whatsappConfig);
        }
      } else if (config.mode === 'email') {
        if (emailConfig.email.trim()) {
          targetPayload = formatEmailPayload(emailConfig);
        }
      } else if (config.mode === 'sms') {
        if (smsConfig.phone.trim()) {
          targetPayload = formatSMSPayload(smsConfig);
        }
      } else if (config.mode === 'upi') {
        if (upiConfig.vpa.trim()) {
          targetPayload = formatUPIPayload(upiConfig);
        }
      }

      if (targetPayload && targetPayload !== config.content) {
        setConfig((prev) => ({ ...prev, content: targetPayload }));
        setIsDirty(false);
      }
    }, 280);

    return () => clearTimeout(handler);
  }, [
    urlInput,
    textInput,
    wifiConfig,
    vcardConfig,
    whatsappConfig,
    emailConfig,
    smsConfig,
    upiConfig,
    config.mode,
    config.content,
  ]);

  const handleUrlChange = useCallback((val: string) => {
    setUrlInput(val);
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const handleTextChange = useCallback((val: string) => {
    setTextInput(val);
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const handleWiFiChange = useCallback((patch: Partial<WiFiConfig>) => {
    setWifiConfig((prev) => ({ ...prev, ...patch }));
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const handleVCardChange = useCallback((patch: Partial<VCardConfig>) => {
    setVcardConfig((prev) => ({ ...prev, ...patch }));
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const handleWhatsAppChange = useCallback((patch: Partial<WhatsAppConfig>) => {
    setWhatsappConfig((prev) => ({ ...prev, ...patch }));
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const handleEmailChange = useCallback((patch: Partial<EmailConfig>) => {
    setEmailConfig((prev) => ({ ...prev, ...patch }));
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const handleSMSChange = useCallback((patch: Partial<SMSConfig>) => {
    setSmsConfig((prev) => ({ ...prev, ...patch }));
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const handleUPIChange = useCallback((patch: Partial<UPIConfig>) => {
    setUpiConfig((prev) => ({ ...prev, ...patch }));
    setIsDirty(true);
    setUrlError(null);
  }, []);

  const setMode = useCallback(
    (newMode: QRMode) => {
      let content = config.content;
      if (newMode === 'url') {
        content = urlInput.trim() || 'https://qrstudio.app';
      } else if (newMode === 'text') {
        content = textInput.trim() || 'QR Studio';
      } else if (newMode === 'wifi') {
        content = wifiConfig.ssid ? formatWiFiPayload(wifiConfig) : 'WIFI:T:WPA;S:OfficeGuest;P:Welcome2026;;';
      } else if (newMode === 'vcard') {
        content = formatVCardPayload({
          firstName: vcardConfig.firstName || 'Alex',
          lastName: vcardConfig.lastName || 'Morgan',
          organization: vcardConfig.organization || 'Creative Studio Inc',
          title: vcardConfig.title || 'Director',
          phone: vcardConfig.phone || '+1 555-0199',
          email: vcardConfig.email || 'alex@example.com',
          website: vcardConfig.website || 'https://example.com',
          address: vcardConfig.address || 'San Francisco, CA',
          note: vcardConfig.note || 'Scan to save contact directly',
        });
      } else if (newMode === 'whatsapp') {
        content = formatWhatsAppPayload({
          phone: whatsappConfig.phone || '15550199222',
          message: whatsappConfig.message || 'Hello! I am contacting you from your QR code.',
        });
      } else if (newMode === 'email') {
        content = formatEmailPayload({
          email: emailConfig.email || 'hello@example.com',
          subject: emailConfig.subject || 'Inquiry from QR Code',
          body: emailConfig.body || 'Hi, I would like to learn more about your services.',
        });
      } else if (newMode === 'sms') {
        content = formatSMSPayload({
          phone: smsConfig.phone || '15550199222',
          message: smsConfig.message || 'Hi there!',
        });
      } else if (newMode === 'upi') {
        content = formatUPIPayload({
          vpa: upiConfig.vpa || 'merchant@upi',
          name: upiConfig.name || 'Merchant Store',
          amount: upiConfig.amount || '50.00',
          note: upiConfig.note || 'Order Payment',
        });
      }

      setConfig((prev) => ({ ...prev, mode: newMode, content }));
      setIsDirty(false);
      setUrlError(null);
    },
    [
      config.content,
      urlInput,
      textInput,
      wifiConfig,
      vcardConfig,
      whatsappConfig,
      emailConfig,
      smsConfig,
      upiConfig,
    ]
  );

  const generateQRCode = useCallback(() => {
    if (config.mode === 'url') {
      const validation = validateAndFormatUrl(urlInput);
      if (!validation.isValid) {
        setUrlError(validation.error || 'Invalid URL format');
        return false;
      }
      setUrlError(null);
      setUrlInput(validation.formattedUrl);
      setConfig((prev) => ({ ...prev, content: validation.formattedUrl }));
      setIsDirty(false);
      return true;
    } else if (config.mode === 'text') {
      const trimmed = textInput.trim();
      if (!trimmed) {
        setUrlError('Please enter some text to generate a QR code.');
        return false;
      }
      setUrlError(null);
      setConfig((prev) => ({ ...prev, content: trimmed }));
      setIsDirty(false);
      return true;
    } else if (config.mode === 'wifi') {
      if (!wifiConfig.ssid.trim()) {
        setUrlError('Please provide a Wi-Fi Network Name (SSID).');
        return false;
      }
      setUrlError(null);
      setConfig((prev) => ({ ...prev, content: formatWiFiPayload(wifiConfig) }));
      setIsDirty(false);
      return true;
    } else if (config.mode === 'vcard') {
      if (!vcardConfig.firstName.trim() && !vcardConfig.lastName.trim() && !vcardConfig.phone.trim()) {
        setUrlError('Please provide at least a name or phone number for the contact card.');
        return false;
      }
      setUrlError(null);
      setConfig((prev) => ({ ...prev, content: formatVCardPayload(vcardConfig) }));
      setIsDirty(false);
      return true;
    } else if (config.mode === 'whatsapp') {
      if (!whatsappConfig.phone.trim()) {
        setUrlError('Please enter a WhatsApp phone number with country code.');
        return false;
      }
      setUrlError(null);
      setConfig((prev) => ({ ...prev, content: formatWhatsAppPayload(whatsappConfig) }));
      setIsDirty(false);
      return true;
    } else if (config.mode === 'email') {
      const recipientList = (emailConfig.email || '')
        .split(/[,;]+/)
        .map((e) => e.trim())
        .filter(Boolean);
      if (recipientList.length === 0) {
        setUrlError('Please enter at least one recipient email address.');
        return false;
      }
      setUrlError(null);
      setConfig((prev) => ({ ...prev, content: formatEmailPayload(emailConfig) }));
      setIsDirty(false);
      return true;
    } else if (config.mode === 'sms') {
      if (!smsConfig.phone.trim()) {
        setUrlError('Please enter a phone number to receive the SMS.');
        return false;
      }
      setUrlError(null);
      setConfig((prev) => ({ ...prev, content: formatSMSPayload(smsConfig) }));
      setIsDirty(false);
      return true;
    } else if (config.mode === 'upi') {
      if (!upiConfig.vpa.trim() || !upiConfig.name.trim()) {
        setUrlError('Please provide both UPI ID (VPA) and Payee Name.');
        return false;
      }
      setUrlError(null);
      setConfig((prev) => ({ ...prev, content: formatUPIPayload(upiConfig) }));
      setIsDirty(false);
      return true;
    }
    return true;
  }, [
    config.mode,
    urlInput,
    textInput,
    wifiConfig,
    vcardConfig,
    whatsappConfig,
    emailConfig,
    smsConfig,
    upiConfig,
  ]);

  const updateConfig = useCallback((patch: Partial<QRConfig>) => {
    setConfig((prev) => {
      const next = { ...prev, ...patch };
      if (patch.logoUrl && !prev.logoUrl) {
        next.errorCorrection = 'H';
      }
      return next;
    });
  }, []);

  // One-Click Auto-Fix Contrast
  const autoFixContrast = useCallback(() => {
    const bgLum = evaluateQrContrast(config.foregroundColor, config.backgroundColor);
    // If foreground is lighter or ratio is low, decide based on background
    const isBgLight = config.backgroundColor.toLowerCase() !== '#171717' && config.backgroundColor.toLowerCase() !== '#000000';
    if (isBgLight) {
      updateConfig({
        foregroundColor: '#171717',
        backgroundColor: '#FFFFFF',
      });
    } else {
      updateConfig({
        foregroundColor: '#FFFFFF',
        backgroundColor: '#171717',
      });
    }
  }, [config.foregroundColor, config.backgroundColor, updateConfig]);

  // Apply Brand Icon Preset
  const applyBrandIcon = useCallback(
    (preset: BrandIconPreset) => {
      updateConfig({
        logoUrl: preset.svgDataUri,
        logoFile: null,
        errorCorrection: 'H',
        logoSize: 0.22,
      });
    },
    [updateConfig]
  );

  const handleLogoUpload = useCallback(
    (file: File) => {
      const validTypes = ['image/png', 'image/jpeg', 'image/svg+xml', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        throw new Error('Unsupported image format. Please upload PNG, JPEG, SVG, or WebP.');
      }
      if (file.size > 5 * 1024 * 1024) {
        throw new Error('File size exceeds the 5MB limit. Please upload a smaller image.');
      }

      const objectUrl = URL.createObjectURL(file);
      updateConfig({
        logoUrl: objectUrl,
        logoFile: file,
        errorCorrection: 'H',
      });
    },
    [updateConfig]
  );

  const handleRemoveLogo = useCallback(() => {
    if (config.logoUrl && config.logoUrl.startsWith('blob:')) {
      URL.revokeObjectURL(config.logoUrl);
    }
    updateConfig({
      logoUrl: undefined,
      logoFile: null,
      errorCorrection: 'Q',
    });
  }, [config.logoUrl, updateConfig]);

  const resetCustomization = useCallback(() => {
    if (config.logoUrl && config.logoUrl.startsWith('blob:')) {
      URL.revokeObjectURL(config.logoUrl);
    }
    setConfig((prev) => ({
      ...prev,
      foregroundColor: '#171717',
      backgroundColor: '#FFFFFF',
      dotType: 'square' as DotPattern,
      cornerSquareType: 'square' as CornerSquarePattern,
      cornerDotType: 'square' as CornerDotPattern,
      errorCorrection: 'Q' as ErrorCorrection,
      logoUrl: undefined,
      logoFile: null,
      logoSize: 0.24,
      frame: DEFAULT_FRAME,
    }));
  }, [config.logoUrl]);

  // Process Batch Items
  const processBatchQueue = useCallback(async () => {
    const lines = batchInput
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length === 0) return;

    setIsProcessingBatch(true);

    const items: BatchItem[] = lines.map((line, idx) => {
      const parts = line.split(',');
      const content = parts[0].trim();
      const label = parts[1]?.trim() || `Item #${idx + 1}`;
      return {
        id: `batch-${idx}-${Date.now()}`,
        content,
        label,
        status: 'generating',
      };
    });

    setBatchItems(items);

    const updatedItems = [...items];

    for (let i = 0; i < updatedItems.length; i++) {
      try {
        const item = updatedItems[i];
        const dataUrl = await QRCode.toDataURL(item.content, {
          width: 512,
          margin: 1,
          color: {
            dark: config.foregroundColor || '#171717',
            light: config.backgroundColor || '#FFFFFF',
          },
          errorCorrectionLevel: 'M',
        });
        updatedItems[i] = {
          ...item,
          dataUrl,
          status: 'ready',
        };
      } catch (err: unknown) {
        updatedItems[i] = {
          ...updatedItems[i],
          status: 'error',
          error: err instanceof Error ? err.message : 'Failed to encode',
        };
      }
    }

    setBatchItems(updatedItems);
    setIsProcessingBatch(false);
  }, [batchInput, config.foregroundColor, config.backgroundColor]);

  // Download All Batch Items as ZIP
  const downloadBatchZip = useCallback(async () => {
    const readyItems = batchItems.filter((it) => it.status === 'ready' && it.dataUrl);
    if (readyItems.length === 0) return;

    const zip = new JSZip();
    const folder = zip.folder('qr-studio-batch');

    readyItems.forEach((item, idx) => {
      if (item.dataUrl) {
        const base64Data = item.dataUrl.split(',')[1];
        const safeName = item.label
          .toLowerCase()
          .replace(/[^a-z0-9_-]/g, '_')
          .substring(0, 30);
        folder?.file(`${idx + 1}_${safeName || 'qr'}.png`, base64Data, { base64: true });
      }
    });

    const content = await zip.generateAsync({ type: 'blob' });
    downloadBlob(content, 'qr-studio-bulk-collection.zip');
  }, [batchItems]);

  // Export single QR
  const exportQR = useCallback(
    async (format: 'png' | 'jpeg' | 'svg', resolution = 1200) => {
      if (isExporting) return;
      setIsExporting(true);
      try {
        const safeErrorCorrection =
          config.content.length > 500
            ? 'L'
            : config.content.length > 250
            ? 'M'
            : config.logoUrl
            ? 'H'
            : config.errorCorrection || 'Q';

        let tempCanvas: HTMLCanvasElement;

        try {
          const exportInstance = new QRCodeStyling({
            width: resolution,
            height: resolution,
            data: config.content,
            dotsOptions: {
              color: config.foregroundColor,
              type: config.dotType as DotType,
            },
            backgroundOptions: {
              color: config.backgroundColor,
            },
            cornersSquareOptions: {
              color: config.foregroundColor,
              type: config.cornerSquareType as CornerSquareType,
            },
            cornersDotOptions: {
              color: config.foregroundColor,
              type: config.cornerDotType as CornerDotType,
            },
            image: config.logoUrl,
            imageOptions: {
              crossOrigin: 'anonymous',
              margin: 8,
              imageSize: config.logoSize,
            },
            qrOptions: {
              errorCorrectionLevel: safeErrorCorrection as ErrorCorrectionLevel,
            },
          });

          const rawBlob = await exportInstance.getRawData('png');
          if (!rawBlob) throw new Error('Raw blob unavailable');

          const img = new Image();
          const blobUrl = URL.createObjectURL(rawBlob as Blob);
          await new Promise<void>((resolve, reject) => {
            img.onload = () => resolve();
            img.onerror = () => reject(new Error('Failed to load generated QR bitmap'));
            img.src = blobUrl;
          });

          tempCanvas = document.createElement('canvas');
          tempCanvas.width = resolution;
          tempCanvas.height = resolution;
          const tempCtx = tempCanvas.getContext('2d');
          if (!tempCtx) throw new Error('2D context failed');
          tempCtx.drawImage(img, 0, 0, resolution, resolution);
          URL.revokeObjectURL(blobUrl);
        } catch (err) {
          console.warn('QRCodeStyling export fallback activated:', err);
          tempCanvas = document.createElement('canvas');
          tempCanvas.width = resolution;
          tempCanvas.height = resolution;
          await QRCode.toCanvas(tempCanvas, config.content, {
            width: resolution,
            margin: 2,
            color: {
              dark: config.foregroundColor,
              light: config.backgroundColor,
            },
            errorCorrectionLevel: safeErrorCorrection === 'H' ? 'H' : 'M',
          });
        }

        // Frame and typography composition
        const finalCanvas = await renderFramedQrCanvas(tempCanvas, config, resolution);

        if (format === 'png') {
          finalCanvas.toBlob((blob) => {
            if (blob) downloadBlob(blob, 'qr-studio-design.png');
            setIsExporting(false);
          }, 'image/png');
        } else if (format === 'jpeg') {
          const dataUrl = finalCanvas.toDataURL('image/jpeg', 0.95);
          downloadDataUrl(dataUrl, 'qr-studio-design.jpg');
          setIsExporting(false);
        } else if (format === 'svg') {
          const dataUrl = finalCanvas.toDataURL('image/png');
          const svgString = `<svg xmlns="http://www.w3.org/2000/svg" width="${finalCanvas.width}" height="${finalCanvas.height}">
            <image href="${dataUrl}" width="${finalCanvas.width}" height="${finalCanvas.height}" />
          </svg>`;
          const svgBlob = new Blob([svgString], { type: 'image/svg+xml' });
          downloadBlob(svgBlob, 'qr-studio-design.svg');
          setIsExporting(false);
        }
      } catch (err) {
        console.error('Export error:', err);
        setIsExporting(false);
        throw err;
      }
    },
    [config, isExporting]
  );

  return {
    config,
    urlInput,
    textInput,
    wifiConfig,
    vcardConfig,
    whatsappConfig,
    emailConfig,
    smsConfig,
    upiConfig,
    batchInput,
    batchItems,
    isProcessingBatch,
    urlError,
    isDirty,
    contrastResult,
    isExporting,
    setUrlInput: handleUrlChange,
    setTextInput: handleTextChange,
    setWifiConfig: handleWiFiChange,
    setVcardConfig: handleVCardChange,
    setWhatsappConfig: handleWhatsAppChange,
    setEmailConfig: handleEmailChange,
    setSmsConfig: handleSMSChange,
    setUpiConfig: handleUPIChange,
    setBatchInput,
    processBatchQueue,
    downloadBatchZip,
    setMode,
    generateQRCode,
    updateConfig,
    autoFixContrast,
    applyBrandIcon,
    handleLogoUpload,
    handleRemoveLogo,
    resetCustomization,
    exportQR,
  };
}
