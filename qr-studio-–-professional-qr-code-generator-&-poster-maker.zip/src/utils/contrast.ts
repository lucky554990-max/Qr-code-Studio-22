/**
 * Calculate WCAG contrast ratio between two hex colors.
 * Essential for QR code readability (camera sensors need high contrast between modules and background).
 */

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const clean = hex.replace('#', '').trim();
  if (clean.length === 3) {
    return {
      r: parseInt(clean[0] + clean[0], 16),
      g: parseInt(clean[1] + clean[1], 16),
      b: parseInt(clean[2] + clean[2], 16),
    };
  }
  if (clean.length === 6) {
    return {
      r: parseInt(clean.substring(0, 2), 16),
      g: parseInt(clean.substring(2, 4), 16),
      b: parseInt(clean.substring(4, 6), 16),
    };
  }
  return null;
}

function getLuminance(r: number, g: number, b: number): number {
  const [rs, gs, bs] = [r, g, b].map((val) => {
    const s = val / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

export interface ContrastResult {
  ratio: number;
  isAdequate: boolean;
  isOptimal: boolean;
  warningMessage?: string;
}

export function evaluateQrContrast(fgHex: string, bgHex: string): ContrastResult {
  const fgRgb = hexToRgb(fgHex);
  const bgRgb = hexToRgb(bgHex);

  if (!fgRgb || !bgRgb) {
    return {
      ratio: 1,
      isAdequate: false,
      isOptimal: false,
      warningMessage: 'Invalid hex color value format.',
    };
  }

  const lum1 = getLuminance(fgRgb.r, fgRgb.g, fgRgb.b);
  const lum2 = getLuminance(bgRgb.r, bgRgb.g, bgRgb.b);

  const brighter = Math.max(lum1, lum2);
  const darker = Math.min(lum1, lum2);
  const ratio = (brighter + 0.05) / (darker + 0.05);

  const isDarkOnLight = lum2 > lum1;
  const isOptimal = ratio >= 7.0 && isDarkOnLight;
  const isAdequate = ratio >= 4.0;

  let warningMessage: string | undefined;

  if (ratio < 3.0) {
    warningMessage =
      'Severe contrast issue: Contrast ratio is very low (' +
      ratio.toFixed(1) +
      ':1). Most phone cameras will fail to scan this code.';
  } else if (!isAdequate) {
    warningMessage =
      'Caution: Low contrast (' +
      ratio.toFixed(1) +
      ':1). Ensure sufficient lighting when scanning.';
  } else if (!isDarkOnLight && ratio < 6.0) {
    warningMessage =
      'Inverted colors (light QR on dark background): Some older barcode scanners may struggle to decode inverted patterns.';
  }

  return {
    ratio,
    isAdequate,
    isOptimal,
    warningMessage,
  };
}
