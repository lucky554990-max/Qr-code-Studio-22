import { PosterCanvasFormat, PosterElement, POSTER_DIMENSIONS } from '../types/poster';
import { downloadBlob, downloadDataUrl } from './exportFile';

/**
 * High-resolution canvas renderer for Posters and Paper Size Presets (A4, Letter, Business Card, etc.).
 * Ensures quiet zone for QR code, accurate text layout, and crisp print fidelity.
 */
export async function renderPosterToCanvas(
  format: PosterCanvasFormat,
  backgroundColor: string,
  backgroundImage: string | null,
  elements: PosterElement[],
  qrCanvas: HTMLCanvasElement | null,
  targetScale = 1.0
): Promise<HTMLCanvasElement> {
  const baseDim = POSTER_DIMENSIONS[format];
  const width = Math.round(baseDim.width * targetScale);
  const height = Math.round(baseDim.height * targetScale);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not get 2D canvas context');

  // 1. Draw Background
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, width, height);

  if (backgroundImage) {
    try {
      const bgImg = new Image();
      bgImg.crossOrigin = 'anonymous';
      await new Promise<void>((resolve, reject) => {
        bgImg.onload = () => resolve();
        bgImg.onerror = () => reject(new Error('Background image failed to load'));
        bgImg.src = backgroundImage;
      });
      ctx.drawImage(bgImg, 0, 0, width, height);
    } catch (e) {
      console.warn('Could not draw background image:', e);
    }
  }

  // Preview container base width used for typography normalization
  const previewBaseWidth = 460;
  const scaleRatio = width / previewBaseWidth;

  // 2. Draw Elements in order
  for (const el of elements) {
    const posX = (el.x / 100) * width;
    const posY = (el.y / 100) * height;

    if (el.type === 'shape') {
      if (el.shapeType === 'divider') {
        const shapeW = ((el.width ?? 60) / 100) * width;
        const shapeH = Math.max(2 * targetScale, ((el.height ?? 0.3) / 100) * height);
        ctx.fillStyle = el.backgroundColor || '#171717';
        ctx.fillRect(posX - shapeW / 2, posY - shapeH / 2, shapeW, shapeH);
      } else if (el.shapeType === 'badge') {
        const badgeW = ((el.width ?? 40) / 100) * width;
        const badgeH = Math.max(28 * targetScale, ((el.height ?? 5) / 100) * height);
        const badgeX = posX - badgeW / 2;
        const badgeY = posY - badgeH / 2;

        ctx.fillStyle = el.backgroundColor || '#2563EB';
        const r = badgeH / 2;
        ctx.beginPath();
        ctx.moveTo(badgeX + r, badgeY);
        ctx.lineTo(badgeX + badgeW - r, badgeY);
        ctx.quadraticCurveTo(badgeX + badgeW, badgeY, badgeX + badgeW, badgeY + r);
        ctx.lineTo(badgeX + badgeW, badgeY + badgeH - r);
        ctx.quadraticCurveTo(badgeX + badgeW, badgeY + badgeH, badgeX + badgeW - r, badgeY + badgeH);
        ctx.lineTo(badgeX + r, badgeY + badgeH);
        ctx.quadraticCurveTo(badgeX, badgeY + badgeH, badgeX, badgeY + badgeH - r);
        ctx.lineTo(badgeX, badgeY + r);
        ctx.quadraticCurveTo(badgeX, badgeY, badgeX + r, badgeY);
        ctx.closePath();
        ctx.fill();

        if (el.text) {
          ctx.fillStyle = el.color || '#FFFFFF';
          const fontSizePx = Math.round((el.fontSize || 14) * 0.75 * scaleRatio);
          ctx.font = `${el.fontWeight === 'bold' ? 'bold ' : ''}${fontSizePx}px system-ui, -apple-system, sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(el.text, posX, posY);
        }
      }
    } else if (el.type === 'qr') {
      const qrW = ((el.width ?? 40) / 100) * width;
      const qrH = qrW; // Strict 1:1 square ratio
      const qrX = posX - qrW / 2;
      const qrY = posY - qrH / 2;

      // Draw white backing card to ensure strict quiet zone
      ctx.fillStyle = '#FFFFFF';
      const quietPadding = qrW * 0.05;
      ctx.fillRect(
        qrX - quietPadding,
        qrY - quietPadding,
        qrW + quietPadding * 2,
        qrH + quietPadding * 2
      );

      // Subtle border for high visual finish
      ctx.strokeStyle = 'rgba(23, 23, 23, 0.08)';
      ctx.lineWidth = Math.max(1, 2 * targetScale);
      ctx.strokeRect(
        qrX - quietPadding,
        qrY - quietPadding,
        qrW + quietPadding * 2,
        qrH + quietPadding * 2
      );

      if (qrCanvas) {
        ctx.drawImage(qrCanvas, qrX, qrY, qrW, qrH);
      }
    } else if (el.type === 'text' && el.text) {
      ctx.fillStyle = el.color || '#171717';
      const fontSizePx = Math.round((el.fontSize || 16) * 0.75 * scaleRatio);
      const fontW = el.fontWeight === '900' ? '900 ' : el.fontWeight === 'bold' ? 'bold ' : 'normal ';
      ctx.font = `${fontW}${fontSizePx}px system-ui, -apple-system, sans-serif`;
      ctx.textAlign = el.textAlign || 'center';
      ctx.textBaseline = 'middle';

      const lines = el.text.split('\n');
      const lineHeight = fontSizePx * 1.25;
      const startY = posY - ((lines.length - 1) * lineHeight) / 2;

      lines.forEach((line, idx) => {
        ctx.fillText(line, posX, startY + idx * lineHeight);
      });
    }
  }

  return canvas;
}

export async function exportPosterFile(
  format: PosterCanvasFormat,
  backgroundColor: string,
  backgroundImage: string | null,
  elements: PosterElement[],
  qrCanvas: HTMLCanvasElement | null,
  fileType: 'png' | 'jpeg',
  scale = 1.0
): Promise<void> {
  const canvas = await renderPosterToCanvas(
    format,
    backgroundColor,
    backgroundImage,
    elements,
    qrCanvas,
    scale
  );

  const formatSlug = format.replace('_', '-');
  const filename = `qr-studio-${formatSlug}-${Date.now()}.${fileType === 'png' ? 'png' : 'jpg'}`;

  if (fileType === 'png') {
    canvas.toBlob((blob) => {
      if (blob) downloadBlob(blob, filename);
    }, 'image/png');
  } else {
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    downloadDataUrl(dataUrl, filename);
  }
}
