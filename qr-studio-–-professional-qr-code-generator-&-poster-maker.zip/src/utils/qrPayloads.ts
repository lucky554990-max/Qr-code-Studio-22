import {
  WiFiConfig,
  VCardConfig,
  WhatsAppConfig,
  EmailConfig,
  SMSConfig,
  UPIConfig,
} from '../types/qr';

/**
 * Escapes characters for Wi-Fi QR format (special chars: \ ; , : " )
 */
function escapeWiFiString(str: string): string {
  return str.replace(/([\\;,":])/g, '\\$1');
}

export function formatWiFiPayload(config: WiFiConfig): string {
  const enc = config.encryption === 'nopass' ? 'nopass' : config.encryption;
  const ssidEsc = escapeWiFiString(config.ssid.trim());
  const passEsc = config.encryption === 'nopass' ? '' : escapeWiFiString(config.password);
  const hidden = config.hidden ? 'true' : 'false';

  return `WIFI:T:${enc};S:${ssidEsc};P:${passEsc};H:${hidden};;`;
}

export function formatVCardPayload(config: VCardConfig): string {
  const lines: string[] = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `N:${config.lastName.trim()};${config.firstName.trim()};;;`,
    `FN:${[config.firstName.trim(), config.lastName.trim()].filter(Boolean).join(' ')}`,
  ];

  if (config.organization.trim()) {
    lines.push(`ORG:${config.organization.trim()}`);
  }
  if (config.title.trim()) {
    lines.push(`TITLE:${config.title.trim()}`);
  }
  if (config.phone.trim()) {
    lines.push(`TEL;TYPE=CELL,VOICE:${config.phone.trim()}`);
  }
  if (config.email.trim()) {
    const emails = config.email.split(/[,;]+/).map((e) => e.trim()).filter(Boolean);
    emails.forEach((em) => {
      lines.push(`EMAIL;TYPE=INTERNET:${em}`);
    });
  }
  if (config.website.trim()) {
    let url = config.website.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    lines.push(`URL:${url}`);
  }
  if (config.address.trim()) {
    lines.push(`ADR;TYPE=WORK:;;${config.address.trim()};;;;`);
  }
  if (config.note.trim()) {
    lines.push(`NOTE:${config.note.trim()}`);
  }

  lines.push('END:VCARD');
  return lines.join('\n');
}

export function formatWhatsAppPayload(config: WhatsAppConfig): string {
  const cleanPhone = config.phone.replace(/[^0-9]/g, '');
  const encodedMsg = config.message.trim() ? `?text=${encodeURIComponent(config.message.trim())}` : '';
  return `https://wa.me/${cleanPhone}${encodedMsg}`;
}

export function formatEmailPayload(config: EmailConfig): string {
  // Support multiple/duplicate comma- or semicolon-separated recipient emails
  const rawEmails = config.email || '';
  const emailList = rawEmails
    .split(/[,;]+/)
    .map((e) => e.trim())
    .filter(Boolean)
    .join(',');

  const params: string[] = [];

  if (config.cc && config.cc.trim()) {
    const ccList = config.cc
      .split(/[,;]+/)
      .map((e) => e.trim())
      .filter(Boolean)
      .join(',');
    if (ccList) {
      params.push(`cc=${encodeURIComponent(ccList)}`);
    }
  }

  if (config.bcc && config.bcc.trim()) {
    const bccList = config.bcc
      .split(/[,;]+/)
      .map((e) => e.trim())
      .filter(Boolean)
      .join(',');
    if (bccList) {
      params.push(`bcc=${encodeURIComponent(bccList)}`);
    }
  }

  if (config.subject && config.subject.trim()) {
    params.push(`subject=${encodeURIComponent(config.subject.trim())}`);
  }
  if (config.body && config.body.trim()) {
    params.push(`body=${encodeURIComponent(config.body.trim())}`);
  }

  const query = params.length > 0 ? `?${params.join('&')}` : '';
  return `mailto:${emailList}${query}`;
}

export function formatSMSPayload(config: SMSConfig): string {
  const cleanPhone = config.phone.trim();
  if (config.message.trim()) {
    return `SMSTO:${cleanPhone}:${config.message.trim()}`;
  }
  return `tel:${cleanPhone}`;
}

export function formatUPIPayload(config: UPIConfig): string {
  const vpa = config.vpa.trim();
  const name = encodeURIComponent(config.name.trim());
  const params = [`pa=${vpa}`, `pn=${name}`, 'cu=INR'];
  if (config.amount.trim()) {
    params.push(`am=${encodeURIComponent(config.amount.trim())}`);
  }
  if (config.note.trim()) {
    params.push(`tn=${encodeURIComponent(config.note.trim())}`);
  }
  return `upi://pay?${params.join('&')}`;
}
