import { QRConfig } from '../types/qr';

/**
 * Composes a high-resolution canvas with the rendered QR code and optional frame/label.
 * Guarantees standard quiet zone (margin) and crisp typography.
 */
export async function renderFramedQrCanvas(
  rawQrCanvas: HTMLCanvasElement,
  config: QRConfig,
  targetSize = 1200
): Promise<HTMLCanvasElement> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context not available');

  const { frame, backgroundColor, foregroundColor } = config;

  if (!frame.enabled || !frame.text.trim()) {
    // No frame, render raw QR with padding and high quality
    canvas.width = targetSize;
    canvas.height = targetSize;

    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const padding = targetSize * 0.05; // 5% quiet zone
    ctx.drawImage(
      rawQrCanvas,
      padding,
      padding,
      targetSize - padding * 2,
      targetSize - padding * 2
    );
    return canvas;
  }

  // Frame is enabled: compute layout based on frame style
  const bannerHeight = Math.round(targetSize * 0.16);
  const totalWidth = targetSize;
  const isTopBanner = frame.style === 'top-banner';
  const totalHeight = targetSize + bannerHeight;

  canvas.width = totalWidth;
  canvas.height = totalHeight;

  // Background
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, totalWidth, totalHeight);

  // Outer container border if 'card' style
  if (frame.style === 'card') {
    ctx.strokeStyle = frame.frameColor || foregroundColor;
    ctx.lineWidth = Math.max(6, targetSize * 0.012);
    const radius = targetSize * 0.04;
    roundedRect(ctx, 10, 10, totalWidth - 20, totalHeight - 20, radius);
    ctx.stroke();
  }

  // Draw the QR code in its designated box
  const qrPadding = targetSize * 0.06;
  const qrY = isTopBanner ? bannerHeight + qrPadding * 0.5 : qrPadding;
  const qrDrawSize = targetSize - qrPadding * 2;

  ctx.drawImage(rawQrCanvas, qrPadding, qrY, qrDrawSize, qrDrawSize);

  // Draw Banner / Badge
  const bannerY = isTopBanner ? 20 : targetSize;
  const actualBannerH = bannerHeight - 20;

  if (frame.style === 'badge' || frame.style === 'minimal-pill') {
    // Pill shaped badge
    const badgeW = targetSize * 0.65;
    const badgeH = bannerHeight * 0.65;
    const badgeX = (totalWidth - badgeW) / 2;
    const badgeY = isTopBanner ? 30 : targetSize + (bannerHeight - badgeH) / 2;

    ctx.fillStyle = frame.frameColor || foregroundColor;
    roundedRect(ctx, badgeX, badgeY, badgeW, badgeH, badgeH / 2);
    ctx.fill();

    // Text
    ctx.fillStyle = frame.textColor || '#FFFFFF';
    ctx.font = `bold ${Math.round(badgeH * 0.44)}px system-ui, -apple-system, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(frame.text.toUpperCase(), totalWidth / 2, badgeY + badgeH / 2);
  } else {
    // Banner background (top or bottom)
    const bannerBoxX = 20;
    const bannerBoxW = totalWidth - 40;
    const bannerBoxY = isTopBanner ? 20 : targetSize + 10;
    const bannerBoxH = actualBannerH;

    ctx.fillStyle = frame.frameColor || foregroundColor;
    roundedRect(ctx, bannerBoxX, bannerBoxY, bannerBoxW, bannerBoxH, 16);
    ctx.fill();

    // Banner Text
    ctx.fillStyle = frame.textColor || '#FFFFFF';
    ctx.font = `bold ${Math.round(bannerBoxH * 0.42)}px system-ui, -apple-system, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(frame.text.toUpperCase(), totalWidth / 2, bannerBoxY + bannerBoxH / 2);
  }

  return canvas;
}

function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}
