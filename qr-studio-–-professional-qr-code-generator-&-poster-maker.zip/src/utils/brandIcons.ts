export interface BrandIconPreset {
  id: string;
  name: string;
  category: 'social' | 'business' | 'utility';
  svgDataUri: string;
}

function svgToUri(svgString: string): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svgString.trim())}`;
}

export const BRAND_ICON_PRESETS: BrandIconPreset[] = [
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    category: 'social',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <circle cx="24" cy="24" r="23" fill="#25D366" />
        <path fill="#FFFFFF" d="M34.2 13.8C31.5 11.1 27.9 9.6 24.1 9.6c-7.9 0-14.3 6.4-14.3 14.3 0 2.5.6 5 1.9 7.1L10 38.3l7.5-2c2 1.1 4.3 1.7 6.6 1.7 7.9 0 14.3-6.4 14.3-14.3 0-3.8-1.5-7.4-4.2-9.9zm-10.1 22.1c-2.1 0-4.2-.6-6-1.6l-.4-.3-4.5 1.2 1.2-4.3-.3-.4c-1.2-1.9-1.8-4-1.8-6.2 0-6.6 5.4-12 12-12 3.2 0 6.2 1.2 8.5 3.5 2.3 2.3 3.5 5.3 3.5 8.5 0 6.6-5.4 12-12 12zm6.6-8.9c-.4-.2-2.1-1-2.4-1.1-.3-.1-.6-.2-.8.2s-1 1.1-1.2 1.3c-.2.2-.4.2-.8 0s-1.6-.6-3-1.9c-1.1-1-1.9-2.2-2.1-2.5-.2-.4 0-.6.2-.8.2-.2.4-.4.5-.6.2-.2.2-.4.3-.6.1-.2 0-.4 0-.6s-.8-2-1.1-2.7c-.3-.7-.6-.6-.8-.6h-.7c-.2 0-.7.1-1 .5s-1.4 1.4-1.4 3.3c0 2 1.4 3.9 1.6 4.1.2.3 2.8 4.3 6.9 6 1 .4 1.8.7 2.4.9 1 .3 1.9.3 2.6.2.8-.1 2.4-1 2.7-1.9.4-.9.4-1.7.3-1.9-.1-.2-.4-.3-.8-.5z" />
      </svg>
    `),
  },
  {
    id: 'instagram',
    name: 'Instagram',
    category: 'social',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <defs>
          <radialGradient id="ig-grad" cx="20%" cy="105%" r="120%">
            <stop offset="0%" stop-color="#FFDD55" />
            <stop offset="25%" stop-color="#FF543E" />
            <stop offset="50%" stop-color="#C837AB" />
            <stop offset="100%" stop-color="#3771C8" />
          </radialGradient>
        </defs>
        <rect width="48" height="48" rx="12" fill="url(#ig-grad)" />
        <rect x="11" y="11" width="26" height="26" rx="7" fill="none" stroke="#FFFFFF" stroke-width="3.2" />
        <circle cx="24" cy="24" r="6.2" fill="none" stroke="#FFFFFF" stroke-width="3.2" />
        <circle cx="31.2" cy="16.8" r="1.8" fill="#FFFFFF" />
      </svg>
    `),
  },
  {
    id: 'youtube',
    name: 'YouTube',
    category: 'social',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#FF0000" />
        <path fill="#FFFFFF" d="M37.8 17.6c-.4-1.6-1.7-2.8-3.3-3.2-2.9-.8-14.5-.8-14.5-.8s-11.6 0-14.5.8c-1.6.4-2.9 1.6-3.3 3.2-.8 2.9-.8 8.9-.8 8.9s0 6 .8 8.9c.4 1.6 1.7 2.8 3.3 3.2 2.9.8 14.5.8 14.5.8s11.6 0 14.5-.8c1.6-.4 2.9-1.6 3.3-3.2.8-2.9.8-8.9.8-8.9s0-6-.8-8.9zm-17.8 12.4v-12l10.4 6-10.4 6z" />
      </svg>
    `),
  },
  {
    id: 'wifi',
    name: 'Wi-Fi Network',
    category: 'utility',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#171717" />
        <path fill="#FFFFFF" d="M24 35a3 3 0 1 0 0 6 3 3 0 0 0 0-6zm-7.1-5.1a10 10 0 0 1 14.2 0l2.1-2.1a13 13 0 0 0-18.4 0l2.1 2.1zm-4.2-4.2a16 16 0 0 1 22.6 0l2.1-2.1a19 19 0 0 0-26.8 0l2.1 2.1zM8.5 21.5a22 22 0 0 1 31 0l2.1-2.1a25 25 0 0 0-35.2 0l2.1 2.1z" />
      </svg>
    `),
  },
  {
    id: 'location',
    name: 'Map Location',
    category: 'utility',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#EA4335" />
        <path fill="#FFFFFF" d="M24 10c-5.5 0-10 4.5-10 10 0 7.5 10 18 10 18s10-10.5 10-18c0-5.5-4.5-10-10-10zm0 13.5c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5z" />
      </svg>
    `),
  },
  {
    id: 'phone',
    name: 'Call Phone',
    category: 'business',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#2563EB" />
        <path fill="#FFFFFF" d="M33.6 28.4l-4.2-.5c-.9-.1-1.8.3-2.3 1l-1.9 2.3c-4.4-2.2-7.9-5.7-10.1-10.1l2.4-2c.7-.6 1.1-1.5 1-2.4l-.5-4.2c-.2-1.3-1.3-2.3-2.6-2.3H11.5c-1.5 0-2.7 1.2-2.7 2.7 0 14.1 11.5 25.6 25.6 25.6 1.5 0 2.7-1.2 2.7-2.7v-3.9c.1-1.2-.9-2.3-2.2-2.5z" />
      </svg>
    `),
  },
  {
    id: 'mail',
    name: 'Email Contact',
    category: 'business',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#0066DA" />
        <path fill="#FFFFFF" d="M36 14H12c-2.2 0-4 1.8-4 4v12c0 2.2 1.8 4 4 4h24c2.2 0 4-1.8 4-4V18c0-2.2-1.8-4-4-4zm-1.2 4L24 24.8 13.2 18h21.6zM12 30V20.5l11.4 7.1c.4.2.8.2 1.2 0L36 20.5V30H12z" />
      </svg>
    `),
  },
  {
    id: 'website',
    name: 'Website Globe',
    category: 'business',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#171717" />
        <path fill="#FFFFFF" d="M24 10C16.3 10 10 16.3 10 24s6.3 14 14 14 14-6.3 14-14-6.3-14-14-14zm9.9 12h-5.2c-.3-3.2-1.3-6.2-2.8-8.7 3.5 1.7 6.4 4.8 8 8.7zM24 14.1c1.5 2.5 2.5 5.5 2.8 7.9h-5.6c.3-2.4 1.3-5.4 2.8-7.9zM14.1 24c0-.7.1-1.3.2-2h5.4c-.1.7-.2 1.3-.2 2s.1 1.3.2 2h-5.4c-.1-.7-.2-1.3-.2-2zm2 4h5.2c.3 3.2 1.3 6.2 2.8 8.7-3.5-1.7-6.4-4.8-8-8.7zm5.2-12.7c-1.5 2.5-2.5 5.5-2.8 8.7h5.6c-.3-3.2-1.3-6.2-2.8-8.7zm2.7 18.6c-1.5-2.5-2.5-5.5-2.8-7.9h5.6c-.3 2.4-1.3 5.4-2.8 7.9zm4.2-1.9c1.5-2.5 2.5-5.5 2.8-8.7h5.2c-1.6 3.9-4.5 7-8 8.7zm2.8-10.7c.1-.7.2-1.3.2-2s-.1-1.3-.2-2h5.4c.1.7.2 1.3.2 2s-.1 1.3-.2 2h-5.4z" />
      </svg>
    `),
  },
  {
    id: 'cart',
    name: 'Shopping Cart',
    category: 'business',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#16A34A" />
        <path fill="#FFFFFF" d="M14 12h-3c-.6 0-1 .4-1 1s.4 1 1 1h2.2l3.4 14.3c.3 1.2 1.4 2.1 2.6 2.1h15.2c1.2 0 2.3-.9 2.6-2.1L38 16.5c.2-.7-.3-1.5-1-1.5H17.8l-.7-3H14zm6.5 20.4c-1.5 0-2.7 1.2-2.7 2.7s1.2 2.7 2.7 2.7 2.7-1.2 2.7-2.7-1.2-2.7-2.7-2.7zm13 0c-1.5 0-2.7 1.2-2.7 2.7s1.2 2.7 2.7 2.7 2.7-1.2 2.7-2.7-1.2-2.7-2.7-2.7z" />
      </svg>
    `),
  },
  {
    id: 'upi',
    name: 'UPI / Pay',
    category: 'business',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#097939" />
        <path fill="#FFFFFF" d="M24 10C16.3 10 10 16.3 10 24s6.3 14 14 14 14-6.3 14-14-6.3-14-14-14zm3 21h-6v-2h6v2zm3.5-5.5h-9.5c-.8 0-1.5-.7-1.5-1.5v-7c0-.8.7-1.5 1.5-1.5h9.5c.8 0 1.5.7 1.5 1.5v7c0 .8-.7 1.5-1.5 1.5zm-1-8h-7.5v5H29.5v-5z" />
      </svg>
    `),
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    category: 'social',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#0A66C2" />
        <path fill="#FFFFFF" d="M15.3 19h4.3v13.7h-4.3V19zm2.1-6.8c1.4 0 2.5 1.1 2.5 2.5s-1.1 2.5-2.5 2.5-2.5-1.1-2.5-2.5 1.1-2.5 2.5-2.5zM22.5 19h4.1v1.9h.1c.6-1.1 2-2.2 4.1-2.2 4.4 0 5.2 2.9 5.2 6.7v7.3h-4.3v-6.5c0-1.5 0-3.5-2.2-3.5s-2.5 1.7-2.5 3.4v6.6h-4.3V19z" />
      </svg>
    `),
  },
  {
    id: 'x-twitter',
    name: 'X (Twitter)',
    category: 'social',
    svgDataUri: svgToUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
        <rect width="48" height="48" rx="12" fill="#000000" />
        <path fill="#FFFFFF" d="M28.8 13.5h3.4l-7.4 8.5 8.7 11.5h-6.8l-5.3-6.9-6.1 6.9h-3.4l7.9-9.1-8.3-10.9h7l4.8 6.3 5.2-6.3zm-1.2 18.1h1.9L17.7 15.4h-2l11.9 16.2z" />
      </svg>
    `),
  },
];
