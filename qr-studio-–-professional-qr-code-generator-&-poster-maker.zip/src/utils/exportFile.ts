/**
 * Browser-native file download utility
 * Downloads blobs or data URLs without third-party services or tracking.
 */

export function triggerDownload(url: string, filename: string): void {
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function downloadBlob(blob: Blob, filename: string): void {
  const objectUrl = URL.createObjectURL(blob);
  triggerDownload(objectUrl, filename);
  // Defer cleanup to allow browser download initiation
  setTimeout(() => {
    URL.revokeObjectURL(objectUrl);
  }, 2000);
}

export function downloadDataUrl(dataUrl: string, filename: string): void {
  triggerDownload(dataUrl, filename);
}
