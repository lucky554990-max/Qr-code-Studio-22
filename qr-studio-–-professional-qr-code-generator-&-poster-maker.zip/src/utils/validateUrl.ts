export interface UrlValidationResult {
  isValid: boolean;
  formattedUrl: string;
  error?: string;
}

export function validateAndFormatUrl(rawInput: string): UrlValidationResult {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    return {
      isValid: false,
      formattedUrl: '',
      error: 'Please enter a website URL.',
    };
  }

  // Check if string contains spaces
  if (/\s/.test(trimmed)) {
    return {
      isValid: false,
      formattedUrl: trimmed,
      error: 'URL cannot contain whitespace characters.',
    };
  }

  let testUrl = trimmed;

  // If protocol is missing, check if it resembles a valid web domain or localhost
  if (!/^https?:\/\//i.test(testUrl)) {
    // Does it look like a domain or host? e.g. domain.tld or domain.tld/path or domain.tld?param=1
    const domainPattern = /^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(:\d+)?([/?#].*)?$/i;
    const isLocalhost = /^localhost(:\d+)?([/?#].*)?$/i.test(trimmed);

    if (domainPattern.test(trimmed) || isLocalhost) {
      testUrl = `https://${trimmed}`;
    } else {
      return {
        isValid: false,
        formattedUrl: trimmed,
        error: 'Please enter a valid domain (e.g. yoursite.com) or full URL with https://',
      };
    }
  }

  try {
    const parsed = new URL(testUrl);
    // Protocols allowed
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return {
        isValid: false,
        formattedUrl: trimmed,
        error: 'Only http:// and https:// web links are supported.',
      };
    }

    if (!parsed.hostname || parsed.hostname.length < 3) {
      return {
        isValid: false,
        formattedUrl: trimmed,
        error: 'Invalid domain name in URL.',
      };
    }

    return {
      isValid: true,
      formattedUrl: testUrl,
    };
  } catch {
    return {
      isValid: false,
      formattedUrl: trimmed,
      error: 'Malformed URL structure. Please verify the web address.',
    };
  }
}
