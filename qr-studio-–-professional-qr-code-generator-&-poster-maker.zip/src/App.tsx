import React, { useState, useEffect, useCallback } from 'react';
import { useQRCode } from './hooks/useQRCode';
import { useTheme } from './hooks/useTheme';
import { Navbar, NavTab } from './components/Navbar';
import { Hero } from './components/Hero';
import { QRGenerator } from './components/QRGenerator';
import { QRPreview } from './components/QRPreview';
import { QRCustomizer } from './components/QRCustomizer';
import { ThreeQRShowcase } from './components/ThreeQRShowcase';
import { PosterMaker } from './components/PosterMaker';
import { FeatureOverview } from './components/FeatureOverview';
import { SEOArticlesView } from './components/SEOArticlesView';
import { Footer } from './components/Footer';
import { InfoModals, ModalType } from './components/InfoModals';
import { AdSlot } from './components/AdSlot';
import QRCode from 'qrcode';
import {
  Sliders,
  Box,
  Eye,
  Settings2,
  BookOpen,
} from 'lucide-react';

export default function App() {
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState<NavTab>('generator');
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [selectedArticleSlug, setSelectedArticleSlug] = useState<string | null>(null);
  const [showDevAdPlaceholders, setShowDevAdPlaceholders] = useState<boolean>(false);
  const [renderedQrCanvas, setRenderedQrCanvas] = useState<HTMLCanvasElement | null>(null);

  const {
    config,
    urlInput,
    textInput,
    wifiConfig,
    vcardConfig,
    whatsappConfig,
    emailConfig,
    smsConfig,
    upiConfig,
    batchInput,
    batchItems,
    isProcessingBatch,
    urlError,
    isDirty,
    contrastResult,
    isExporting,
    setUrlInput,
    setTextInput,
    setWifiConfig,
    setVcardConfig,
    setWhatsappConfig,
    setEmailConfig,
    setSmsConfig,
    setUpiConfig,
    setBatchInput,
    processBatchQueue,
    downloadBatchZip,
    setMode,
    generateQRCode,
    updateConfig,
    autoFixContrast,
    applyBrandIcon,
    handleLogoUpload,
    handleRemoveLogo,
    resetCustomization,
    exportQR,
  } = useQRCode();

  // Fast, lightweight canvas synchronization for 3D showcase & Poster maker
  useEffect(() => {
    let isCancelled = false;

    const timer = setTimeout(async () => {
      try {
        const dataContent = config.content?.trim() || 'https://qrstudio.app';
        const safeErrorCorrection =
          dataContent.length > 500
            ? 'L'
            : dataContent.length > 250
            ? 'M'
            : config.logoUrl
            ? 'H'
            : config.errorCorrection || 'Q';

        const cvs = document.createElement('canvas');
        cvs.width = 512;
        cvs.height = 512;

        await QRCode.toCanvas(cvs, dataContent, {
          width: 512,
          margin: 1,
          color: {
            dark: config.foregroundColor || '#171717',
            light: config.backgroundColor || '#FFFFFF',
          },
          errorCorrectionLevel: safeErrorCorrection === 'H' ? 'H' : 'M',
        });

        // If logo is present, draw it onto the center of the shared canvas
        if (config.logoUrl) {
          try {
            const logoImg = new Image();
            logoImg.crossOrigin = 'anonymous';
            await new Promise<void>((resolve, reject) => {
              logoImg.onload = () => resolve();
              logoImg.onerror = () => reject();
              logoImg.src = config.logoUrl!;
            });

            const ctx = cvs.getContext('2d');
            if (ctx && !isCancelled) {
              const logoScale = config.logoSize || 0.24;
              const logoDim = 512 * logoScale;
              const logoPos = (512 - logoDim) / 2;

              // Clean backdrop for logo legibility
              ctx.fillStyle = config.backgroundColor || '#FFFFFF';
              ctx.fillRect(logoPos - 4, logoPos - 4, logoDim + 8, logoDim + 8);
              ctx.drawImage(logoImg, logoPos, logoPos, logoDim, logoDim);
            }
          } catch {
            // Safe fallback if logo fails to load
          }
        }

        if (!isCancelled) {
          setRenderedQrCanvas(cvs);
        }
      } catch (err) {
        console.warn('Canvas sync error:', err);
      }
    }, renderedQrCanvas ? 80 : 0);

    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, [
    config.content,
    config.foregroundColor,
    config.backgroundColor,
    config.logoUrl,
    config.logoSize,
    config.errorCorrection,
  ]);

  const scrollToSection = useCallback((id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  const handleClear = useCallback(() => {
    if (config.mode === 'url') setUrlInput('');
    else if (config.mode === 'text') setTextInput('');
    else if (config.mode === 'wifi') setWifiConfig({ ssid: '', password: '', encryption: 'WPA', hidden: false });
    else if (config.mode === 'vcard') setVcardConfig({ firstName: '', lastName: '', organization: '', title: '', phone: '', email: '', website: '', address: '', note: '' });
    else if (config.mode === 'whatsapp') setWhatsappConfig({ phone: '', message: '' });
    else if (config.mode === 'email') setEmailConfig({ email: '', subject: '', body: '' });
    else if (config.mode === 'sms') setSmsConfig({ phone: '', message: '' });
    else if (config.mode === 'upi') setUpiConfig({ vpa: '', name: '', amount: '', note: '' });
  }, [
    config.mode,
    setUrlInput,
    setTextInput,
    setWifiConfig,
    setVcardConfig,
    setWhatsappConfig,
    setEmailConfig,
    setSmsConfig,
    setUpiConfig,
  ]);

  return (
    <div className="min-h-screen bg-white dark:bg-[#121212] text-[#171717] dark:text-[#f3f4f6] flex flex-col font-sans selection:bg-[#2563EB] selection:text-white transition-colors duration-150">
      {/* Navigation Header with Theme Toggle */}
      <Navbar
        activeTab={activeTab}
        theme={theme}
        onToggleTheme={toggleTheme}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'articles') {
            scrollToSection(tab);
          } else {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }}
        onOpenModal={setActiveModal}
      />

      {/* Ad Placement 1: Top Advertisement Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full print:hidden">
        <AdSlot placement="home_top" showDevPlaceholder={showDevAdPlaceholders} />
      </div>

      {/* View Switch: Standalone Guides/Articles View vs Main Generator Workspace */}
      {activeTab === 'articles' ? (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-1 w-full space-y-12">
          <SEOArticlesView
            currentArticleSlug={selectedArticleSlug}
            onSelectArticle={(slug) => setSelectedArticleSlug(slug)}
            onBackToArticlesList={() => setSelectedArticleSlug(null)}
            onNavigateToGenerator={() => {
              setActiveTab('generator');
              scrollToSection('generator');
            }}
          />
        </main>
      ) : (
        <>
          {/* Hero Section */}
          <div className="print:hidden">
            <Hero
              onScrollToGenerator={() => scrollToSection('generator')}
              onScrollToCustomizer={() => scrollToSection('customizer')}
            />
          </div>

          {/* Main Workspaces Area */}
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16 w-full flex-1 print:py-0 print:space-y-0">
            {/* SECTION 1: QR Generator Workspace */}
            <section id="generator" className="space-y-6 scroll-mt-20">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#171717]/10 dark:border-white/10 print:hidden">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]" />
                    <h2 className="text-2xl font-extrabold tracking-tight text-[#171717] dark:text-white">
                      QR Code Generator
                    </h2>
                  </div>
                  <p className="text-sm text-[#171717]/70 dark:text-white/70 mt-1">
                    Choose from 9 specialized formats: URLs, Wi-Fi networks, vCard 3.0 contacts, WhatsApp,
                    Email, SMS, UPI payments, and batch generation.
                  </p>
                </div>

                {/* Ad Placeholder Toggle for Testing & Verification */}
                <button
                  type="button"
                  onClick={() => setShowDevAdPlaceholders(!showDevAdPlaceholders)}
                  className="text-xs text-[#171717]/60 dark:text-white/60 hover:text-[#171717] dark:hover:text-white active:scale-95 px-2.5 py-1.5 rounded-lg border border-[#171717]/15 dark:border-white/15 bg-[#171717]/[0.02] dark:bg-white/[0.02] transition-transform flex items-center gap-1.5 touch-manipulation min-h-[38px]"
                  title="Toggle AdSense layout reservations preview"
                >
                  <Settings2 className="w-3.5 h-3.5" />
                  <span>Ad Slots: {showDevAdPlaceholders ? 'Preview Visible' : 'Normal / Live'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Input Controls */}
                <div className="lg:col-span-7 print:hidden">
                  <QRGenerator
                    mode={config.mode}
                    urlInput={urlInput}
                    textInput={textInput}
                    wifiConfig={wifiConfig}
                    vcardConfig={vcardConfig}
                    whatsappConfig={whatsappConfig}
                    emailConfig={emailConfig}
                    smsConfig={smsConfig}
                    upiConfig={upiConfig}
                    batchInput={batchInput}
                    batchItems={batchItems}
                    isProcessingBatch={isProcessingBatch}
                    urlError={urlError}
                    isDirty={isDirty}
                    onModeChange={setMode}
                    onUrlChange={setUrlInput}
                    onTextChange={setTextInput}
                    onWiFiChange={setWifiConfig}
                    onVCardChange={setVcardConfig}
                    onWhatsAppChange={setWhatsappConfig}
                    onEmailChange={setEmailConfig}
                    onSMSChange={setSmsConfig}
                    onUPIChange={setUpiConfig}
                    onBatchInputChange={setBatchInput}
                    onProcessBatch={processBatchQueue}
                    onDownloadBatchZip={downloadBatchZip}
                    onGenerate={generateQRCode}
                    onClear={handleClear}
                  />
                </div>

                {/* Live Preview & Direct File Downloads */}
                <div className="lg:col-span-5 print:col-span-12 print:flex print:justify-center">
                  <QRPreview
                    config={config}
                    contrastResult={contrastResult}
                    isExporting={isExporting}
                    onExport={exportQR}
                    onReset={resetCustomization}
                    onNavigateToCustomizer={() => scrollToSection('customizer')}
                  />
                </div>
              </div>
            </section>

            {/* Ad Placement 2: Generator Bottom Advertisement */}
            <div className="print:hidden">
              <AdSlot placement="generator_bottom" showDevPlaceholder={showDevAdPlaceholders} />
            </div>

            {/* SECTION 2: Advanced Customization Studio */}
            <section id="customizer" className="space-y-6 scroll-mt-20 print:hidden">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#171717]/10 dark:border-white/10">
                <div>
                  <div className="flex items-center gap-2">
                    <Sliders className="w-5 h-5 text-[#2563EB]" />
                    <h2 className="text-2xl font-extrabold tracking-tight text-[#171717] dark:text-white">
                      Advanced QR Customizer
                    </h2>
                  </div>
                  <p className="text-sm text-[#171717]/70 dark:text-white/70 mt-1">
                    Customize palette colors, check contrast scannability with 1-click Auto-Fix, apply curated brand icons, and attach action frames.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Left Controls */}
                <div className="lg:col-span-7">
                  <QRCustomizer
                    config={config}
                    contrastResult={contrastResult}
                    onUpdateConfig={updateConfig}
                    onAutoFixContrast={autoFixContrast}
                    onApplyBrandIcon={applyBrandIcon}
                    onLogoUpload={handleLogoUpload}
                    onRemoveLogo={handleRemoveLogo}
                    onResetCustomization={resetCustomization}
                  />
                </div>

                {/* Right Live Preview Sticky */}
                <div className="lg:col-span-5 lg:sticky lg:top-24">
                  <QRPreview
                    config={config}
                    contrastResult={contrastResult}
                    isExporting={isExporting}
                    onExport={exportQR}
                    onReset={resetCustomization}
                    onNavigateToCustomizer={() => scrollToSection('showcase')}
                  />
                </div>
              </div>
            </section>

            {/* Ad Placement 3: Customizer Bottom Advertisement */}
            <div className="print:hidden">
              <AdSlot placement="customizer_bottom" showDevPlaceholder={showDevAdPlaceholders} />
            </div>

            {/* SECTION 3: Three.js 3D Physical Display Stand Mockup */}
            <section id="showcase" className="space-y-6 scroll-mt-20 print:hidden">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#171717]/10 dark:border-white/10">
                <div>
                  <div className="flex items-center gap-2">
                    <Box className="w-5 h-5 text-[#2563EB]" />
                    <h2 className="text-2xl font-extrabold tracking-tight text-[#171717] dark:text-white">
                      3D Physical Display Studio
                    </h2>
                  </div>
                  <p className="text-sm text-[#171717]/70 dark:text-white/70 mt-1">
                    Inspect your live customized QR code mapped onto physically-based 3D acrylic stands,
                    counter kiosks, and wood blocks with real studio lighting and orbit controls.
                  </p>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#171717]/60 dark:text-white/60 font-mono">
                  <Eye className="w-4 h-4 text-[#2563EB]" />
                  <span>Interactive 360° PBR Viewport</span>
                </div>
              </div>

              <ThreeQRShowcase qrCanvas={renderedQrCanvas} qrContent={config.content} />
            </section>

            {/* SECTION 4: Feature Overview & 3-Step Guide */}
            <div className="print:hidden">
              <FeatureOverview
                onNavigateTab={(tab) => {
                  setActiveTab(tab);
                  scrollToSection(tab);
                }}
              />
            </div>

            {/* Ad Placement 4: Homepage Middle Advertisement */}
            <div className="print:hidden">
              <AdSlot placement="home_middle" showDevPlaceholder={showDevAdPlaceholders} />
            </div>

            {/* SECTION 5: Promotional Poster Maker */}
            <section id="poster" className="space-y-6 scroll-mt-20 print:page-break-before-always">
              <PosterMaker qrCanvas={renderedQrCanvas} />
            </section>

            {/* Ad Placement 5: Poster Maker Bottom Advertisement */}
            <div className="print:hidden">
              <AdSlot placement="poster_bottom" showDevPlaceholder={showDevAdPlaceholders} />
            </div>

            {/* SECTION 6: In-Page SEO Knowledge Base Preview */}
            <section className="print:hidden pt-8 border-t border-[#171717]/10 dark:border-white/10">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-[#171717] dark:text-white flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-[#2563EB]" />
                    <span>Technical Guides & Educational Resources</span>
                  </h3>
                  <p className="text-xs text-[#171717]/70 dark:text-white/70 mt-1">
                    Explore original guides on QR code generation, Wi-Fi configuration, commercial print specs, and customization.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('articles');
                    setSelectedArticleSlug(null);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-xs font-semibold text-[#2563EB] dark:text-[#60a5fa] hover:underline"
                >
                  View All Guides →
                </button>
              </div>

              <SEOArticlesView
                currentArticleSlug={null}
                onSelectArticle={(slug) => {
                  setSelectedArticleSlug(slug);
                  setActiveTab('articles');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onBackToArticlesList={() => setSelectedArticleSlug(null)}
                onNavigateToGenerator={() => scrollToSection('generator')}
              />
            </section>
          </main>
        </>
      )}

      {/* Footer */}
      <div className="print:hidden">
        <Footer
          theme={theme}
          onToggleTheme={toggleTheme}
          onOpenModal={setActiveModal}
          onNavigateTab={(tab) => {
            setActiveTab(tab);
            scrollToSection(tab);
          }}
          onOpenGuides={() => {
            setActiveTab('articles');
            setSelectedArticleSlug(null);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      </div>

      {/* Informational & Legal Modals */}
      <InfoModals
        activeModal={activeModal}
        onClose={() => setActiveModal(null)}
        onNavigateToGuides={() => {
          setActiveTab('articles');
          setSelectedArticleSlug(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />
    </div>
  );
}
